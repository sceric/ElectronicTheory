LPTscope is free for personal use and can be redistributed
if it is not changed in any way and no fee is requested.
If you intend to use a part of the code from LPTscope in 
your code give a credit to the author.
Terms for including LPTscope into any software packages
are available from the author at the address given below.
LPTscope is supplied on "as is" basis, use it at your own risk.
Always follow safety procedures when working with electric circuits.

Suggestions, questions and bug reports can be directed to the author:
Bojan Banko, at bojan.banko@pu.hinet.hr 
www.geocities/LPTscope
version 1.3 to elecon, at elecon@volny.cz
www.volny.cz/elecon/elecon.html
Any your feedback is always welcome.