// ScopeView.cpp : implementation of the CScopeView class
//

#include "stdafx.h"
#include "LPTScope.h"
#include "MainFrm.h"
// Miran Miran Miran Miran 
#include "math.h"
// Miran Miran Miran Miran  
#include "ScopeDoc.h"
#include "ScopeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScopeView

IMPLEMENT_DYNCREATE(CScopeView, CScrollView)

BEGIN_MESSAGE_MAP(CScopeView, CScrollView)
	//{{AFX_MSG_MAP(CScopeView)
	ON_COMMAND(ID_LEFT, OnLeft)
	ON_COMMAND(ID_RIGHT, OnRight)
	ON_COMMAND(ID_UP, OnUp)
	ON_COMMAND(ID_DOWN, OnDown)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

// Miran Miran Miran Miran  Miran 
	float Miran_zero;
// Miran Miran Miran Miran  Miran


/////////////////////////////////////////////////////////////////////////////
// CScopeView construction/destruction

CScopeView::CScopeView()
{
	// TODO: add construction code here
	m_GuideMode = FALSE;
	m_TrgMouseMode = FALSE;
// Miran Miran Miran Miran  Miran
	m_GuideMode2 = FALSE;
	m_GuideModeZero = FALSE;
	
// Miran Miran Miran Miran  Miran

}

CScopeView::~CScopeView()
{
}

BOOL CScopeView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CScopeView drawing

void CScopeView::OnDraw(CDC* pDC)
{	CScopeDoc* pDoc = GetDocument();

// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran	
	if(pDoc->m_ScrollChange)
		{DWORD k1;
		 k1= (DWORD)ceil(10* pDoc->m_TimeFactor);
		 pDoc->m_ScrollLength = (k1*pDoc->m_MAX_SAMPLES) / 10;
		 if(pDoc->m_ScrollLength > 32767)	pDoc->m_ScrollLength = 32767;
		 CSize sizeTotal;
		 sizeTotal.cx = pDoc->m_ScrollLength;	
    		 sizeTotal.cy = 500;
		 SetScrollSizes(MM_TEXT, sizeTotal);
		 pDoc->m_ScrollChange = FALSE;
		}
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran

	ASSERT_VALID(pDoc);

	CMemDC pMDC(pDC);	// implement flickerfree DC
	CString szTemp;
// Miran Miran Miran Miran  Miran
	CString szTemp1;
	DWORD i;
	DWORD i1;
	DWORD M_S;
// Miran Miran Miran Miran  Miran
	float f;
	CRect TextRect;
	CRect rect;	this->GetClientRect(&rect);
	CPen penTrigger(PS_DOT, 0, RGB(255, 150, 100));
	CPen penCotes(PS_SOLID, 0, RGB(120, 200, 150));
	CPen penGuide(PS_DASH,  0, RGB(200, 200, 255));
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
	CPen penGuideZero(PS_DASH,  0, RGB(255, 100, 255));
	Miran_zero = (pDoc->m_GuideLineZero*5*pDoc->m_VoltageCorrection)/(pDoc->m_YFactor*MAX_ADCBITS);
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran

	// draw GuideLine	
	CPen * pre_pen = pMDC->SelectObject(&penGuide);
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
	pMDC->MoveTo(0, rect.Height() - 10 - pDoc->m_GuideLine);
	//pMDC->LineTo(pDoc->m_MAX_SAMPLES-1, rect.Height() - 10 - pDoc->m_GuideLine);
	pMDC->LineTo(pDoc->m_ScrollLength, rect.Height() - 10 - pDoc->m_GuideLine); 
	// draw GuideLine 2	
	pMDC->MoveTo(0, rect.Height() - 10 - pDoc->m_GuideLine2);
	pMDC->LineTo(pDoc->m_ScrollLength, rect.Height() - 10 - pDoc->m_GuideLine2);

	// draw GuideLineZero
	CPen * pre_pen1 = pMDC->SelectObject(&penGuideZero);
	pMDC->MoveTo(0, rect.Height() - 10 - pDoc->m_GuideLineZero);
	pMDC->LineTo(pDoc->m_ScrollLength, rect.Height() - 10 - pDoc->m_GuideLineZero);
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran 
	
	// create font for all writings
	CFont font;
	font.CreateFont(
		13,							// nHeight
		0,							// nWidth
		0,							// nEscapement
		0,							// nOrientation
		FW_NORMAL,					// nWeight
		FALSE,						// bItalic
		FALSE,						// bUnderline
		0,							// cStrikeOut
		ANSI_CHARSET,				// nCharSet
		OUT_DEFAULT_PRECIS,			// nOutPrecision
		CLIP_DEFAULT_PRECIS,		// nClipPrecision
		DEFAULT_QUALITY,			// nQuality
		DEFAULT_PITCH | FF_SWISS,	// nPitchAndFamily
		"Arial");					// lpszFacename
	CFont * pre_font = pMDC->SelectObject(&font);

	// Demo signal text
	if (pDoc->m_DemoSignal)
	{	pMDC->SetTextColor(RGB(255,130,130));
		szTemp = "This is a demo signal. Press RUN to start the real signal from LPT1";
		pMDC->DrawText(szTemp, &rect, DT_LEFT | DT_TOP | DT_SINGLELINE);
	}

	// write GuideLine value (in Volts)
	pMDC->SetTextColor(RGB(50,150,255));
	szTemp.Format("%.3f V", (float)((pDoc->m_GuideLine*5*pDoc->m_VoltageCorrection)/(pDoc->m_YFactor*MAX_ADCBITS)-Miran_zero));
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
	szTemp = "                                                            " + szTemp;
	TextRect = rect;
	TextRect.bottom = rect.Height() - 10 - pDoc->m_GuideLine;
	pMDC->DrawText(szTemp, &TextRect, DT_LEFT | DT_BOTTOM | DT_SINGLELINE | DT_NOCLIP);

	// write GuideLine 2 value (in Volts)
	pMDC->SetTextColor(RGB(50,150,255));
	szTemp.Format("%.3f V", (float)((pDoc->m_GuideLine2*5*pDoc->m_VoltageCorrection)/(pDoc->m_YFactor*MAX_ADCBITS)-Miran_zero));
	szTemp = "                                                " + szTemp;
	TextRect = rect;
	TextRect.bottom = rect.Height() - 10 - pDoc->m_GuideLine2;
	pMDC->DrawText(szTemp, &TextRect, DT_LEFT | DT_BOTTOM | DT_SINGLELINE | DT_NOCLIP);

 	// write GuideLineZero value 
	pMDC->SetTextColor(RGB(255,80,255));
	szTemp.Format("%.3f V", (float)(pDoc->m_GuideLineZero*5*pDoc->m_VoltageCorrection)/(pDoc->m_YFactor*MAX_ADCBITS));
	szTemp = "                       Zero ( " + szTemp + " )";
	TextRect = rect;
	TextRect.bottom = rect.Height() - 10 - pDoc->m_GuideLineZero;
	pMDC->DrawText(szTemp, &TextRect, DT_LEFT | DT_BOTTOM | DT_SINGLELINE | DT_NOCLIP);

	// Triger level line
	if (pDoc->m_TriggerMode == TRG_INT)
	{	pMDC->SelectObject(&penTrigger);
	//	i = rect.Height() - 10 - (int)(float)(pDoc->m_TriggerValue*pDoc->m_YFactor*MAX_ADCBITS/(pDoc->m_VoltageCorrection*5));
		
	//	pMDC->MoveTo(0, i);
	//	pMDC->LineTo(75, i);
		pMDC->MoveTo(0, rect.Height() - 10 - pDoc->m_TriggerValue);
		pMDC->LineTo(70, rect.Height() - 10 - pDoc->m_TriggerValue);
		pMDC->SetTextColor(RGB(255,120,70));
		szTemp.Format("%.2f V", (float)((pDoc->m_TriggerValue*5*pDoc->m_VoltageCorrection)/(pDoc->m_YFactor*MAX_ADCBITS)-Miran_zero));
		szTemp = "TRG   " + szTemp;	
		TextRect = rect;
		TextRect.bottom = rect.Height() - 10 - pDoc->m_TriggerValue;
		//TextRect.right = 50;
		pMDC->DrawText(szTemp, &TextRect, DT_LEFT | DT_BOTTOM | DT_SINGLELINE | DT_NOCLIP);
	}
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran	
	// Cotes
	if (m_MouseSource != m_MouseDest)
	{	// cotes lines
		pMDC->SelectObject(&penCotes);
		pMDC->MoveTo(m_MouseSource);
		pMDC->LineTo(m_MouseSource.x, m_MouseDest.y);
		pMDC->LineTo(m_MouseDest);
		// cotes text
		pMDC->SetTextColor(RGB(80,160,110));
		f = (float)(m_MouseDest.x - m_MouseSource.x) * pDoc->m_usPerSample / pDoc->m_TimeFactor;
		if (f < 0) f *= -1;
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
		if (f < 1000)
			{szTemp.Format("%.2f�s", f);
			 szTemp1.Format("%.3fkHz", 1000/f);
			}
		else
			{szTemp.Format("%.2fms", f/1000);
			szTemp1.Format("%.0fHz", 1000000/f);
			}
		szTemp = szTemp+"   "+szTemp1;
		TextRect.SetRect(m_MouseSource, m_MouseDest);

		TextRect.NormalizeRect();
if ((m_MouseSource.x - m_MouseDest.x) <50) 
		TextRect.InflateRect(50,14);
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
		UINT nFormat = DT_SINGLELINE | DT_CENTER;
		if (m_MouseSource.y < m_MouseDest.y) 
			nFormat |= DT_BOTTOM;
		else
			nFormat |= DT_TOP;
		pMDC->DrawText(szTemp, &TextRect, nFormat);

		nFormat = DT_SINGLELINE | DT_TOP;
		if (m_MouseSource.x > m_MouseDest.x) 
			nFormat |= DT_RIGHT;
		else
			nFormat |= DT_LEFT;
		TextRect.top += TextRect.Height()/2;
		f = (float)((m_MouseDest.y-m_MouseSource.y)*5*pDoc->m_VoltageCorrection)/(pDoc->m_YFactor*MAX_ADCBITS);
		if (f < 0) f *= -1;
		
		szTemp.Format("%.2fV", f);
		pMDC->DrawText(szTemp, &TextRect, nFormat);


	}
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
	if(pDoc->m_Draw)
		{// draw the signal
		 pMDC->SelectObject(pre_pen);
		 i1=0;
		 // Handle the trigger
		switch (pDoc->m_TriggerMode)
		{	case TRG_INT:
			{	DWORD current, previous, citac;
				BOOLEAN TrigAno;
				previous = 10000;
				for(i1=0;i1<pDoc->m_MAX_SAMPLES;i1++)
					{TrigAno = TRUE;
					 current = pDoc->m_data[i1];
						if (pDoc->m_isSlopeUp)
							{if ((pDoc->m_TriggerValue/pDoc->m_YFactor) >= previous)
								{if ((pDoc->m_TriggerValue/pDoc->m_YFactor) <= current) 
									{for(citac=1;citac<3;citac++)
										{if(TrigAno)
											{if(pDoc->m_data[i1+citac] < pDoc->m_data[i1+citac -1]) TrigAno = FALSE;
										    }
										}
								     if(TrigAno) 
									 {if((current-(pDoc->m_TriggerValue/pDoc->m_YFactor))>((pDoc->m_TriggerValue/pDoc->m_YFactor)-previous)) i1=i1-1; 
										 break;								 
									 }
									}
								}
							}
						else
								{if ((pDoc->m_TriggerValue/pDoc->m_YFactor) <= previous)
										if ((pDoc->m_TriggerValue/pDoc->m_YFactor) >= current)
										{for(citac=1;citac<6;citac++)
										{if(TrigAno)
											{if(pDoc->m_data[i1+citac] > pDoc->m_data[i1+citac -1]) TrigAno = FALSE;										     
											}
										}
								     if(TrigAno) 
									 {if(((pDoc->m_TriggerValue/pDoc->m_YFactor)- current)>(previous-(pDoc->m_TriggerValue/pDoc->m_YFactor))) i1=i1-1; 
										 break;								 
									 }								 
									}
								}
						previous = current;
					}
			 if(i1 == pDoc->m_MAX_SAMPLES) i1 = 1;
			}
					
		}		



		 pMDC->MoveTo(0, rect.Height() - 10 - pDoc->m_data[i1]*pDoc->m_YFactor);
		 //if(pDoc->m_MAX_SAMPLES > 32767)
		 //	{M_S = 32767;
    	 //	}
		 //else
		 //	{M_S = pDoc->m_MAX_SAMPLES;
		 //	}
		 M_S = pDoc->m_MAX_SAMPLES;
		 if(((M_S-i1) * pDoc->m_TimeFactor) > 32767)
			{M_S = (DWORD)((32767+i1) / pDoc->m_TimeFactor);
			}
		 for (i=i1; i < M_S; i++)
			// pMDC->LineTo((int)((i-i1)*pDoc->m_TimeFactor), rect.Height() - 10- pDoc->m_GuideLineZero - (int)(float)(pDoc->m_data[i]*pDoc->m_YFactor));
			pMDC->LineTo((int)((i-i1)*pDoc->m_TimeFactor), rect.Height() - 10-  (int)(float)(pDoc->m_data[i]*pDoc->m_YFactor));
		}
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran

	pMDC->SelectObject(pre_font);
	// Clenup:
	font.DeleteObject();
	penTrigger.DeleteObject();
	penCotes.DeleteObject();
	penGuide.DeleteObject();
 // Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Mira
 //	 if(pDoc->m_Miran_Memory_Mode==1)		// if Memory mode
//	  {CMainFrame* pCMain1 = (CMainFrame*) GetParent();
//	   pCMain1->Miran_Stop();			// stop of reading 
//	  }	
 // Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Mira

}

void CScopeView::OnInitialUpdate()
{
// Miran Miran Miran Miran  Miran Miran Miran 
CScopeDoc* pDoc = GetDocument();
// Miran Miran Miran Miran  Miran Miran Miran 

	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	//sizeTotal.cx = MAX_SAMPLES-1;
// Miran Miran Miran Miran  Miran Miran Miran Miran  
	sizeTotal.cx = pDoc->m_ScrollLength;
// Miran Miran Miran Miran  Miran Miran Miran Miran  

    sizeTotal.cy = 500;
	SetScrollSizes(MM_TEXT, sizeTotal);
}

/////////////////////////////////////////////////////////////////////////////
// CScopeView printing

BOOL CScopeView::OnPreparePrinting(CPrintInfo* pInfo)
{	return DoPreparePrinting(pInfo);
}

void CScopeView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{	// set the page to landscape orientation
	DEVMODE *dm = pInfo->m_pPD->GetDevMode();
	dm->dmOrientation = DMORIENT_LANDSCAPE;
	dm->dmFields = DM_ORIENTATION;
	pDC->ResetDC(dm);
}

void CScopeView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CScopeView diagnostics

#ifdef _DEBUG
void CScopeView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CScopeView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CScopeDoc* CScopeView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CScopeDoc)));
	return (CScopeDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CScopeView message handlers

void CScopeView::OnLeft() 
{	PostMessage(WM_HSCROLL, SB_PAGELEFT, 0);
}

void CScopeView::OnRight() 
{	PostMessage(WM_HSCROLL, SB_PAGERIGHT, 0);
}

void CScopeView::OnUp() 
{	PostMessage(WM_VSCROLL, SB_PAGEUP, 0);
}

void CScopeView::OnDown() 
{	PostMessage(WM_VSCROLL, SB_PAGEDOWN, 0);
}

void CScopeView::OnMouseMove(UINT nFlags, CPoint point) 
{	CPoint pointex = point;
	pointex += GetDeviceScrollPosition();
	if (nFlags == MK_LBUTTON)
	{	if (m_GuideMode)		// GudeLine moving
		{	CScopeDoc* pDoc = GetDocument();
			CRect rect;	GetClientRect(&rect);
			pDoc->m_GuideLine = rect.Height() - 10 - pointex.y;
			SetCursor(AfxGetApp()->LoadCursor(IDC_CURTRG));
			Invalidate();
		}
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
		else if(m_GuideMode2)
		{	CScopeDoc* pDoc = GetDocument();
			CRect rect;	GetClientRect(&rect);
			pDoc->m_GuideLine2 = rect.Height() - 10 - pointex.y;
			SetCursor(AfxGetApp()->LoadCursor(IDC_CURTRG));
			Invalidate();
		}


		else if(m_GuideModeZero)
		{	CScopeDoc* pDoc = GetDocument();
			CRect rect;	GetClientRect(&rect);
			pDoc->m_GuideLineZero = rect.Height() - 10 - pointex.y;
			SetCursor(AfxGetApp()->LoadCursor(IDC_CURTRG));
			Invalidate();
		}
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran

		else if (m_TrgMouseMode)	// Trigger line moving
		{	CScopeDoc* pDoc = GetDocument();
			CRect rect;	GetClientRect(&rect);
			rect.right = 70;
			pDoc->m_TriggerValue = rect.Height() - 10-pointex.y;
			SetCursor(AfxGetApp()->LoadCursor(IDC_CURTRG));
			InvalidateRect(&rect, TRUE);
		}
		else				// Cotes moving
		{	// set the rect1 for invalidation
			CRect rect1(m_MouseSource, m_MouseDest);
			CRect rect2(m_MouseSource, pointex);
			rect1.NormalizeRect();
			rect2.NormalizeRect();
			if (rect1.top  > rect2.top) rect1.top = rect2.top;
			if (rect1.left > rect2.left) rect1.left = rect2.left;
			if (rect1.right  < rect2.right) rect1.right = rect2.right;
			if (rect1.bottom < rect2.bottom) rect1.bottom = rect2.bottom;

			rect1.InflateRect(50,14);
			rect1 = rect1 - GetDeviceScrollPosition();
			// end of rect1 setup
			m_MouseDest = pointex;
			InvalidateRect(&rect1, TRUE);
		}
	}
	else
	{	CScopeDoc* pDoc = GetDocument();
		CRect rect;
		GetClientRect(&rect);
		// check if mouse over TriggerLevel line
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
		int i = rect.Height() - 10 - (int)(float)(pDoc->m_TriggerValue*pDoc->m_YFactor*MAX_ADCBITS/(pDoc->m_VoltageCorrection*5));
		if ((pDoc->m_TriggerMode==TRG_INT) && (pointex.x <= 70) && (rect.Height() - 10-pDoc->m_TriggerValue < pointex.y+2) && ((int)rect.Height() - 10-pDoc->m_TriggerValue > pointex.y-2))
		{	SetCursor(AfxGetApp()->LoadCursor(IDC_CURTRG));
			m_TrgMouseMode = TRUE;
		}
		else
		{	m_TrgMouseMode = FALSE;
			// check if mouse over Guideline
			if ((rect.Height() - 10-pDoc->m_GuideLine < pointex.y+2) && ((int)rect.Height() - 10-pDoc->m_GuideLine > pointex.y-2))
			{	SetCursor(AfxGetApp()->LoadCursor(IDC_CURTRG));
				m_GuideMode = TRUE;
			}
			else

			{	m_GuideMode = FALSE;

				 if ((rect.Height() - 10-pDoc->m_GuideLine2 < pointex.y+2) && ((int)rect.Height() - 10-pDoc->m_GuideLine2 > pointex.y-2))
				 	{SetCursor(AfxGetApp()->LoadCursor(IDC_CURTRG));
					 m_GuideMode2 = TRUE;
					}
				else
				{	m_GuideMode2 = FALSE;

					if ((rect.Height() - 10-pDoc->m_GuideLineZero < pointex.y+2) && ((int)rect.Height() - 10-pDoc->m_GuideLineZero > pointex.y-2))
						{SetCursor(AfxGetApp()->LoadCursor(IDC_CURTRG));
						 m_GuideModeZero = TRUE;
						}
					else
					{	m_GuideModeZero= FALSE;
					}
				}
			}
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran

		}
	}
	// show the mouse position
	CString szTemp;
	CMainFrame* pCMain = (CMainFrame*) GetParent();
	CEdit* pCEdit = (CEdit*) pCMain->m_wndDlgBar.GetDlgItem(IDC_EDITMOUSE1);
	szTemp.Format("x=%d  y=%d", pointex.x, pointex.y);
	pCEdit->SetWindowText(szTemp);

	CScrollView::OnMouseMove(nFlags, point);
}

void CScopeView::OnLButtonDown(UINT nFlags, CPoint point) 
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
{	if (!m_GuideMode && !m_TrgMouseMode&& !m_GuideMode2 && !m_GuideModeZero)
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
	{	SetCapture();
		CPoint pointex = point;
		pointex += GetDeviceScrollPosition();
		m_MouseSource = m_MouseDest = pointex;
		InvalidateRect(NULL, TRUE);
	}

	CScrollView::OnLButtonDown(nFlags, point);
}

void CScopeView::OnLButtonUp(UINT nFlags, CPoint point) 
{	m_MouseDest = m_MouseSource;
	InvalidateRect(NULL, TRUE);
	ReleaseCapture();
	
	CScrollView::OnLButtonUp(nFlags, point);
}

BOOL CScopeView::OnEraseBkgnd(CDC* pDC) 
{	return FALSE;	// this is part of implementation of flickerfree DC
}

void CScopeView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{	pDC->SetMapMode(MM_ISOTROPIC);
	pDC->SetWindowExt(1,1); 
	pDC->SetViewportExt(6,6);

	CScrollView::OnPrint(pDC, pInfo);
}
