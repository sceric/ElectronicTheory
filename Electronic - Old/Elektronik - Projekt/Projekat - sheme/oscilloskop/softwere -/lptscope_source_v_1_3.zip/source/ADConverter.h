// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
#if !defined(AFX_ADCONVERTER_H__F795B1B2_AA28_4634_A858_042DD12F3AC5__INCLUDED_)
#define AFX_ADCONVERTER_H__F795B1B2_AA28_4634_A858_042DD12F3AC5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ADConverter.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CADConverter dialog

class CADConverter : public CDialog
{
// Construction
public:
	CADConverter(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CADConverter)
	enum { IDD = IDD_DIALOG1 };
	short	m_Miran_Waiting;
	float	m_VoltCorrection;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CADConverter)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFont	m_fontBig;
	UINT	m_nTimerID;

	// Generated message map functions
	//{{AFX_MSG(CADConverter)
	afx_msg void OnDestroy();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnCustomdrawSliderAdc(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADCONVERTER_H__F795B1B2_AA28_4634_A858_042DD12F3AC5__INCLUDED_)
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran