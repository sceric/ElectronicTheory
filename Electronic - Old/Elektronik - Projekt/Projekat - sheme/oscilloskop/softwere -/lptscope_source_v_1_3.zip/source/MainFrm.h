// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__66669D5E_DD83_4686_9CCA_8B37FAF903B6__INCLUDED_)
#define AFX_MAINFRM_H__66669D5E_DD83_4686_9CCA_8B37FAF903B6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ScopeDoc.h"

// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
void MeasureSpeedPC(CScopeDoc * m_pDoc);
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran

// Controlling function for the worker thread.
UINT ReadThread(LPVOID pParam);
#define WM_USER_READ_DONE (WM_USER + 1)


class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	DWORD BytesReturned;
	DWORD piD;

	CDialogBar m_wndDlgBar;
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CToolBar    m_wndToolBar;

	INT		m_isRunning;	// for toolbar enabling/disabling
	UINT	m_nTimerID;
	CScopeDoc * m_pDoc;

// Generated message map functions
protected:
	LRESULT OnReadDone(WPARAM wParam, LPARAM lParam);
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnStart();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnTimeBaseLeft();
	afx_msg void OnTimeBaseRight();
	afx_msg void OnCustomDrawSliderTimeBase(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTrgOff();
	afx_msg void OnTrgInt();
	afx_msg void OnTrgExt();
	afx_msg void OnSlopeUp();
	afx_msg void OnSlopeDown();
	afx_msg void OnCustomdrawSliderY(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomdrawSliderVCorr(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnYbaseUp();
	afx_msg void OnYbaseDown();
	afx_msg void OnButtonDefault();
	afx_msg void OnBidirectionalTest();
	afx_msg void OnStop();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnUpdateTrgExt(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTrgInt(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTrgOff(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSlopeUp(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSlopeDown(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStart(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStop(CCmdUI* pCmdUI);
	afx_msg void OnClose();
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  
	afx_msg void OnChangebuffer();
	afx_msg void OnKillfocusbuffer();
	afx_msg void OnChangeSamplingRate();
	afx_msg void OnKillfocusSamplingRate();
	afx_msg void OnSaveConfig();
	afx_msg void OnOneRecord();
	afx_msg void OnTestAdc();
	afx_msg void OnDestroy();
	afx_msg void OnSaveConfigExit();
	afx_msg void OnUpdateSaveConfigExit(CCmdUI* pCmdUI);
	afx_msg void OnStartDemoMode();
	afx_msg void OnUpdateStartDemoMode(CCmdUI* pCmdUI);
	afx_msg void OnSpeedPc();
	afx_msg void OnUpdateSpeedPc(CCmdUI* pCmdUI);
	afx_msg void OnMaxtextbuffer();
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran 
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__66669D5E_DD83_4686_9CCA_8B37FAF903B6__INCLUDED_)
