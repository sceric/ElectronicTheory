// MainFrm.cpp : implementation of the CMainFrame class
//

 // Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Mira
#include <stdio.h>
 // Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Mira


#include "stdafx.h"
#include "LPTScope.h"


#include "MainFrm.h"
#include "Mmsystem.h"		// for multimedia timer functions (precise timings)
#include "IOManager.h"		// for LPT port access getting on WinNT/2k/XP
#include "conio.h"			// for LPT port writing/reading on Win95/98/ME
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
#include "ADConverter.h"
#include "InfoSpeed.h"
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
#include "math.h"			// sin function
#include "BidirectionalTest.h"
#include "windows.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


 // Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
		WORD Miran_Wait; //for wating cycle
		WORD Miran_Waiting = 1; //number waiting cycles for waiting to end measure TLC0820
		WORD Miran_Citac = 0; //cycles for compute Miran_Waiting
		WORD Miran_Citac_Uroven=0; // cycles for valid reading
		WORD Miran_Citac_Konec = 65000; //ending correction Miran_Waiting
		WORD Miran_Slider_Timebase;
		WORD Miran_SliderY;
		WORD Miran_SliderVcorr;
		FILE*fp; // declaration config file
		BOOLEAN Miran_cfg = FALSE;		// TRUE = cfg OK
		//WORD Miran_Memory_Citac=0;	// for Memory mode
		CString Miran_EditBoxString;
		DWORD Miran_SamplesBuffer;
		float Miran_SampleTime;
		float Miran_TimeFactor;
		BOOLEAN Save_Exit = TRUE;
		BOOLEAN Miran_SpeedPC = TRUE;
		BOOLEAN Miran_DemoSignal = TRUE;


// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_START, OnStart)
	ON_WM_SHOWWINDOW()
	ON_COMMAND(ID_TIMEBASELEFT, OnTimeBaseLeft)
	ON_COMMAND(ID_TIMEBASERIGHT, OnTimeBaseRight)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDERTIMEBASE, OnCustomDrawSliderTimeBase)
	ON_COMMAND(ID_TRG_OFF, OnTrgOff)
	ON_COMMAND(ID_TRG_INT, OnTrgInt)
	ON_COMMAND(ID_TRG_EXT, OnTrgExt)
	ON_COMMAND(ID_SLOPE_UP, OnSlopeUp)
	ON_COMMAND(ID_SLOPE_DOWN, OnSlopeDown)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDERY, OnCustomdrawSliderY)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDERVCORR, OnCustomdrawSliderVCorr)
	ON_COMMAND(ID_YBASEUP, OnYbaseUp)
	ON_COMMAND(ID_YBASEDOWN, OnYbaseDown)
	ON_BN_CLICKED(IDC_BUTTONDEFAULT, OnButtonDefault)
	ON_COMMAND(ID_BIDIRECTIONALTEST, OnBidirectionalTest)
	ON_COMMAND(ID_STOP, OnStop)
	ON_WM_TIMER()
	ON_UPDATE_COMMAND_UI(ID_TRG_EXT, OnUpdateTrgExt)
	ON_UPDATE_COMMAND_UI(ID_TRG_INT, OnUpdateTrgInt)
	ON_UPDATE_COMMAND_UI(ID_TRG_OFF, OnUpdateTrgOff)
	ON_UPDATE_COMMAND_UI(ID_SLOPE_UP, OnUpdateSlopeUp)
	ON_UPDATE_COMMAND_UI(ID_SLOPE_DOWN, OnUpdateSlopeDown)
	ON_UPDATE_COMMAND_UI(ID_START, OnUpdateStart)
	ON_UPDATE_COMMAND_UI(ID_STOP, OnUpdateStop)
	ON_WM_CLOSE()
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
	ON_EN_CHANGE(IDC_buffer, OnChangebuffer)
	ON_EN_KILLFOCUS(IDC_buffer, OnKillfocusbuffer)
	ON_EN_CHANGE(IDC_SamplingRate, OnChangeSamplingRate)
	ON_EN_KILLFOCUS(IDC_SamplingRate, OnKillfocusSamplingRate)
	ON_COMMAND(ID_SaveConfig, OnSaveConfig)
	ON_COMMAND(ID_OneRecord, OnOneRecord)
	ON_COMMAND(ID_TEST_ADC, OnTestAdc)
	ON_WM_DESTROY()
	ON_COMMAND(ID_SAVE_CONFIG_EXIT, OnSaveConfigExit)
	ON_UPDATE_COMMAND_UI(ID_SAVE_CONFIG_EXIT, OnUpdateSaveConfigExit)
	ON_COMMAND(ID_START_DEMO_MODE, OnStartDemoMode)
	ON_UPDATE_COMMAND_UI(ID_START_DEMO_MODE, OnUpdateStartDemoMode)
	ON_COMMAND(ID_SPEED_PC, OnSpeedPc)
	ON_UPDATE_COMMAND_UI(ID_SPEED_PC, OnUpdateSpeedPc)
	ON_EN_MAXTEXT(IDC_buffer, OnMaxtextbuffer)
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_USER_READ_DONE, OnReadDone)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_nTimerID  = 1;
	m_isRunning = 999;
}

CMainFrame::~CMainFrame()
{	
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.SetButtonStyle(3, m_wndToolBar.GetButtonStyle(3)|/*TBBS_GROUP|*/TBBS_CHECKGROUP);
	m_wndToolBar.SetButtonStyle(4, m_wndToolBar.GetButtonStyle(4)|TBBS_CHECKGROUP);
	m_wndToolBar.SetButtonStyle(5, m_wndToolBar.GetButtonStyle(5)|TBBS_CHECKGROUP);
	m_wndToolBar.SetButtonStyle(7, m_wndToolBar.GetButtonStyle(7)|/*TBBS_GROUP|*/TBBS_CHECKGROUP);
	m_wndToolBar.SetButtonStyle(8, m_wndToolBar.GetButtonStyle(8)|TBBS_CHECKGROUP);

	// Delete these three lines if you don't want the toolbar to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);


	// Create the bottom ControlDialog
	if (!m_wndDlgBar.Create(this, IDD_DLGBAR,
		CBRS_BOTTOM|CBRS_TOOLTIPS|CBRS_FLYBY, IDD_DLGBAR))
	{
		TRACE0("Failed to create DlgBar\n");
		return -1;      // fail to create
	}

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.style = cs.style & ~(FWS_ADDTOTITLE|FWS_PREFIXTITLE); 

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

//______________________________________________________________________________________________
// Program initialisation
void CMainFrame::OnShowWindow(BOOL bShow, UINT nStatus) 
{	CFrameWnd::OnShowWindow(bShow, nStatus);
	
	RECT rect;
	WORD wWidth,wHeight;
	rect.left = 0;
	rect.top = 0;
	rect.right = 1000;
	rect.bottom = 550;
	wWidth = GetSystemMetrics(SM_CXSCREEN);
	wHeight = GetSystemMetrics(SM_CYSCREEN);
	if(rect.right>wWidth) rect.right = wWidth;
	if(rect.bottom>wHeight) rect.bottom = wHeight;
	MoveWindow((wWidth / 2) - ((rect.right - rect.left) / 2), (wHeight / 2) - ((rect.bottom - rect.top) / 2), rect.right - rect.left, rect.bottom - rect.top, TRUE);

	BYTE b = 0;
	if (bShow)
	{	m_pDoc = (CScopeDoc*) GetActiveDocument();

		// Is this a WinNT based OS?
		OSVERSIONINFO osvi;
		osvi.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
		if (GetVersionEx (&osvi))
		{
			if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
			{   
			    LoadIOManager();			// If this is NT, run IO manager
			}
		}
		//_____________________________________________________________________________________
		// find out if this machine do have a bidirectional port
		// Put bit 5 of LPT1's control byte high and then check if bit5 realy turned high or hardware keep it locked low. This method is a partial check! works only on some PCs. 		
		_outp(890,255);
		_outp(890,255);
		b = _inp(890);
		b = b & 0x10;
		if (b == 0)
			MessageBox("Your LPT1 is NOT a bidirectional port.\nDo not use any input devices on it !\n\n(bit5 of contol port doesn't set to high)", "Warning", MB_ICONWARNING);

		//_____________________________________________________________________________________
		// initialisation of LPT1 if the case of ECP port
		// switch LPT1 to normal-write mode
		_outp(890,0);
		// if LPT1 is an ECP port then switch to byte mode. ECP is not working with bidirectional mode
		// read the Extended Control Register (ECR) 
		b = _inp(0x378+0x402);
		// set ECR to byte_mode
		b = b & 0x3F;
		b = b | 0x20;
		_outp(0x378+0x402, b);

// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
		if(fp=fopen("lptscope.cfg","rb"))
		{	fread(&Miran_Waiting, sizeof(Miran_Waiting), 1, fp);
			fread(&Miran_DemoSignal, sizeof(Miran_DemoSignal), 1, fp);
			fread(&m_pDoc->m_MAX_SAMPLES, sizeof(m_pDoc->m_MAX_SAMPLES), 1, fp);
			fread(&m_pDoc->m_TriggerValue, sizeof(m_pDoc->m_TriggerValue), 1, fp);
			fread(&m_pDoc->m_TriggerMode, sizeof(m_pDoc->m_TriggerMode), 1, fp);
			fread(&m_pDoc->m_isSlopeUp, sizeof(m_pDoc->m_isSlopeUp), 1, fp);
			fread(&Miran_Slider_Timebase, sizeof(Miran_Slider_Timebase), 1, fp);
			fread(&Miran_SliderY, sizeof(Miran_SliderY), 1, fp);
			fread(&Miran_SliderVcorr, sizeof(Miran_SliderVcorr), 1, fp);
			fread(&Save_Exit, sizeof(Save_Exit), 1, fp);
			fread(&Miran_SpeedPC, sizeof(Miran_SpeedPC), 1, fp);
			fread(&m_pDoc->m_usPerSample, sizeof(m_pDoc->m_usPerSample), 1, fp);
			fread(&m_pDoc->m_TimeFactor, sizeof(m_pDoc->m_TimeFactor), 1, fp);
			fread(&m_pDoc->m_GuideLine, sizeof(m_pDoc->m_GuideLine), 1, fp);
			fread(&m_pDoc->m_GuideLine2, sizeof(m_pDoc->m_GuideLine2), 1, fp);
			fread(&m_pDoc->m_GuideLineZero, sizeof(m_pDoc->m_GuideLineZero), 1, fp);
			Miran_cfg = TRUE;
			fclose(fp);
		}
		

		Miran_EditBoxString.Format("%.d", m_pDoc->m_MAX_SAMPLES);
		//DWORD Miran_P = m_pDoc->m_MAX_SAMPLES;
		if(Miran_SpeedPC)	MeasureSpeedPC(m_pDoc);
	//	m_pDoc->m_MAX_SAMPLES = Miran_P;
		

		CString szTemp;
		Miran_SamplesBuffer = m_pDoc->m_MAX_SAMPLES;
		CEdit* pCEdit1 = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_SamplingRate);
		szTemp.Format("%.2f", m_pDoc->m_usPerSample);
		pCEdit1->SetWindowText(szTemp);
		CEdit* pCEdit2 = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_buffer);
		szTemp.Format("%.d", Miran_SamplesBuffer);
		pCEdit2->SetWindowText(szTemp);
		m_pDoc->m_ScrollChange = TRUE;
	
 // Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran

		//_____________________________________________________________________________________
		// some additional initialisation
		CSliderCtrl* pCSlider;
		pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERTIMEBASE);
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran Miran Miran
		pCSlider->SetRange(1, 2000);		
		pCSlider->SetPos(Miran_Slider_Timebase);
		Miran_TimeFactor = 1;
		pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
		pCSlider->SetRange(1, 100);
		pCSlider->SetPos(Miran_SliderY);
		pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERVCORR);
		pCSlider->SetRange(2, 250);
		pCSlider->SetPos(Miran_SliderVcorr);
		//	---------------------------------------------------------------	
		//	Value Convert Table	|MIN	|DEFAULT	|MAX
		//	---------------------------------------------------------------
		//	IDC_SLIDERVCORR		|1		|10			|100
		//	m_VoltageCorrection	|0.1	|1			|10
		//	IDC_EDITVCORR		|0.2	|5			|25 maxVolts
		//	---------------------------------------------------------------
		//	IDC_SLIDERY			|1		|10			|100
		//	m_FactorY			|0.1	|1			|10
		//	IDC_EDITY			|195	|19.5		|1.95 mV/pix
		//	---------------------------------------------------------------
		//	IDC_SLIDERTIMEBASE	|1		|50			|2000
		//	m_TimeFactor		|~50	|1			|~0.025
		//	IDC_EDITTIMEBASE	|~220	|			|~0.11 �s/pix
		//	---------------------------------------------------------------	
	//m_pDoc->m_DemoSignal=FALSE;
	if(m_pDoc->m_DemoSignal)
	{m_pDoc->m_Draw = TRUE;
		DWORD nLoops;	
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran Miran Miran	
		// fill in the demo signal
		srand ((unsigned)time(NULL));
		switch(rand()%4)
		{
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran Miran Miran
		case 0:	// triangular
			for (nLoops=0; nLoops<m_pDoc->m_MAX_SAMPLES; nLoops++)
				m_pDoc->m_data[nLoops] = (BYTE)nLoops;
			break;
		case 1:	//sine 1
			for (nLoops=0; nLoops<m_pDoc->m_MAX_SAMPLES; nLoops++)
				m_pDoc->m_data[nLoops] = (BYTE)(127+(float)80 * sin((double)nLoops/58))+(BYTE)((float)20 * sin((double)nLoops/12));
			break;
		case 2:	// sine 2
			for (nLoops=0; nLoops<m_pDoc->m_MAX_SAMPLES; nLoops++)
				m_pDoc->m_data[nLoops] = (BYTE)((float)236 * sin((double)nLoops/50));
			break;
		case 3:	// random
			int i=0;
			for (nLoops=0; nLoops<m_pDoc->m_MAX_SAMPLES; nLoops++)
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran Miran Miran
			{	i += rand()%50;
				i -= rand()%50;
				if (i>255) i=235;
				if (i<0) i=20;
				m_pDoc->m_data[nLoops] = i;
			}
			break;
		}
	}
	
		
		// run the working thread for LPT1 reading and don't read anything untill "start" event fires
		m_pDoc->m_pReadWorkerThread = AfxBeginThread(ReadThread, (LPVOID)m_pDoc);
		m_pDoc->m_hwndNotifyReadDone = m_hWnd;
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran Miran Miran
		if(m_pDoc->m_DemoSignal)
			{m_pDoc->m_DemoSignal = rand()%8+1;
		     SetTimer(m_nTimerID, 20, NULL);
			}
	}  
}

void CMainFrame::OnTrgOff() 
{	m_pDoc->m_TriggerMode = TRG_OFF;
	m_pDoc->UpdateAllViews(NULL);
	Miran_cfg=FALSE;
}

void CMainFrame::OnTrgInt() 
{	m_pDoc->m_TriggerMode = TRG_INT;
	m_pDoc->UpdateAllViews(NULL);
	Miran_cfg=FALSE;
}

void CMainFrame::OnTrgExt() 
{	m_pDoc->m_TriggerMode = TRG_EXT;
	m_pDoc->UpdateAllViews(NULL);
	Miran_cfg=FALSE;
}

void CMainFrame::OnSlopeUp() 
{	m_pDoc->m_isSlopeUp = TRUE;
	Miran_cfg=FALSE;
}

void CMainFrame::OnSlopeDown() 
{	m_pDoc->m_isSlopeUp = FALSE;
	Miran_cfg=FALSE;
}
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran Miran Miran
void CMainFrame::OnCustomDrawSliderTimeBase(NMHDR* pNMHDR, LRESULT* pResult) 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERTIMEBASE);
	CEdit* pCEdit = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_EDITTIMEBASE);
	
	//m_pDoc->m_TimeFactor = (float)pCSlider->GetPos()/50;
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran 
	Miran_Slider_Timebase = pCSlider->GetPos();
	m_pDoc->m_TimeFactor = (float)50/pCSlider->GetPos();
	if(Miran_TimeFactor != m_pDoc->m_TimeFactor) 
		{Miran_TimeFactor = m_pDoc->m_TimeFactor;
		 m_pDoc->m_ScrollChange = TRUE;
		 Miran_cfg = FALSE;
		}
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran  

	CString szTemp;
	szTemp.Format("%.2f �s/pixel", m_pDoc->m_usPerSample / m_pDoc->m_TimeFactor);
	pCEdit->SetWindowText(szTemp);
	m_pDoc->UpdateAllViews(NULL);

	*pResult = 0;
}

void CMainFrame::OnCustomdrawSliderY(NMHDR* pNMHDR, LRESULT* pResult) 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
	CEdit* pCEdit = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_EDITY);
// Miran Miran Miran Miran  Miran Miran Miran Miran  
	Miran_SliderY=pCSlider->GetPos();
	Miran_cfg=FALSE;
// Miran Miran Miran Miran  Miran Miran Miran Miran  
	m_pDoc->m_YFactor = (float) pCSlider->GetPos() / 10;
	CString szTemp;
	szTemp.Format("%.2f mV/pixel", (5000*m_pDoc->m_VoltageCorrection)/(m_pDoc->m_YFactor*MAX_ADCBITS));
	pCEdit->SetWindowText(szTemp);
	m_pDoc->UpdateAllViews(NULL);
	
	*pResult = 0;
}

void CMainFrame::OnCustomdrawSliderVCorr(NMHDR* pNMHDR, LRESULT* pResult) 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERVCORR);
	CEdit* pCEdit = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_EDITVCORR);
// Miran Miran Miran Miran  Miran Miran Miran Miran 
	Miran_SliderVcorr=pCSlider->GetPos();
	Miran_cfg=FALSE; 
	m_pDoc->m_VoltageCorrection = (float) pCSlider->GetPos() / 50;
// Miran Miran Miran Miran  Miran Miran Miran Miran
	CString szTemp;
	szTemp.Format("max input:%.1fV", m_pDoc->m_VoltageCorrection * 5);
	pCEdit->SetWindowText(szTemp);
	
	// fix the Ybase value by invalidating the Ybase slider
	pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
	pCSlider->Invalidate();
	
	*pResult = 0;
}

void CMainFrame::OnYbaseUp() 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
	UINT i = pCSlider->GetPos();
	pCSlider->SetPos(i+1);
	
}

void CMainFrame::OnYbaseDown() 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
	UINT i = pCSlider->GetPos();
	pCSlider->SetPos(i-1);
}

void CMainFrame::OnTimeBaseLeft() 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERTIMEBASE);
	UINT i = pCSlider->GetPos();
	pCSlider->SetPos(i-1);
}

void CMainFrame::OnTimeBaseRight() 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERTIMEBASE);
	UINT i = pCSlider->GetPos();
	pCSlider->SetPos(i+1);
}

void CMainFrame::OnButtonDefault() 
{	CSliderCtrl* pCSlider;
	pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERTIMEBASE);
	pCSlider->SetPos(50);
	pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
	pCSlider->SetPos(10);
	pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERVCORR);
	pCSlider->SetPos(50);
}

void CMainFrame::OnUpdateTrgExt(CCmdUI* pCmdUI) 
{	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	pCmdUI->SetRadio(pDoc->m_TriggerMode == TRG_EXT);
}

void CMainFrame::OnUpdateTrgInt(CCmdUI* pCmdUI) 
{	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	pCmdUI->SetRadio(pDoc->m_TriggerMode == TRG_INT);
}

void CMainFrame::OnUpdateTrgOff(CCmdUI* pCmdUI) 
{	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	pCmdUI->SetRadio(pDoc->m_TriggerMode == TRG_OFF);
}

void CMainFrame::OnUpdateSlopeUp(CCmdUI* pCmdUI) 
{	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	if (pDoc->m_TriggerMode == TRG_INT)
		pCmdUI->SetRadio(pDoc->m_isSlopeUp);
	else
	{	pCmdUI->Enable(FALSE);
		pCmdUI->SetRadio(FALSE);
	}
}

void CMainFrame::OnUpdateSlopeDown(CCmdUI* pCmdUI) 
{	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	if (pDoc->m_TriggerMode == TRG_INT)
		pCmdUI->SetRadio(!pDoc->m_isSlopeUp);
	else
	{	pCmdUI->Enable(FALSE);
		pCmdUI->SetRadio(FALSE);
	}
}

void CMainFrame::OnUpdateStart(CCmdUI* pCmdUI) 
{	pCmdUI->Enable(m_isRunning != TRUE);
}

void CMainFrame::OnUpdateStop(CCmdUI* pCmdUI) 
{	pCmdUI->Enable(m_isRunning != FALSE);
}

void CMainFrame::OnStart() 
{	m_pDoc->m_DemoSignal = FALSE;
// Miran Miran Miran Miran  Miran Miran Miran Miran 
	m_pDoc->m_Draw = TRUE;
// Miran Miran Miran Miran  Miran Miran Miran Miran 
	m_isRunning = TRUE;
	KillTimer(m_nTimerID);
	SetTimer(m_nTimerID, 40, NULL);

}



void CMainFrame::OnStop() 
{	KillTimer(m_nTimerID);
	m_isRunning = FALSE;
}

void CMainFrame::OnClose() 
{/*	// Kill the active worker thread.
	// It's a good idea to wait for the worker thread to notify via a
	// "thread killed" event that it has killed itself. Otherwise, in the case
	// where the app is terminating, is possible (even if unlikely) that it
	// will detect a memory leak of the CWinThread object before the
	// CWinThread object has had a chance to auto-delete itself.
	OnStop();
	// Kill the worker thread by setting the "kill thread" event.
	SetEvent(m_pDoc->m_hEventKillThread);
	SetEvent(m_pDoc->m_hEventStartRead);
	WaitForSingleObject(m_pDoc->m_hEventThreadKilled, INFINITE);
*/	
	CFrameWnd::OnClose();
}

LRESULT CMainFrame::OnReadDone(WPARAM, LPARAM)
{	m_pDoc->UpdateAllViews(NULL);
	return 0;
}

void CMainFrame::OnBidirectionalTest() 
{	CBidirectionalTest dlgBT;
	BOOL bOK = TRUE;
	// Before calling BidirectionalTest, assure that signal reading really stoped.
	// We don't want to BidirectionalTest collide with acctual signal reading.
	if (!m_pDoc->m_DemoSignal)
	{	OnStop();
		if (WaitForSingleObject(m_pDoc->m_hEventReadDone, INFINITE) != WAIT_OBJECT_0)
			bOK = FALSE;
	}
	if (bOK) dlgBT.DoModal();
}

//_____________________________________________________________________________________________
// Standard timer function. Fires the ReadingThread, or alters the demo signal when in demo mode
void CMainFrame::OnTimer(UINT nIDEvent) 
{	DWORD nLoop;
	if (!m_pDoc->m_DemoSignal)	// if real signal (not demo)
	{	// start reading the LPT1
		SetEvent(m_pDoc->m_hEventStartRead);
	}
	else if (m_pDoc->m_DemoSignal == 1)		// if in demo mode do some signal shaking
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran Miran Miran 
	{	for (nLoop=0; nLoop<m_pDoc->m_MAX_SAMPLES; nLoop++)
			m_pDoc->m_data[nLoop] += (BYTE)nLoop;
		m_pDoc->UpdateAllViews(NULL);
	}
	else
	{	int offset=rand()%3-1;
		for (nLoop=0; nLoop<m_pDoc->m_MAX_SAMPLES; nLoop++)
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran Miran Miran
			m_pDoc->m_data[nLoop] += offset;
		m_pDoc->UpdateAllViews(NULL);
	}

	CFrameWnd::OnTimer(nIDEvent);
}

//______________________________________________________________________________________________
// working thread for bacground reading data from LPT1
UINT ReadThread(LPVOID pParam)
{	DWORD nLoop;
	CScopeDoc* pDoc = (CScopeDoc*) pParam;
	for(;;)
	{	// Wait for "start" event
		if (WaitForSingleObject(pDoc->m_hEventStartRead, INFINITE) != WAIT_OBJECT_0)
			break;

		// Exit the thread if the main application sets the kill event. 
		// The main application will set the "start" event before setting the "kill" event.
		if (WaitForSingleObject(pDoc->m_hEventKillThread, 0) == WAIT_OBJECT_0)
			break; // Terminate this thread by exiting this funct.

		// Reset event to indicate "not done", that is, reading is in progress.
		ResetEvent(pDoc->m_hEventReadDone);
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran Miran  Miran Miran 
		// Changing the priority helps a bit, but Win's kernel doesn't have a real real-time capabilities. This way we keep the program simple but not so precise. Making precise time measuring within windows is not an impossible task, but is close to be impossible.
		if (pDoc->m_isNT)
			{SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);			
			 SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL/*THREAD_PRIORITY_HIGHEST*/);
			}
		else
			
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL/*THREAD_PRIORITY_HIGHEST*/);
		

//	   if(pDoc->m_Miran_Memory_Mode==1) 
//		{Miran_Memory_Citac=Miran_Memory_Citac+1;
//		}
//	   if(Miran_Memory_Citac<2)
//	        {

		// Handle the trigger
		switch (pDoc->m_TriggerMode)
		{	case TRG_INT:
			{	//float current, previous;
				WORD current, previous;
				//previous = pDoc->m_isSlopeUp ? (float)9999999 : 0;
				previous = 10000;
				for (Miran_Wait=1; Miran_Wait<=Miran_Waiting; Miran_Wait++) _outp(890,255);
				for (nLoop=0; nLoop<pDoc->m_MAX_SAMPLES*3; nLoop++)
					{	for (Miran_Wait=1; Miran_Wait<=Miran_Waiting; Miran_Wait++) _outp(890,254);
						//current = (float)(_inp(888) * 5 * pDoc->m_VoltageCorrection)/MAX_ADCBITS;
						current = _inp(888);
						if (pDoc->m_isSlopeUp)
							if ((pDoc->m_TriggerValue/pDoc->m_YFactor) >= previous)
								if ((pDoc->m_TriggerValue/pDoc->m_YFactor) <= current)
									break;
						else
							if ((pDoc->m_TriggerValue/pDoc->m_YFactor) <= previous)
								if ((pDoc->m_TriggerValue/pDoc->m_YFactor) >= current)
									break;
						previous = current;
						_outp(890,255);
					}					
				break;
			}
			case TRG_EXT:		// external trigger fires at rising edge of Ack (pin10 of LPT1) wihich is 6th bit of Status port.
			{	BYTE current, previous = 0xFF;
				for (nLoop=0; nLoop<((pDoc->m_MAX_SAMPLES+pDoc->m_MAX_SAMPLES*Miran_Waiting)*9); nLoop++)

// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran Miran  Miran Miran 

					{	current = _inp(889);
						current = current & 0x40;
						if (previous == 0)
							if (current)
								break;
						previous = current;
					}				
				break;
			}
		}
		// end of trigger handling

		// read the data
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran Miran Miran  Miran Miran Miran Miran
			for (Miran_Wait=1; Miran_Wait<=Miran_Waiting; Miran_Wait++) _outp(890,255);	
			// set control port, bits 5 and 0 are used
			// bit5=bidrectionalON, bit0=pin1(strobe on LPT)=WR/RD on ADC
			// Changing the priority helps a bit, but Win's kernel doesn't have a real real-time capabilities. This way we keep the program simple but not so precise. Making precise time measuring within windows is not an impossible task, but is close to be impossible.
			//SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
			//SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL/*THREAD_PRIORITY_HIGHEST*/);
			for (nLoop=0; nLoop<pDoc->m_MAX_SAMPLES; nLoop++)
			{	
				for (Miran_Wait=1; Miran_Wait<=Miran_Waiting; Miran_Wait++) _outp(890,254);
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran

				pDoc->m_data[nLoop] = _inp(888);
				_outp(890,255);
			}	
			// get back to normal
			SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);		
		// end of reading the data
		
		// display the signal
		::PostMessage(pDoc->m_hwndNotifyReadDone, WM_USER_READ_DONE, 0, 0); // this is same as pDoc->UpdateAllViews(NULL);

		// notify that we finished with the reading
		SetEvent(pDoc->m_hEventReadDone);
	}
	SetEvent(pDoc->m_hEventThreadKilled);
	return 0;
}
	


// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
 

void CMainFrame::OnChangebuffer() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFrameWnd::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here


	
    CEdit* pCEdit2 = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_buffer);
	pCEdit2->GetWindowText(Miran_EditBoxString);
	if(atol(Miran_EditBoxString) > 1000000)
		{Miran_EditBoxString = "1000000";
		 pCEdit2->SetWindowText(Miran_EditBoxString);
		}
	

	
	
}

void CMainFrame::OnKillfocusbuffer() 
{
	// TODO: Add your control notification handler code here
  
  CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	Miran_SamplesBuffer = atol(Miran_EditBoxString);
	if(pDoc->m_MAX_SAMPLES != Miran_SamplesBuffer)
		{pDoc->m_MAX_SAMPLES = Miran_SamplesBuffer;
		 pDoc->m_ScrollChange = TRUE;
		 Miran_cfg=FALSE;
		}
  
}

void CMainFrame::OnChangeSamplingRate() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFrameWnd::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
//CEdit* pCEdit1 = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_SamplingRate);
//	szTemp.Format("%.1f", m_pDoc->m_usPerSample);
//	pCEdit1->SetWindowText(szTemp);
	
}

void CMainFrame::OnKillfocusSamplingRate() 
{
	// TODO: Add your control notification handler code here
	
}

void CMainFrame::OnSaveConfig() 
{
	// TODO: Add your command handler code here
	fp=fopen("lptscope.cfg","wb");
	fwrite(&Miran_Waiting, sizeof(Miran_Waiting), 1, fp);
	fwrite(&Miran_DemoSignal, sizeof(Miran_DemoSignal), 1, fp);
	fwrite(&m_pDoc->m_MAX_SAMPLES, sizeof(m_pDoc->m_MAX_SAMPLES), 1, fp);
	fwrite(&m_pDoc->m_TriggerValue, sizeof(m_pDoc->m_TriggerValue), 1, fp);
	fwrite(&m_pDoc->m_TriggerMode, sizeof(m_pDoc->m_TriggerMode), 1, fp);
	fwrite(&m_pDoc->m_isSlopeUp, sizeof(m_pDoc->m_isSlopeUp), 1, fp);
	fwrite(&Miran_Slider_Timebase, sizeof(Miran_Slider_Timebase), 1, fp);
	fwrite(&Miran_SliderY, sizeof(Miran_SliderY), 1, fp);
	fwrite(&Miran_SliderVcorr, sizeof(Miran_SliderVcorr), 1, fp);
	fwrite(&Save_Exit, sizeof(Save_Exit), 1, fp);
	fwrite(&Miran_SpeedPC, sizeof(Miran_SpeedPC), 1, fp);
	fwrite(&m_pDoc->m_usPerSample, sizeof(m_pDoc->m_usPerSample), 1, fp);
	fwrite(&m_pDoc->m_TimeFactor, sizeof(m_pDoc->m_TimeFactor), 1, fp);
	fwrite(&m_pDoc->m_GuideLine, sizeof(m_pDoc->m_GuideLine), 1, fp);
	fwrite(&m_pDoc->m_GuideLine2, sizeof(m_pDoc->m_GuideLine2), 1, fp);
	fwrite(&m_pDoc->m_GuideLineZero, sizeof(m_pDoc->m_GuideLineZero), 1, fp);
	fclose(fp);
	Miran_cfg = TRUE;
	
}

void CMainFrame::OnOneRecord() 
{
	// TODO: Add your command handler code here
	m_pDoc->m_DemoSignal = FALSE;
	m_pDoc->m_Draw = TRUE;
	KillTimer(m_nTimerID);
	m_isRunning = FALSE;
	SetEvent(m_pDoc->m_hEventStartRead);
	
}

void CMainFrame::OnTestAdc() 
{
	// TODO: Add your command handler code here
	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	CADConverter dlgAD;
	BOOL bOK = TRUE;
	// Before calling reaing AD Converter, assure that signal reading really stoped.
	
	OnStop();
	if (WaitForSingleObject(m_pDoc->m_hEventReadDone, INFINITE) != WAIT_OBJECT_0)
		bOK = FALSE;
	if (bOK)
	{dlgAD.m_Miran_Waiting = Miran_Waiting;
	 dlgAD.m_VoltCorrection= m_pDoc->m_VoltageCorrection;
	 if(dlgAD.DoModal() == IDOK)
		{Miran_Waiting = dlgAD.m_Miran_Waiting;
		 Miran_cfg = FALSE;
		 MeasureSpeedPC(m_pDoc);
		 CEdit* pCEdit = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_EDITTIMEBASE);
		 CString szTemp;
		 szTemp.Format("%.2f �s/pixel", m_pDoc->m_usPerSample / m_pDoc->m_TimeFactor);
		 pCEdit->SetWindowText(szTemp);
		 CEdit* pCEdit1 = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_SamplingRate);
		 szTemp.Format("%.2f", m_pDoc->m_usPerSample);
		 pCEdit1->SetWindowText(szTemp);
		 m_pDoc->UpdateAllViews(NULL);
		}
	}
}

void CMainFrame::OnDestroy() 
{
	CFrameWnd::OnDestroy();
	
	// TODO: Add your message handler code here
	if(!Miran_cfg)
		OnSaveConfig();
	
}

void CMainFrame::OnSaveConfigExit() 
{
	// TODO: Add your command handler code here
	Save_Exit = !Save_Exit;
	
}

void CMainFrame::OnUpdateSaveConfigExit(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	if(Save_Exit)
		pCmdUI->SetCheck(TRUE);
	else
		pCmdUI->SetCheck(FALSE);

	
}

void CMainFrame::OnStartDemoMode() 
{
	// TODO: Add your command handler code here
	Miran_DemoSignal = !Miran_DemoSignal;
}

void CMainFrame::OnUpdateStartDemoMode(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	if(Miran_DemoSignal)
		pCmdUI->SetCheck(TRUE);
	else
		pCmdUI->SetCheck(FALSE);
}

void CMainFrame::OnSpeedPc() 
{
	// TODO: Add your command handler code here
	Miran_SpeedPC =!Miran_SpeedPC;
}

void CMainFrame::OnUpdateSpeedPc(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(Miran_SpeedPC)
		pCmdUI->SetCheck(TRUE);
	else
		pCmdUI->SetCheck(FALSE);
}

void MeasureSpeedPC(CScopeDoc * m_pDoc) 
{	//_____________________________________________________________________________________
		
		CInfoSpeed* poDlg = new CInfoSpeed();
		poDlg->Create(IDD_DIALOG2);

	

		 //poDlg->ShowWindow(SW_SHOW);
	// Settings for measuring the speed of this PC
		TIMECAPS tc;
		if (timeGetDevCaps(&tc, sizeof (TIMECAPS)) != TIMERR_NOERROR)
			AfxMessageBox("Error gathering time capabilities of this machine");


		// Set time resolution to the minimum supported by the system
		DWORD resolution = min(max(tc.wPeriodMin, 0), tc.wPeriodMax);
		if (timeBeginPeriod(resolution) != TIMERR_NOERROR)
			AfxMessageBox("Error setting the time resolution for multimedia timer");
		
		DWORD nLoops; // how much loops we can make in measuring period
		
		// Changing the priority helps a bit, but Win's kernel doesn't have a real real-time capabilities. This way we keep the program simple but not so precise. Making precise time measuring within windows is not an impossible task, but is close to be impossible.
		if (m_pDoc->m_isNT)
			{SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
			 SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL/*THREAD_PRIORITY_HIGHEST*/);
			}
		else
			SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL/*THREAD_PRIORITY_HIGHEST*/);

		DWORD Zaloha = m_pDoc->m_MAX_SAMPLES;




		//----------------------------------- start of time measure
		DWORD MaxLoops;
		DWORD elapsed = timeGetTime();
   		// time measuring loop. Keep it similar as OnStart loop (in the meaning of timing).
			MaxLoops = 700000;
			for (nLoops=0; nLoops<MaxLoops; nLoops++)
			{	
				// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
				for (Miran_Wait=1; Miran_Wait<=Miran_Waiting; Miran_Wait++) _outp(890,254);
				// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran

				m_pDoc->m_data[10] = _inp(888);
				_outp(890,255);
			}
		
		//----------------------------------- end of time measure
		// get back to normal
		SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);
		SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);

		// calculation of time per sample. This variable is a base for all time values in the program
		m_pDoc->m_usPerSample = (float)(timeGetTime() - elapsed) * 1000 / MaxLoops;

		// destroy the efect of timeBeginPeriod
		if (timeEndPeriod(resolution) != TIMERR_NOERROR)
			AfxMessageBox("Error reseting MMTimer resolution");

		poDlg->DestroyWindow();

}

void CMainFrame::OnMaxtextbuffer() 
{
	// TODO: Add your control notification handler code here
	CMainFrame::OnKillfocusbuffer();
	m_pDoc->UpdateAllViews(NULL);
}
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran