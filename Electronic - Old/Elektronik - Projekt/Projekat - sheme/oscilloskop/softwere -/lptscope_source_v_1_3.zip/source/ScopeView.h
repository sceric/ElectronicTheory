// ScopeView.h : interface of the CScopeView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCOPEVIEW_H__6B1EB438_5D0E_42C8_8306_449968D50F2E__INCLUDED_)
#define AFX_SCOPEVIEW_H__6B1EB438_5D0E_42C8_8306_449968D50F2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CScopeView : public CScrollView
{
protected: // create from serialization only
	CScopeView();
	DECLARE_DYNCREATE(CScopeView)

// Attributes
public:
	CScopeDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScopeView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CScopeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	BOOL m_TrgMouseMode;
	BOOL m_GuideMode;
// Miran Miran Miran Miran  Miran Miran 
	BOOL m_GuideMode2;
	BOOL m_GuideModeZero;
// Miran Miran Miran Miran  Miran Miran 

	CPoint m_MouseSource;
	CPoint m_MouseDest;
	//{{AFX_MSG(CScopeView)
	afx_msg void OnLeft();
	afx_msg void OnRight();
	afx_msg void OnUp();
	afx_msg void OnDown();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ScopeView.cpp
inline CScopeDoc* CScopeView::GetDocument()
   { return (CScopeDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCOPEVIEW_H__6B1EB438_5D0E_42C8_8306_449968D50F2E__INCLUDED_)
