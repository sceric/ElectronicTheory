// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
// ADConverter.cpp : implementation file
//

#include "stdafx.h"
#include "lptscope.h"
#include "ADConverter.h"
//#include "pt_ioctl.h"		// for LPT port writing/reading on WinNT/2k/XP
#include "conio.h"			// for LPT port writing/reading on Win95/98/ME


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

WORD Mira_Wait; //for wating cycle
WORD Miran_Data;
BOOL OSVer;
//WORD Mira_Waiting; //number waiting cycles for waiting to end measure TLC0820

/////////////////////////////////////////////////////////////////////////////
// CADConverter dialog


CADConverter::CADConverter(CWnd* pParent /*=NULL*/)
	: CDialog(CADConverter::IDD, pParent)
{
	//{{AFX_DATA_INIT(CADConverter)
	m_Miran_Waiting = 0;
	m_VoltCorrection = 0.0f;
	//}}AFX_DATA_INIT
}


void CADConverter::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CADConverter)
	DDX_Text(pDX, IDC_ADC_EDIT, m_Miran_Waiting);
	DDX_Text(pDX, IDC_INPUT_VOLTAGE, m_VoltCorrection);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CADConverter, CDialog)
	//{{AFX_MSG_MAP(CADConverter)
	ON_WM_DESTROY()
	ON_WM_SHOWWINDOW()
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_ADC, OnCustomdrawSliderAdc)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CADConverter message handlers

void CADConverter::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	KillTimer(m_nTimerID);
	
}

void CADConverter::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	if (bShow)
	{	m_nTimerID  = 2;
		SetTimer(m_nTimerID, 300, NULL);
		// create bigger font. Default font is too small
		m_fontBig.CreateFont(
			48,	                       // nHeight
			0,                         // nWidth
			0,                         // nEscapement
			0,                         // nOrientation
			FW_NORMAL,                 // nWeight
			FALSE,                     // bItalic
			FALSE,                     // bUnderline
			0,                         // cStrikeOut
			ANSI_CHARSET,              // nCharSet
			OUT_DEFAULT_PRECIS,        // nOutPrecision
			CLIP_DEFAULT_PRECIS,       // nClipPrecision
			DEFAULT_QUALITY,           // nQuality
			DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
			"Arial");                 // lpszFacename	
			

		// initialisation of dialog controls
		CEdit * edit = (CEdit*) GetDlgItem(IDC_INPUT_VOLTAGE);
		edit->SetFont(&m_fontBig);

		CEdit * edit5 = (CEdit*) GetDlgItem(IDC_VOLTAGE);
		edit5->SetFont(&m_fontBig);

		CSliderCtrl* pCSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_ADC);
		pCSlider->SetRange(1, 50);
		pCSlider->SetPos(m_Miran_Waiting);
	}
	
}

void CADConverter::OnCustomdrawSliderAdc(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	

	CSliderCtrl* pCSlider = (CSliderCtrl*)GetDlgItem(IDC_SLIDER_ADC);
	CEdit* pCEdit = (CEdit*)GetDlgItem(IDC_ADC_EDIT);
	
	CString szTemp;
	m_Miran_Waiting=pCSlider->GetPos();
	szTemp.Format("%.1d ", (m_Miran_Waiting));
	pCEdit->SetWindowText(szTemp);
	




		
		
	

	
	*pResult = 0;
}

void CADConverter::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

		// Is this a WinNT based OS?
		OSVERSIONINFO osvi;
		osvi.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
		if (GetVersionEx (&osvi)) 
			if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
				OSVer = TRUE;
		// Changing the priority helps a bit, but Win's kernel doesn't have a real real-time capabilities. This way we keep the program simple but not so precise. Making precise time measuring within windows is not an impossible task, but is close to be impossible.
		SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
		SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL/*THREAD_PRIORITY_HIGHEST*/);

		for (Mira_Wait=1; Mira_Wait<=m_Miran_Waiting; Mira_Wait++) _outp(890,255);
								// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
				for (Mira_Wait=1; Mira_Wait<=m_Miran_Waiting; Mira_Wait++) _outp(890,254);
				// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran

				Miran_Data = _inp(888);
				_outp(890,255);			
		// get back to normal
		SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);
		SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);
		CString szTemp;
		CEdit* pCEdit1 = (CEdit*)GetDlgItem(IDC_INPUT_VOLTAGE);
		szTemp.Format("%.2f ", (BYTE(Miran_Data)*5*m_VoltCorrection/256));
		//szTemp.Format("%.1d ", Miran_Data);
		pCEdit1->SetWindowText(szTemp);
	
	CDialog::OnTimer(nIDEvent);
}
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran