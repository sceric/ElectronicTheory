// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
#if !defined(AFX_INFOSPEED_H__391AE257_A364_4F08_90E2_44DE3D59DC7E__INCLUDED_)
#define AFX_INFOSPEED_H__391AE257_A364_4F08_90E2_44DE3D59DC7E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InfoSpeed.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInfoSpeed dialog

class CInfoSpeed : public CDialog
{
// Construction
public:
	CInfoSpeed(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInfoSpeed)
	enum { IDD = IDD_DIALOG2 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInfoSpeed)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInfoSpeed)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INFOSPEED_H__391AE257_A364_4F08_90E2_44DE3D59DC7E__INCLUDED_)
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran