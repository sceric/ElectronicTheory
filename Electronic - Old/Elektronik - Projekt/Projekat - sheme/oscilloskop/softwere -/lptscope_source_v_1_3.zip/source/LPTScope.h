// LPTScope.h : main header file for the LPTSCOPE application
//

#if !defined(AFX_LPTSCOPE_H__07BB6CFB_79BF_44DB_8D5F_2B308BF62D46__INCLUDED_)
#define AFX_LPTSCOPE_H__07BB6CFB_79BF_44DB_8D5F_2B308BF62D46__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
// #define MAX_SAMPLES 6000	// how much samples within one ADC read cycle. Less for program speed, more for input signal logging on small frequencies.
// Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran Miran Miran Miran Miran  Miran
#define MAX_ADCBITS 256		// ADC resolution. It is not 256 when you have a resistor voltage divider on the analog input. For example, 10kOhm+100kOhm gives an ADC resolution around 230.

#define TRG_OFF 0			// trigger mode enum
#define TRG_INT 1
#define TRG_EXT	2

/////////////////////////////////////////////////////////////////////////////
// CScopeApp:
// See LPTScope.cpp for the implementation of this class
//

class CScopeApp : public CWinApp
{
public:
	CScopeApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScopeApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CScopeApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LPTSCOPE_H__07BB6CFB_79BF_44DB_8D5F_2B308BF62D46__INCLUDED_)
