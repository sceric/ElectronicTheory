//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LPTScope.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_LPTSCOTYPE                  129
#define IDD_DLGBAR                      130
#define IDC_EDIT1                       131
#define IDC_EDITTIMEBASE                131
#define IDC_EDIT_READ                   131
#define IDC_ADC_EDIT                    131
#define IDD_DLGBAR_UP                   133
#define IDC_CURTRG                      135
#define IDD_DIALOGTEST                  136
#define IDB_CONN2                       137
#define IDB_CONN3                       138
#define IDB_CONN9                       139
#define IDB_CONN4                       140
#define IDD_DIALOG1                     140
#define IDB_CONN5                       141
#define IDD_DIALOG2                     141
#define IDB_CONN6                       142
#define IDB_CONN7                       143
#define IDB_CONN8                       144
#define IDB_CONNEXT                     145
#define IDC_SLIDERTIMEBASE              1000
#define IDC_STATICTIMEBASE              1001
#define ID_STOP                         1002
#define ID_TRG_OFF                      1003
#define ID_TRG_INT                      1004
#define ID_TRG_EXT                      1005
#define ID_SLOPE_UP                     1006
#define ID_SLOPE_DOWN                   1007
#define IDC_SLIDER1                     1008
#define IDC_SLIDERY                     1008
#define IDC_SLIDER_ADC                  1008
#define IDC_STATICTRG                   1009
#define IDC_EDITMOUSE1                  1010
#define IDC_STATICY                     1011
#define ID_START                        1012
#define IDC_EDITY                       1013
#define IDC_SLIDERVCORR                 1014
#define IDC_STATICVCORR                 1015
#define IDC_EDITVCORR                   1016
#define IDC_BUTTONDEFAULT               1017
#define IDC_CONNECTOR                   1019
#define IDC_STATIC2                     1020
#define IDC_STATIC_READ                 1021
#define IDC_STATIC_BLINK                1022
#define IDC_STATIC_CONGRATULATE         1023
#define IDC_buffer                      1025
#define IDC_SamplingRate                1026
#define IDC_INPUT_VOLTAGE               1027
#define IDC_ADDRESSMAIL1                1028
#define IDC_ADDRESSMAIL                 1029
#define IDC_WEB                         1030
#define IDC_ADDRESSMAIL2                1031
#define IDC_VOLTAGE                     1032
#define ID_TIMEBASELEFT                 32772
#define ID_TIMEBASERIGHT                32773
#define ID_LEFT                         32774
#define ID_RIGHT                        32775
#define ID_UP                           32776
#define ID_DOWN                         32777
#define ID_YBASEUP                      32780
#define ID_YBASEDOWN                    32781
#define ID_BIDIRECTIONALTEST            32782
#define ID_MemoryMode                   32784
#define ID_SaveConfig                   32785
#define ID_OneRecord                    32786
#define ID_TEST_ADC                     32787
#define ID_SAVE_CONFIG_EXIT             32788
#define ID_START_DEMO_MODE              32789
#define ID_SPEED_PC                     32790

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32791
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
