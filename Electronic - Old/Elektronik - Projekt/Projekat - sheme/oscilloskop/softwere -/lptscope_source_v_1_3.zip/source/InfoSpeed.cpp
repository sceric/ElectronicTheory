// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran
// InfoSpeed.cpp : implementation file
//

#include "stdafx.h"
#include "lptscope.h"
#include "InfoSpeed.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInfoSpeed dialog


CInfoSpeed::CInfoSpeed(CWnd* pParent /*=NULL*/)
	: CDialog(CInfoSpeed::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInfoSpeed)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CInfoSpeed::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInfoSpeed)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInfoSpeed, CDialog)
	//{{AFX_MSG_MAP(CInfoSpeed)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInfoSpeed message handlers
// Miran Miran Miran Miran  Miran Miran Miran Miran  Miran Miran Miran Miran