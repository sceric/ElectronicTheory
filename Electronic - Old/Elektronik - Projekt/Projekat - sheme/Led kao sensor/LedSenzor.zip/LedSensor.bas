'****************************************************************
'*  Name    : LedSensor.BAS                                     *
'*  Author  : Kifo                                              *
'*  Notice  : Copyright (c) 2004 kifo                           *
'*          : All Rights Reserved                               *
'*  Date    : 15.01.2004                                        *
'*  Version : 1.0                                               *
'*  Notes   :                                                   *
'*          :                                                   *
'****************************************************************
    
    LedAnoda   var     GPIO.0
    LedKatoda  VAr     GPIO.1

'****************************************************************
    

            GPIO = 0
    		cmcon = 7                   ' comparator (off , set as digital IO )
            TRISIO = %00000000 			' set GP 1,2,3,4,5 as outputs
    		'WPU = %00110000            'pin gp3, gp4 - pull up enabled  
            'option_reg.7 = 0           'global GPPU bit - za pull up enabled = 0
            'ANSEL = %00010001	        'GP0 analog input , Fosc/8 ( A/D konverzija )
            'ADCON0 = %10000001         'chanel 0, stop AD, A/D On, Vdd = ref   
            'ANSEL=0				    'digital IO " samo za 12F675 "

'****************************************************************
            INTCON =  %00000000     	' Onemoguci prekide
            INTCON.2 = 0                ' brisanje flega prekoracenja  Tmr0
            option_reg = %10000111      ' timer 0 prescaler rate 1:256

'***************************************************************             

                    
            
    Main:   
            low     LedAnoda                    ' inverzni napon na led 
            high    LedKatoda                   ' led ne svijetli
   
            input   LedKatoda                   ' high Z na katodi led diode    

            tmr0 = 0                            ' reset timer 0 
       
 WaitLow:   if TMR0 > 50 then goto ukljuci      ' tu odre�ujemo razinu osvjetljenosti
            if LedKatoda = 1 then goto WaitLow  ' �ekamo kad padne nivo na nulu
            goto main                           '  ako ima dosta svjetla vra�amo se na main
                                                
 ukljuci:   high LedAnoda                       ' ako nema dosta svjetla upalimo led diodu
            Low  LedKatoda                      '
            
            Pause 400                           ' led svjetli 400ms
            
            goto main
            
            
            end    
