
<?php

if ($mail_sent) {$savenotes="0";}

if ($savenotes=="1") {
	$sqlfraga = 'UPDATE calls SET notes=\''.$notes.'\' WHERE date=\''.$date.'\'';
//        echo $sqlfraga;
	$db = mysql_connect("localhost", "cid","cidpasswd") or die("mysql_connect failed");
	mysql_select_db("cid",$db) or die("mysql_select_db failed");
	$notes_result = mysql_query($sqlfraga,$db) or die("mysql_query failed");
	$savenotes=0;
// echo $result;
}


$findme = '_';
//while ( ($pos = strpos($caller_name, $findme))!=NULL) {
//$caller_name[$pos] = "T";
//echo $pos."<br>";
//}
$adress = str_replace($findme,"<br>",$caller_name);


?>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">


<style type="text/css">
<!--
.text {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
}
--> </style>

<title>Inkommet samtal</title>
</head><body>
<table width="680" border="0">
  <tr bgcolor="#bbddff">
    <td width="88" bgcolor="bbddff" class="text">Nummer</td>
    <td width="582" bgcolor="bbddff" class="text"><?php echo $incomming_num;?></td>
	  </tr>
  <tr>
    <td class="text">Tidpunkt </td>
    <td class="text"><?php echo $date ?></td>
  </tr>
  <tr bgcolor="#0099FF">
    <td bgcolor="bbddff" class="text">Alias</td>
    <td bgcolor="#bbddff" class="text">
<?php
//	$sqlfraga = "select book.name, calls.notes, calls.date, calls.number FROM calls WHERE date="+$date+" LEFT OUTER JOIN book on calls.number=book.number ORDER BY calls.date DESC LIMIT 1";
	$sqlfraga = 'select book.name, calls.notes, calls.date, calls.number FROM calls,book WHERE calls.date = \''. $date .'\' AND calls.number= book.number LIMIT 1';
//echo $sqlfraga;
	$db = mysql_connect("localhost", "cid","cidpasswd") or die("mysql_connect failed");
	mysql_select_db("cid",$db) or die("mysql_select_db failed");
	$result = mysql_query($sqlfraga,$db) or die("mysql_query failed");
	$antkol = mysql_num_fields($result);
	//$kolnamn = mysql_list_fields($result);
	while ($myrow = mysql_fetch_row($result)) {
$alias = $myrow[0];
echo $alias;


?>


</td>
  </tr>
  <tr>
    <td><span class="text">Adress</span></td>
    <td><span class="text"><?php echo $adress;
?></span></td>
  </tr>
  <tr>
    <td bgcolor="bbddff" class="text">Noteringar</td>
    <td bgcolor="bbddff" class="text">
<?php
$mylink = '/cid/show_info.php?savenotes=1&caller_name='.$adress.'&date='.$date.'&incomming_num='.$incomming_num;
?>
<form ACTION="<?php echo $mylink; ?>" method="post">
<p>
<INPUT type="HIDDEN" name="savenotes" VALUE=1>
<INPUT type="HIDDEN" name="caller_name" VALUE="<?php echo $adress ?>">
<INPUT type="HIDDEN" name="date" VALUE="<?php echo $date ?>">
<INPUT type="HIDDEN" name="incomming_num" VALUE="<?php echo $incomming_num ?>">

<TEXTAREA name="notes" rows="5" cols="50">
<?php if ($myrow[1]=="") echo "NULL"; else echo $myrow[1]; }?>
</TEXTAREA><br> <?php $m=127;while($m--)echo '&nbsp'; ?> <INPUT style="font-size:9px" type="submit" value="spara">
<?php if ($notes_result==1) echo '<span style="color:009900">Sparad</span>' ?>
</P></form>
</td>
  </tr>
</table>
<p class="text">
<?php
$num = $incomming_num;
$inc_url = './chart/index_custom_number.php';
include $inc_url;
$date_form = str_replace(" ","&nbsp;",$date);

?>
<span style="font-family:verdana; font-size: 11px">

<form ACTION="../cgi/mail.php" method="get">
Mejla detta samtal till
<INPUT type="HIDDEN" name="caller_name" VALUE="<?php echo $adress ?>">
<INPUT type="HIDDEN" name="alias" VALUE="<?php echo $alias ?>">
<INPUT type="HIDDEN" name="date" VALUE="<?php echo $date_form ?>">
<INPUT type="HIDDEN" name="number" VALUE="<?php echo $incomming_num ?>">
<SELECT NAME="to" style="font-size:11px">
<OPTION SELECTED VALUE="bengt.sjoholm@gebit.se">Bengt
<OPTION VALUE="asjoholm@kth.se">Andy
<OPTION VALUE="lollo_sjoholm@hotmail.com">Lollo
</SELECT>
<INPUT type="submit" value="skicka" style="font-size:9px">
<?php if ($mail_sent==1) echo '<span style="color:119911; font-size:11; font-family:verdana">Skickat!</SPAN>'; ?>

</form></span>
<?php
// echo 'L�nk till denna sida: &nbsp; &nbsp;  '.$link;

?>

</p><p class="text"><a href="index.php">Tillbaka</a></p>
<?php
//echo 'Caller_name:'.$adress;
//echo '<br>Alias:'.$alias;
//echo '<br>DATE: '.$date;
//echo '<br>NUM: '.$incomming_num;

?>
</body></html>
