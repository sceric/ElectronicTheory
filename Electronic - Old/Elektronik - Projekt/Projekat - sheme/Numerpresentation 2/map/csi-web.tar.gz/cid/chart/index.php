<HTML>
<BODY bgcolor="#FFFFFF">
<?php
//include charts.php to access the InsertChart function.
 include "charts.php";
// echo InsertChart ( "charts.swf", "charts_library", "data_total_week.php?time=".microtime() );
echo "<p>";
echo InsertChart ( "charts.swf", "charts_library", "data_total_days.php?time=".microtime() );
echo InsertChart ( "charts.swf", "charts_library", "data_total_hours.php?time=".microtime() );
echo "<p>";
echo InsertChart ( "charts.swf", "charts_library", "data_custom_hours.php?time=".microtime() );
echo "<p>";
echo InsertChart ( "charts.swf", "charts_library", "data_latest_week.php?time=".microtime() );


?>

</BODY>
</HTML>
