<?php
include "charts.php";
$chart [ 'chart_type' ] = "line";

$days = array ("son", "mon","tis","ons","tor","fre","lor" ) ;
$dayofweek = (int)date("w");
$weekofyear = (int)date("W");
$year = (int)date("Y");
$chart [ 'chart_data' ][ 0 ][ 0 ] = "";
$chart [ 'chart_data' ][ 0 ][ 1 ] = $days[(($dayofweek+1)%7)];
$chart [ 'chart_data' ][ 0 ][ 2 ] = $days[(($dayofweek+2)%7)];
$chart [ 'chart_data' ][ 0 ][ 3 ] = $days[(($dayofweek+3)%7)];
$chart [ 'chart_data' ][ 0 ][ 4 ] = $days[(($dayofweek+4)%7)];
$chart [ 'chart_data' ][ 0 ][ 5 ] = $days[(($dayofweek+5)%7)];
$chart [ 'chart_data' ][ 0 ][ 6 ] = $days[(($dayofweek+6)%7)];
$chart [ 'chart_data' ][ 0 ][ 7 ] = $days[$dayofweek];
$chart [ 'chart_data' ][ 1 ][ 0 ] = "samtal senaste veckan";

$chart [ 'chart_data' ][ 1 ][ 1 ] = $days[(($dayofweek+1)%7)];
$chart [ 'chart_data' ][ 1 ][ 2 ] = $days[(($dayofweek+2)%7)];
$chart [ 'chart_data' ][ 1 ][ 3 ] = $days[(($dayofweek+3)%7)];
$chart [ 'chart_data' ][ 1 ][ 4 ] = $days[(($dayofweek+4)%7)];
$chart [ 'chart_data' ][ 1 ][ 5 ] = $days[(($dayofweek+5)%7)];
$chart [ 'chart_data' ][ 1 ][ 6 ] = $days[(($dayofweek+6)%7)];
$chart [ 'chart_data' ][ 1 ][ 7 ] = $days[$dayofweek];
$chart [ 'chart_data' ][ 2 ][ 0 ] = "veckan innan det";

//$chart [ 'chart_data' ][ 2 ][ 1 ]  = 7;

$conn = mysql_connect ( "127.0.0.1", "cid", "cidpasswd" );
mysql_select_db ( "cid" );

$yesdate = date("Y-m-d",strtotime ("-6 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 1 ][ 1 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-5 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 1 ][ 2 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-4 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 1 ][ 3 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-3 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 1 ][ 4 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-2 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 1 ][ 5 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-1 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 1 ][ 6 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)=CURDATE()");
$chart [ 'chart_data' ][ 1 ][ 7 ]  = (int) mysql_result($result,0,n);mysql_free_result($result);

//veckan innan det


$yesdate = date("Y-m-d",strtotime ("-13 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 2 ][ 1 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-12 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 2 ][ 2 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-11 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 2 ][ 3 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-10 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 2 ][ 4 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-9 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 2 ][ 5 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-8 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 2 ][ 6 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

$yesdate = date("Y-m-d",strtotime ("-7 day"));
$result = mysql_query ("select count(calls.date) as n from calls where DATE(calls.date)='$yesdate'");
$chart [ 'chart_data' ][ 2 ][ 7 ]  = (int) mysql_result($result,0,n);mysql_free_result($result);

mysql_close($conn);
 $chart [ 'chart_border' ] = array (   'top_thickness'     =>  0,
                                      'bottom_thickness'  =>  0,
                                      'left_thickness'    =>  0,
                                      'right_thickness'   =>  0,
                                   );
$chart [ 'chart_grid_h' ] = array (   'thickness'  =>  1,
                                      'color'      =>  "222222",
                                      'alpha'      =>  15,
                                      'type'       =>  "dashed"
                                   );
$chart [ 'chart_pref' ] = array (   'line_thickness'  =>  2,  
                                    'point_shape'     =>  "square", 
                                    'fill_shape'      =>  true
                                  );
$chart [ 'chart_rect' ] = array ( 'x'=>15,
                                  'y'=>40,
                                  'width'=>370,
                                  'height'=>180,
                                  'positive_color'  =>  "DDDDFF",
                                  'positive_alpha'  =>  75,
                                );

$chart [ 'series_color' ] = array ( "1111dd", "EEEEFF" );
SendChartData ( $chart );
?>
