
<?php
include "charts.php";
$chart [ 'chart_type' ] = "line";

$chart [ 'chart_data' ][ 0 ][ 0 ] = "";
$chart [ 'chart_data' ][ 0 ][ 1 ] = "mon";
$chart [ 'chart_data' ][ 0 ][ 2 ] = "tis";
$chart [ 'chart_data' ][ 0 ][ 3 ] = "ons";
$chart [ 'chart_data' ][ 0 ][ 4 ] = "tor";
$chart [ 'chart_data' ][ 0 ][ 5 ] = "fre";
$chart [ 'chart_data' ][ 0 ][ 6 ] = "lor";
$chart [ 'chart_data' ][ 0 ][ 7 ] = "son";
$chart [ 'chart_data' ][ 1 ][ 0 ] = 'samtal per veckodag for '.$number;

$conn = mysql_connect ( "127.0.0.1", "cid", "cidpasswd" );
mysql_select_db ( "cid" );

$result = mysql_query ("select count(calls.date) as n from calls where calls.number = $number AND DAYNAME(calls.date)=0");
$chart [ 'chart_data' ][ 1 ][ 1 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where calls.number = $number AND DAYNAME(calls.date)=1");
$chart [ 'chart_data' ][ 1 ][ 2 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where calls.number = $number AND DAYNAME(calls.date)=2");
$chart [ 'chart_data' ][ 1 ][ 3 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where calls.number = $number AND DAYNAME(calls.date)=3");
$chart [ 'chart_data' ][ 1 ][ 4 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where calls.number = $number AND DAYNAME(calls.date)=4");
$chart [ 'chart_data' ][ 1 ][ 5 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where calls.number=$number AND DAYNAME(calls.date)=5");
$chart [ 'chart_data' ][ 1 ][ 6 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where calls.number=$number AND DAYNAME(calls.date)=6");
$chart [ 'chart_data' ][ 1 ][ 7 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);

mysql_close($conn);
$chart [ 'chart_border' ] = array (   'top_thickness'     =>  0,
                                      'bottom_thickness'  =>  0,
                                      'left_thickness'    =>  0,
                                      'right_thickness'   =>  0,
                                   );
$chart [ 'chart_grid_h' ] = array (   'thickness'  =>  1,
                                      'color'      =>  "222222",
                                      'alpha'      =>  15,
                                      'type'       =>  "dashed"
                                   );
$chart [ 'chart_pref' ] = array (   'line_thickness'  =>  2,  
                                    'point_shape'     =>  "none", 
                                    'fill_shape'      =>  false
                                  );
$chart [ 'chart_rect' ] = array ( 'x'=>25,
                                  'y'=>40,
                                  'width'=>360,
                                  'height'=>180,
                                  'positive_color'  =>  "BFDFFF",
                                  'positive_alpha'  =>  75,
                                );

$chart [ 'series_color' ] = array ( "1111cc", "CCCCFF" );

SendChartData ( $chart );
?>
