<?php
include "charts.php";
 

$chart [ 'chart_type' ] = "line";

$chart [ 'chart_data' ][ 0 ][ 0 ] = "";
$chart [ 'chart_data' ][ 0 ][ 1 ] = "2001";
$chart [ 'chart_data' ][ 0 ][ 2 ] = "2002";
$chart [ 'chart_data' ][ 0 ][ 3 ] = "2003";
$chart [ 'chart_data' ][ 0 ][ 4 ] = "2004";
$chart [ 'chart_data' ][ 0 ][ 5 ] = "2005";
$chart [ 'chart_data' ][ 0 ][ 6 ] = "2006";
$chart [ 'chart_data' ][ 0 ][ 7 ] = "2007";
$chart [ 'chart_data' ][ 0 ][ 8 ] = "2008";
$chart [ 'chart_data' ][ 0 ][ 9 ] = "2009";
$chart [ 'chart_data' ][ 1 ][ 10 ] = "Region A";
$chart [ 'chart_data' ][ 1 ][ 1 ] = 5;
$chart [ 'chart_data' ][ 1 ][ 2 ] = 10;
$chart [ 'chart_data' ][ 1 ][ 3 ] = 30;
$chart [ 'chart_data' ][ 1 ][ 4 ] = 63;
$chart [ 'chart_data' ][ 2 ][ 0 ] = "Region B";
$chart [ 'chart_data' ][ 2 ][ 1 ] = 100;
$chart [ 'chart_data' ][ 2 ][ 2 ] = 20;
$chart [ 'chart_data' ][ 2 ][ 3 ] = 65;
$chart [ 'chart_data' ][ 2 ][ 4 ] = 55;
$chart [ 'chart_data' ][ 3 ][ 0 ] = "Region C";
$chart [ 'chart_data' ][ 3 ][ 1 ] = 56;
$chart [ 'chart_data' ][ 3 ][ 2 ] = 21;
$chart [ 'chart_data' ][ 3 ][ 3 ] = 5;
$chart [ 'chart_data' ][ 3 ][ 4 ] = 90;
$chart [ 'chart_data' ][ 3 ][ 5 ] = 191;
$chart [ 'chart_data' ][ 3 ][ 6 ] = 192;
$chart [ 'chart_data' ][ 3 ][ 7 ] = 193;
$chart [ 'chart_data' ][ 3 ][ 8 ] = 194;
$chart [ 'chart_data' ][ 3 ][ 9 ] = 195;
$chart [ 'chart_data' ][ 3 ][ 10 ] = 196;



SendChartData ( $chart );

?>
