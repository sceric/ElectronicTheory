<?php
include "charts.php";
$chart [ 'chart_type' ] = "line";

$chart [ 'chart_data' ][ 0 ][ 0 ] = "";
$chart [ 'chart_data' ][ 0 ][ 1 ] = "00-01";
$chart [ 'chart_data' ][ 0 ][ 2 ] = "01-02";
$chart [ 'chart_data' ][ 0 ][ 3 ] = "02-03";
$chart [ 'chart_data' ][ 0 ][ 4 ] = "03-04";
$chart [ 'chart_data' ][ 0 ][ 5 ] = "04-05";
$chart [ 'chart_data' ][ 0 ][ 6 ] = "05-06";
$chart [ 'chart_data' ][ 0 ][ 7 ] = "06-07";
$chart [ 'chart_data' ][ 0 ][ 8 ] = "07-08";
$chart [ 'chart_data' ][ 0 ][ 9 ] = "08-09";
$chart [ 'chart_data' ][ 0 ][ 10 ] = "09-10";
$chart [ 'chart_data' ][ 0 ][ 11 ] = "10-11";
$chart [ 'chart_data' ][ 0 ][ 12 ] = "11-12";
$chart [ 'chart_data' ][ 0 ][ 13 ] = "12-13";
$chart [ 'chart_data' ][ 0 ][ 14 ] = "13-14";
$chart [ 'chart_data' ][ 0 ][ 15 ] = "14-15";
$chart [ 'chart_data' ][ 0 ][ 16 ] = "15-16";
$chart [ 'chart_data' ][ 0 ][ 17 ] = "16-17";
$chart [ 'chart_data' ][ 0 ][ 18 ] = "17-18";
$chart [ 'chart_data' ][ 0 ][ 19 ] = "18-19";
$chart [ 'chart_data' ][ 0 ][ 20 ] = "19-20";
$chart [ 'chart_data' ][ 0 ][ 21 ] = "20-21";
$chart [ 'chart_data' ][ 0 ][ 22 ] = "21-22";
$chart [ 'chart_data' ][ 0 ][ 23 ] = "22-23";
$chart [ 'chart_data' ][ 0 ][ 24 ] = "23-00";
$chart [ 'chart_data' ][ 1 ][ 0 ] = "totalt: samtal uppdelade per timme";

$conn = mysql_connect ( "127.0.0.1", "cid", "cidpasswd" );
mysql_select_db ( "cid" );

$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=0");
$chart [ 'chart_data' ][ 1 ][ 1 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=1");
$chart [ 'chart_data' ][ 1 ][ 2 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=2");
$chart [ 'chart_data' ][ 1 ][ 3 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=3");
$chart [ 'chart_data' ][ 1 ][ 4 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=4");
$chart [ 'chart_data' ][ 1 ][ 5 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=5");
$chart [ 'chart_data' ][ 1 ][ 6 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=6");
$chart [ 'chart_data' ][ 1 ][ 7 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=7");
$chart [ 'chart_data' ][ 1 ][ 8 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=8");
$chart [ 'chart_data' ][ 1 ][ 9 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=9");
$chart [ 'chart_data' ][ 1 ][ 10 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=10");
$chart [ 'chart_data' ][ 1 ][ 11 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=11");
$chart [ 'chart_data' ][ 1 ][ 12 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=12");
$chart [ 'chart_data' ][ 1 ][ 13 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=13");
$chart [ 'chart_data' ][ 1 ][ 14 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=14");
$chart [ 'chart_data' ][ 1 ][ 15 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=15");
$chart [ 'chart_data' ][ 1 ][ 16 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=16");
$chart [ 'chart_data' ][ 1 ][ 17 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=17");
$chart [ 'chart_data' ][ 1 ][ 18 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=18");
$chart [ 'chart_data' ][ 1 ][ 19 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=19");
$chart [ 'chart_data' ][ 1 ][ 20 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=20");
$chart [ 'chart_data' ][ 1 ][ 21 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=21");
$chart [ 'chart_data' ][ 1 ][ 22 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=22");
$chart [ 'chart_data' ][ 1 ][ 23 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);
$result = mysql_query ("select count(calls.date) as n from calls where HOUR(calls.date)=23");
$chart [ 'chart_data' ][ 1 ][ 24 ]  = (int) mysql_result($result,0,"n");mysql_free_result($result);




mysql_close($conn);
$chart [ 'chart_border' ] = array (   'top_thickness'     =>  0,
                                      'bottom_thickness'  =>  0,
                                      'left_thickness'    =>  0,
                                      'right_thickness'   =>  0,
                                   );
$chart [ 'chart_grid_h' ] = array (   'thickness'  =>  1,
                                      'color'      =>  "222222",
                                      'alpha'      =>  15,
                                      'type'       =>  "dashed"
                                   );
$chart [ 'chart_pref' ] = array (   'line_thickness'  =>  2,  
                                    'point_shape'     =>  "none",
                                    'fill_shape'      =>  true
                                  );
$chart [ 'chart_rect' ] = array ( 'x'=>25,
                                  'y'=>40,
                                  'width'=>360,
                                  'height'=>180,
                                  'positive_color'  =>  "DDDDFF",
                                  'positive_alpha'  =>  75,
                                );

$chart [ 'series_color' ] = array ( "1111dd", "CCCCFF" );

SendChartData ( $chart );
?>
