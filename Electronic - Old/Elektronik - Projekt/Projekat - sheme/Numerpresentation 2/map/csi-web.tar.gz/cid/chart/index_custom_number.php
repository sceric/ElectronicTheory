<?php
if ($num=="") $num="087686864";
 include "./chart/charts.php";
echo '<br>';
echo InsertChart ( "./chart/charts.swf", "./chart/charts_library", "./chart/custom_data_total_days.php?alias=$alias&number=$num&time=".microtime());
echo InsertChart ( "./chart/charts.swf", "./chart/charts_library", "./chart/custom_data_total_hours.php?alias=$alias&number=$num&time=".microtime());
echo '<br>';
?>
