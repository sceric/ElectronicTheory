 <html><head><title>Calls</title></head><body><div style="font-size:10">
<?php
        $db = mysql_connect("localhost", "cid","cidpasswd");
        mysql_select_db("cid",$db);
        $sqlsats ="select count('date') FROM calls";
        $result = mysql_query($sqlsats,$db);
	  echo "<b>Antal samtal totalt: </b>";
	  $myrow= mysql_fetch_row($result);
	  echo $myrow[0]; echo "<br>";
	  
	  $sqlsats ="select count('number') FROM book";
        $result = mysql_query($sqlsats,$db);
	  echo "<b>Antal namn inlagda i telefonbok: </b>";
	  $myrow= mysql_fetch_row($result);
	  echo $myrow[0]; echo "<p>";
	  
	 
	  $sqlsats ="select count(*) as antal,book.name,calls.number FROM calls,book WHERE calls.number=book.number group by calls.number order by antal desc limit 10";
        $result = mysql_query($sqlsats,$db);?>
			<b>De 10 som ringt flest g�nger:</b>
			<table cellspacing=0 border=0 font=verdana style="font-size:10;font-family:verdana" >
			<tr style="background-color:#CCF;font-weight: bold"><td>Antal</td><td>Namn</td><td>Nummer</td></tr>
<?php
	  $farg=0; while ($myrow = mysql_fetch_row($result)) {
		if ($farg==1) {echo "<tr style=\"background-color:#CCF\"><td>";$farg=0;} else
		{echo "<tr style=\"background-color:#FFF\"><td>";$farg=1;}
		echo $myrow[0];echo "</trd";
		echo "<td>";echo $myrow[1];echo "</td>";
		echo "<td>";echo $myrow[2];echo "</td></tr>";
	  
	}
	echo "</table><p>";
	  $sqlsats = "select * from book where number not in (select number from calls) order by name";
        $result = mysql_query($sqlsats,$db);?>
			<b>Nummer i telefonboken som inte ringt n�gon g�ng:</b>
			<table cellspacing=0 border=0 font=verdana style="font-size:10;font-family:verdana" >
			<tr style="background-color:#CCF;font-weight: bold"><td>Nummer</td><td>Namn</td></tr>
<?php
	  $farg=0; while ($myrow = mysql_fetch_row($result)) {
		if ($farg==1) {echo "<tr style=\"background-color:#CCF\"><td>";$farg=0;} else
{echo "<tr style=\"background-color:#FFF\"><td>";$farg=1;}
		echo $myrow[0];echo "</td";
		echo "<td>";echo $myrow[1];echo "</td></tr>";
		
	  
}
	echo "</table><p>";
	  $sqlsats = "select number from calls where number not in (select number from book)";
        $result = mysql_query($sqlsats,$db);?>
			<b>Nummer i telefonboken som inte ringt n�gon g�ng:</b>
			<table cellspacing=0 border=0 font=verdana style="font-size:10;font-family:verdana" >
			<tr style="background-color:#CCF;font-weight: bold"><td>Nummer</td></tr>
<?php
	  $farg=0; while ($myrow = mysql_fetch_row($result)) {
		if ($farg==1) {echo "<tr style=\"background-color:#CCF\"><td>";$farg=0;} else
{echo "<tr style=\"background-color:#FFF\"><td>";$farg=1;}
		
		echo $myrow[0];echo "</td></tr>";
		
	  
}
if ($dayinterval==0) {$dayinterval=60;}
echo "</table><p>";
	  $sqlsats = "select distinct calls.number,name from calls,book where calls.number=book.number and calls.number not in (select distinct number from calls where calls.date > DATE_SUB(now(), INTERVAL '$dayinterval' day)) order by name";
        $result = mysql_query($sqlsats,$db);?>
			<b>Nummer som inte ringt de senaste <i><?php echo $dayinterval?> </i>dagarna: </b>
			<form method="POST" action="query.php"><input style="font-family:verdana;font-size:9" size="3" type="Text" name="dayinterval">
			<input style="font-family:verdana;font-size:9" type="submit" value="dagarna"></form>
			<table cellspacing=0 border=0 font=verdana style="font-size:10;font-family:verdana" >
			<tr style="background-color:#CCF;font-weight: bold"><td>Nummer</td><td>Namn</td></tr>
<?php
	  $farg=0; while ($myrow = mysql_fetch_row($result)) {
		if ($farg==1) {echo "<tr style=\"background-color:#CCF\"><td>";$farg=0;} else
{echo "<tr style=\"background-color:#FFF\"><td>";$farg=1;}
		
		echo $myrow[0];echo "&nbsp;&nbsp;&nbsp;</td>";echo "<td>";echo $myrow[1];echo "</td></tr>";
		
	  
}



?></table><p><a style="font-size:10;font-family:verdana" href="javascript:history.go(-1)">Tillbaka</a</div> </body></html>