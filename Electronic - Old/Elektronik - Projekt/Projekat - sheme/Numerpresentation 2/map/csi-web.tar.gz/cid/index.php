 <html><head><title>Calls</title></head><body>
<?
if ($rm!="") {
echo "<div style=\"font-size:10\">Posten '$rm' borttagen</div>";
$db = mysql_connect("localhost", "cid","cidpasswd");
        mysql_select_db("cid",$db);
        $sqlsats ="DELETE FROM calls WHERE date='$rm'";
        $res = mysql_query($sqlsats,$db);
}
// OKEJ.. H�R KOMMER KODEN F�R ATT VISA SAMTAL, HTML B�RJAR

 
//<div style="font-size:10">Namn:  <select name="namn" style="font-size:10">
 
 //<form method="POST" action="search.php">
 //<div style="font-size:10">Namn:  <select name="namn" style="font-size:10">
  //<?php
   //     $db = mysql_connect("localhost", "cid","cidpasswd");
    //    mysql_select_db("cid",$db);
     //   $sqlsats ="SELECT name FROM book ORDER BY name";
      //  $result = mysql_query($sqlsats,$db);
       // while ($myrow = mysql_fetch_row($result)) {
        //        if ($myrow[0]!="") {
//		echo "<option value=\"";
 //               printf($myrow[0]);
  //              echo "\">$myrow[0]\n";}         
//}
  
  //</select><input type="submit" name="submit" style="font-size:10;font-family:verdana" value="visa samtal"></form></div>
 // OKEJ H�R SLUTAR DEN KODEN
?>
<table cellspacing=0 border=0 font=verdana style="font-size:10;font-family:verdana" >

<tr style="background-color:#bbddff;font-weight: 
bold"><td>Datum</td><td>Namn</td><td>Nummer</td><td></td><td></td></tr>
<?php
	if ($name!="") {
	echo "<div style=\"font-weight: bold;font-size:10;font-family:verdana\">";
	echo $number;
	echo " sparad som ";
	echo $name;
	echo ".</div>";
	
	 $db = mysql_connect("localhost", "cid","cidpasswd");
  	mysql_select_db("cid",$db);
  $sql = "update book set name='$name' where number='$number'";
 $result = mysql_query($sql);
	}

	
	
	
	
	
	
	$sqlfraga = "select calls.date, book.name,calls.number FROM calls LEFT OUTER JOIN book 
on calls.number=book.number ORDER BY calls.date DESC LIMIT 30";
	$db = mysql_connect("localhost", "cid","cidpasswd") or die("mysql_connect failed");
	$color=0;
	$add=0;
	mysql_select_db("cid",$db) or die("mysql_select_db failed");
	$result = mysql_query($sqlfraga,$db) or die("mysql_query failed");
	$antkol = mysql_num_fields($result);
	//$kolnamn = mysql_list_fields($result);
	while ($myrow = mysql_fetch_row($result)) {
		
		if ($color==0) {echo "<tr style=\"background-color:#FFF\">"; $color=1;}
		else{echo "<tr style=\"background-color:#bbddff\">"; $color=0;}
		for($i=0;$i<$antkol; $i=($i+1)){
		echo "<td>";
		$numtosave=$myrow[2];
		$numtorm=$myrow[0];
		if ($i==1) {
			if (($myrow[1]=="")&&($myrow[2]!="Dolt nummer"))  {
				$add=1;$numtosave=$myrow[2];} else {printf($myrow[$i]); echo "&nbsp;&nbsp;&nbsp;&nbsp;</td>";}}
				 else {
			printf($myrow[$i]);
		echo "&nbsp;&nbsp;&nbsp;&nbsp;</td>";
		}
		
	}
		
			if ($myrow[2]!="Dolt nummer") {
			?>
			<td>
			<a href="../cgi/info.cgi?date=<?php echo $myrow[0]?>&submit=submit&number=<?php echo $numtosave?>" border=0>Info:<img src="12.gif"ALT="DELETE" border=0 
width=12 heigth=12></A></td><? }
?> <td> &nbsp; &nbsp;<a href="index.php?rm=<?php echo $numtorm?>" alt=DELETE"><img src="rm.gif" alt="DELETE" width=12 heigth=12 border=0></td>
<?
		if ($add==1) {

			?><td>
			<form align="center" method="POST" action="<?php echo $PHP_SELF ?>" >L�gg till som 
			<input style="font-family:verdana;font-size:9" type="Text" name="name">
			<input TYPE="hidden" VALUE="<?php echo $numtosave?>" NAME="number">					
			<input style="font-family:verdana;font-size:9" type="submit" value="OK">
			</td>
			</form>
			<?
					
			$add=0;
		}
	echo "</tr>";
	}//for

?></table><p><div style="font-size:11">
<hr><span style="font-family: verdana; ">
 <form method="POST" action="search.php" >S�k namn:
			<input style="font-family:verdana;font-size:9" type="Text" name="namnet">
			<input style="font-family:verdana;font-size:9" type="submit" value="OK">
			</form>
 <span style="font-size:10;color:red"><a style="font-size:10;color:blue" href="query.php">Se statistik</a></span>

&nbsp; &nbsp; <a href="chart/index.php">Diagram</a><br><hr>
DEBUG INFO<br>
<?
echo "lsmod|grep csi: ";
echo exec('lsmod|grep csi');

echo "<br>ps -C csid u: <br>USER PID %CPU %MEM VSZ RSS TTY STAT START TIME CMD<br>";
echo exec('ps -C csid u');
   echo "<br>index.php was last changed: " . date("F d Y H:i:s.", filectime('./index.php'));
?>
</div></span></body></html>

