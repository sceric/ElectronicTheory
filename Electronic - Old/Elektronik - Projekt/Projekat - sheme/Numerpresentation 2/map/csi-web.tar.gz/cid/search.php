<?php
if ($namnet=="") {echo "<div font=verdana style=\"font-size:10;font-family:verdana\">";
?>
<form method="POST" action="<?php echo $PHP_SELF ?>" >S�k namn:
			<input style="font-family:verdana;font-size:9" type="Text" name="namnet">
			<input style="font-family:verdana;font-size:9" type="submit" value="OK">
			</form>

<?php
} else {
?>
<html><head><title>S�kning</title></head><body><span style="font-family:verdana; font-size:11px">
<b>S�kning </b></span> &nbsp; <br>&nbsp; <br>
<table cellspacing=0 border=0 font=verdana style="font-size:10;font-family:verdana" >
<tr style="background-color:#bbddff;font-weight: bold"><td>Nummer</td><td>Namn</td><td>Info senaste samtal</td></tr>

<?php

$sqlfraga=sprintf("select DISTINCT calls.number, book.name FROM calls,book WHERE book.name LIKE '%s%s%s' and calls.number=book.number order by date desc limit 30","%",$namnet,"%");
//$sqlfraga = sprintf("select calls.number, calls.date FROM calls,book WHERE book.name LIKE '%s%s' and calls.number=book.number order by date desc limit 5",$namnet,"%");
//$sqlfraga="select calls.number, calls.date FROM calls,book WHERE book.name LIKE 'An%' and calls.number=book.number order by date desc limit 5";
//printf("%s\n",$sqlfraga);
	$db = mysql_connect("localhost", "cid","cidpasswd") or die("mysql_connect failed");
	$color=0;
	$add=0;
	mysql_select_db("cid",$db) or die("mysql_select_db failed");
	$result = mysql_query($sqlfraga,$db) or die("mysql_query failed");
	$antkol = mysql_num_fields($result);
	//$kolnamn = mysql_list_fields($result);
	while ($myrow = mysql_fetch_row($result)) {
		$add++;
		if ($color==0) {echo "<tr style=\"background-color:#FFF\">"; $color=1;}
		else{echo "<tr style=\"background-color:#bbddff\">"; $color=0;}
		for($i=0;$i<$antkol; $i=($i+1)){
		echo "<td>";
		if ($i==1) {
			if (($myrow[1]=="")&&($myrow[2]!="Dolt nummer"))  {
				$add=1;$numtosave=$myrow[2];} else {printf($myrow[$i]); echo "&nbsp;&nbsp;&nbsp;&nbsp;</td>";}}
				 else {
			printf($myrow[$i]);
		echo "&nbsp;&nbsp;&nbsp;&nbsp;</td>";
		}
		
	}
	echo "<td>";
$sqlfraga2 = 'SELECT date FROM calls WHERE number = \''.$myrow[0].'\' ORDER BY date DESC LIMIT 1';
//echo $sqlfraga2;
$db2 = mysql_connect("localhost", "cid","cidpasswd") or die("mysql_connect2 failed");
	mysql_select_db("cid",$db2) or die("mysql_select_db2 failed");
	$result2 = mysql_query($sqlfraga2,$db2) or die("mysql_query2 failed");

	$myrow2 = mysql_fetch_row($result2);
$link = 'http://kongo/cgi/info.cgi?date='.$myrow2[0].'&submit=submit&number='.$myrow[0];

echo '<a href="'.$link.'"> L�nk </a>';

echo "</td></tr>";
	}//for
	 echo "</table>";echo "<div style=\"font-size:10;font-family:verdana\">";
}
?><br><a style="font-size:10;font-family:verdana" href="javascript:history.go(-1)">Tillbaka</a></div></body></html>
