#include <math.h>

extern double x, y, r, fi;

void polar (void) {
  extern double x, y, r, fi;

  r  = sqrt (x * x + y * y);
  fi = (x == 0 && y == 0) ? 0 : atan2 (y, x); 
}