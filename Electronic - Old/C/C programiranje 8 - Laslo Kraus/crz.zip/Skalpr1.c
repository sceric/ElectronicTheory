/* Funkcija za izracunavanje skalarnog proizvoda */

double skal_pro (double a[], double b[], int n) {
  double zbir=0;
  int i;

  for (i=0; i<n; i++) zbir += a[i] * b[i];
  return zbir;
}

/* Nalazenje skalarnog proizvoda pomocu funkcije skal_pro */

#include <stdio.h>

main () {
  double x[100], y[100];
  int i, k;

  printf ("Duzina vektora: "); scanf ("%d", &k);
  printf ("Komponente vektora X: ");
  for (i=0; i<k; i++) scanf ("%lf", &x[i]);
  printf ("Komponente vektora Y: ");
  for (i=0; i<k; i++) scanf ("%lf", &y[i]);

  printf ("Skalarni proizvod X*Y: %g\n",  skal_pro (x, y, k));
}