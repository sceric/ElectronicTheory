/* Program za sortiranje imena gradova smestenih u dinami�ku zonu */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_GRAD  100
#define MAX_DUZ   30

main () {

  char *adrese[MAX_GRAD], *adresa;
  int  znak, br_grad=0, duz, i;

  do {

    /* Dodela prostora za sledece ime */
    adresa = calloc (MAX_DUZ, sizeof(char));

    /* Citanje sledeceg imena */
    for (duz=0; (znak = getchar()) != '\n'; )
      if (duz < MAX_DUZ - 1) *(adresa + duz++) = znak;
    *(adresa + duz) = '\0';

    /* Kraj ako je duzina imena nula */
    if (! duz) { free (adresa); break; }

    /* Podesavanje velicine dodeljenog prostora stvarnim potrebama */
    adresa = realloc (adresa, duz+1);

    /* Uvrstavanje novog imena u sortirani niz starih imena */
    for (i=br_grad-1; i>=0; i--)
      if (strcmp (adrese[i], adresa) > 0)
        adrese[i+1] = adrese[i];
      else break;
    adrese[i+1] = adresa;

    /* Nastavak rada ako ima jos slobodnih mesta u nizu pokazivaca */
  } while (br_grad++ < MAX_GRAD);

  /* Ispisivanje sortiranog niza imena */
  for (i=0; i<br_grad; i++) printf ("%s\n", adrese[i]);
}