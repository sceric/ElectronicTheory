#include <stdio.h>

void polar () ;

main () {
  double x, y, r, fi;

  while (printf ("x,y: "), scanf ("%lf%lf", &x, &y) != EOF) {
    polar (x, y, &r, &fi); printf ("r,fi: %g, %g\n", r, fi);
  }
}