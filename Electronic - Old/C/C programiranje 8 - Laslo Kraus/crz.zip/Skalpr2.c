/* Funkcija za izracunavanje skalarnog proizvoda */

double skal_pro (double a[], double b[], int n) {
  double zbir=0;
  int i;

  for (i=0; i<n; i++) zbir += a[i] * b[i];
  return zbir;
}