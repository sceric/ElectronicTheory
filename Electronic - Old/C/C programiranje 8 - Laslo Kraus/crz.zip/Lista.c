/* Rad sa jednostruko lancanom listom */

#include <stdio.h>
#include <stdlib.h>

typedef struct elem { int broj; struct elem *sled; } Elem;

Elem *citaj (void) {              /* citanje brojeva i formiranje liste */
  Elem *niz = NULL, *tekuci = NULL, *novi; int broj;
  while (scanf ("%d", &broj)) {
    novi = malloc (sizeof (Elem));
    novi->broj = broj; novi->sled = NULL;
    if (tekuci) tekuci->sled = novi; else niz = novi;
    tekuci = novi;
  }
  getchar (); return niz;
}

void pisi (Elem *niz) {           /* ispisivanje liste */
  while (niz) printf ("%d ", niz->broj), niz = niz->sled;
}

void brisi (Elem *niz) {          /* brisanje cele liste */
  Elem * stari;
  while (niz) {stari = niz; niz = niz->sled; free (stari);}
}

Elem *izost (Elem *niz, int k) {  /* izostavljanje zadatog broja */
  Elem *preth = NULL, *tekuci = niz, *stari;
  while (tekuci)
    if (tekuci->broj == k) {
      stari = tekuci; tekuci = tekuci->sled;
      if (preth) preth->sled = tekuci; else niz = tekuci;
      free (stari);
    } else {
      preth = tekuci; tekuci = tekuci->sled;
    }
  return niz;
}

main () {                         /* test glavni program */
  Elem *lista; int k;
  while (lista = citaj ()) {
    printf ("Ucitani niz   = "); pisi (lista); putchar ('\n');
    scanf ("%d", &k); printf ("Izostavlja se = %d\n", k);
    printf ("Novi niz      = "); pisi (lista = izost (lista, k));
    printf ("\n\n"); brisi (lista);
  }
}