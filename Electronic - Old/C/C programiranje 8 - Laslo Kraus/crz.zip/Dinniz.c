#include <stdio.h>
#include <stdlib.h>
#define MAX_N 500
#define USPEH   0
#define NEUSPEH 1

/* Formiranje dinamickog niza citajuci preko tastature */
int *citaj_niz (void) {
  int *a, n = 0, greska = 0;
  if (! (a = malloc ((MAX_N + 1) * sizeof (int)))) {
    printf ("\n*** Neuspesna dodela memorije ***\a\n\n");
    exit (NEUSPEH);
  }
  while (scanf ("%d", a+(++n)) && !(greska = n == MAX_N));
  getchar ();
  if (greska) { printf ("\n*** Predugacak niz podataka ***\a\n\n");
                exit (NEUSPEH);
              }
  *a = n - 1;
  return realloc (a, n * sizeof (int));
}

/* Ispisivanje dinamickog niza na ekranu */
void pisi_niz (int *a) {
  int i;
  for (i=1; i<=*a; i++) printf ("%d ", *(a+i));
}

/* Nalazenje fuzije dva dinamicka niza */
int *fuzija_nizova (int *a, int *b) {
  int na = *a, nb = *b, nc = *a + *b, ia = 1, ib = 1, ic = 1, *c;
  if (! (c = malloc ((nc + 1) * sizeof (int)))) {
    printf ("\n*** Neuspesna dodela memorije ***\a\n\n");
    exit (NEUSPEH);
  }
  *c = nc;
  while (ia <= na && ib <= nb)
    *(c+ic++) = (*(a+ia) < *(b+ib)) ? *(a+ia++) : *(b+ib++);
  while (ia <= na) *(c+ic++) = *(a+ia++);
  while (ib <= nb) *(c+ic++) = *(b+ib++);
  return c;
}

/* Glavni program za prikaz rada gornjih potprograma */
main () {
  int *a, *b, *c; char odg[2];
  do {
    putchar ('\n');
    printf ("Prvi  ulazni niz: "); a = citaj_niz ();
    printf ("Drugi ulazni niz: "); b = citaj_niz ();
    c = fuzija_nizova (a, b);
    printf ("Rezultujuci niz:  "); pisi_niz (c); putchar ('\n');
    free (a); free (b); free (c);
    printf ("\nDalje (d/n)? "); scanf ("%1s", odg);
  } while (odg[0] == 'd' || odg[0] == 'D');
}