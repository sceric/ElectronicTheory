/* Program za sortiranje imena gradova smestenih u vektor */

#include <stdio.h>
#include <string.h>
#define MAX_GRAD    100
#define MAX_UK_DUZ  3000

main () {

  char gradovi[MAX_UK_DUZ];
  char *adrese[MAX_GRAD], *adresa, *sled_znak=gradovi;
  int  znak, br_grad=0, duz, i;

  do {

    /* Citanje sledeceg imena */
    adresa = sled_znak;
    for (duz=0; sled_znak < gradovi+MAX_UK_DUZ-1; duz++)
      if ((znak = getchar()) != '\n')
        *(sled_znak++) = znak;
      else break;
    *(sled_znak++) = '\0';

    /* Kraj ako je duzina imena nula */
    if (! duz) break; 

    /* Uvrstavanje novog imena u sortirani niz starih imena */
    for (i=br_grad-1; i>=0; i--)
      if (strcmp (adrese[i], adresa) > 0)
        adrese[i+1] = adrese[i];
      else break;
    adrese[i+1] = adresa;
    br_grad++;

    /* Nastavak rada ako ima jos slobodnih mesta u vektoru */
  } while (sled_znak < gradovi+MAX_UK_DUZ);

  /* Ispisivanje sortiranog niza imena */
  for (i=0; i<br_grad; i++) printf ("%s\n", adrese[i]);
}