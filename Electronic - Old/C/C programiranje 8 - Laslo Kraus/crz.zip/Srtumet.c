/* Sortiranje niza brojeva metodom umetanja */

#include <stdio.h>
#include <stdlib.h>
#define DIM 500

main () {
  int n, a[DIM], i, j, b;

  for (;;) {

    /* �itanje du�ine niza */
    printf ("\n\nDuzina niza (max %d): ", DIM); scanf ("%d", &n);
    if (n <= 0 || n > DIM) break;

    /* Formiranje i ispisivanje niza */
    printf ("\nPocetni niz:\n\n");
    for (i=0; i<n; i++) printf ("%d%c",
                        a[i] = rand() / ((double)RAND_MAX + 1) * 10,
                        (i%30==29 || i==n-1) ? ('\n') : (' '));

    /* Sortiranje niza */
    for (i=1; i<n; i++) {
      for (b=a[i], j=i-1; j>=0; j--)
        if (a[j] > b) a[j+1] = a[j]; else break;
      a[j+1] = b;
    }

    /* Ispisivanje sortiranog niza */
    printf ("\nSortirani niz:\n\n");
    for (i=0; i<n; i++) printf ("%d%c",
                        a[i],
                        (i%30==29 || i==n-1) ? ('\n') : (' '));
  }
}