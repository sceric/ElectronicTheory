/* Program za sortiranje imena gradova smestenih u vektor */

#include <stdio.h>
#include <string.h>
#define MAX_GRAD    100
#define MAX_UK_DUZ  3000

main () {

  char gradovi[MAX_UK_DUZ];
  int  indeksi[MAX_GRAD];
  int  znak, br_grad=0, duz, uk_duz=0, indeks, i;

  do {

    /* Citanje sledeceg imena */
    indeks = uk_duz;
    for (duz=0; uk_duz < MAX_UK_DUZ-1; duz++)
      if ((znak = getchar()) != '\n') gradovi[uk_duz++] = znak;
      else break;
    gradovi[uk_duz++] = '\0';

    /* Kraj ako je duzina imena nula */
    if (! duz) break;

    /* Uvrstavanje novog imena u sortirani niz starih imena */
    for (i=br_grad-1; i>=0; i--)
      if (strcmp (&gradovi[indeksi[i]], &gradovi[indeks]) > 0)
        indeksi[i+1] = indeksi[i];
      else break;
    indeksi[i+1] = indeks;
    br_grad++;

    /* Nastavak rada ako ima jos slobodnih mesta u vektoru */
  } while (uk_duz < MAX_UK_DUZ);

  /* Ispisivanje sortiranog niza imena */
  for (i=0; i<br_grad; i++) printf ("%s\n", &gradovi[indeksi[i]]);
}