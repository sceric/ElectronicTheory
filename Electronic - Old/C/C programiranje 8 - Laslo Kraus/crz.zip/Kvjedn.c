/* Program za nalazenje korena kvadratne jednacine */

#include <stdio.h>
#include <math.h>

main () {
  double a, b, c,              /* Koeficijenti jednacine                      */
         d,                    /* Diskriminanta jednacine                     */
         x1, x2,               /* Realni koreni                               */
         z1r, z1i, z2r, z2i,   /* Kompleksni koreni                           */
         x;                    /* Resenje linearne jednacine                  */
  int    por;                  /* Poruka o vrsti resenja                      */

  printf ("Koeficijenti kvadratne jednacine: ");
  scanf ("%lf%lf%lf", &a, &b, &c);
  if (! a)
    if (! b)               por = 1;
    else     { x = -c / b; por = 2; }
  else {
    d = b * b - 4 * a * c;
    if (d < 0) {
      z1r = -b / (2 * a); z1i = sqrt (-d) / (2 * a);
      z2r = z1r;          z2i = - z1i;                por = 3;
    } else {
      x1 = (-b + sqrt (d)) / (2 * a);
      x2 = (-b - sqrt (d)) / (2 * a);                 por = 4;
    }
  }

  switch (por) {
    case 1: printf ("Ulazni podaci nemaju smisla!\a\n");
            break;
    case 2: printf ("Koren linearne jednacine je %g\n", x);
            break;
    case 3: printf ("Kompleksni koreni su %g%ci%g i %g%ci%g\n",
                    z1r, ((z1i >= 0) ? '+' : '-'), fabs (z1i),
                    z2r, ((z2i >= 0) ? '+' : '-'), fabs (z2i));
            break;
    case 4: if (x1 != x2)
              printf ("Realni koreni su %g i %g\n", x1, x2);
            else
              printf ("Jednacina ima dvostruki koren %g\n",x1);
            break;
  }
}