#include <stdio.h>
#include <stdlib.h>

main () {
  int *a[5], i, j;

  for (i=0; i<5; i++) {
    a[i] = calloc (10, sizeof(int));
    for (j=0; j<10; j++) printf ("%2.2d ", *(a[i]+j) = 10*i+j);
    putchar ('\n');
  } 
}