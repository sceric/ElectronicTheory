/* Program za brojanje slova i cifara */

#include <stdio.h>
#include <ctype.h>

main ()
{
  int znak, vel_sl = 0, mal_sl = 0, cifra = 0;

  dalje:
    znak = getchar ();
  if (znak == EOF) goto kraj;
    vel_sl += isupper (znak) != 0;
    mal_sl += islower (znak) != 0;
    cifra  += isdigit (znak) != 0;
    goto dalje;
  kraj:
  printf ("Broj velikih slova u tekstu je %d.\n", vel_sl);
  printf ("Broj malih slova u tekstu je %d.\n",   mal_sl);
  printf ("Broj cifara u tekstu je %d.\n",        cifra );
}