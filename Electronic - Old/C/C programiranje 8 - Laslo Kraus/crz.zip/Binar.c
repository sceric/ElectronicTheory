/* Program za ispisivanje u binarnom sistemu */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

main ()
{
  char dec[10];   int bin, i;

  dalje:
    printf ("Decimalni broj: "); scanf ("%s", dec);
  if (! strlen (dec)) goto kraj;
    bin = atoi (dec);
    printf ("Binarni broj:   "); i = 0;
    cifra:
      putchar ((bin & 0x8000) ? '1' : '0'); bin <<= 1;
      if (i % 4 == 3) putchar (' ');
    if (++i < 16) goto cifra;
    putchar ('\n');
    goto dalje;
  kraj:
  printf ("Uspesan kraj!\n");
}