#include <stdio.h>

double x, y, r, fi;

void polar (void) ;

main () {
  extern double x, y, r, fi;

  while (printf ("x,y: "), scanf ("%lf%lf", &x, &y) != EOF) {
    polar (); printf ("r,fi: %g, %g\n", r, fi);
  }
}