/* Program za ispisivanje poruke na ekranu */

#include <stdio.h>

main (int argc, char *argv[]) {
  int i;
  for (i=1; i<argc; i++)
    printf ("%s%c", argv[i], (i<argc-1)?(' '):('\n'));
}