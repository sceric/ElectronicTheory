#include <stdio.h>
#include <stdlib.h>

main () {
  int *a, *b, *c, na, nb, nc, duz, i;
  for (;;) {
    printf ("na? "); scanf ("%d", &na);
  if (na <= 0) break;
    duz = na * sizeof (int);
    a = malloc (duz); b = malloc (duz); c = malloc (duz);
    printf ("A? "); for (i=0; i<na; scanf ("%d", a+i++));
    for (i=nb=nc=0; i<na; a[i]<0?(b[nb++]=a[i++]):(c[nc++]=a[i++]));
    printf ("B="); for (i=0; i<nb; printf (" %d", b[i++])); putchar ('\n');
    printf ("C="); for (i=0; i<nc; printf (" %d", c[i++])); putchar ('\n');
    free (a); free (b); free (c);
  }
}