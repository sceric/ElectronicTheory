/* Funkcija za binarno pretrazivanje rastuce uredjenog niza */

int bitra (int a[], int n, int k) {
  int l = 0, d = n-1, s;
  enum {NE, DA};

  while (l <= d)
    if (a [s = (l + d) / 2] == k)
      return DA;
    else if (k < a[s])
      d = s - 1;
    else
      l = s + 1;
  return NE;
}

/* Glavni program za prikazivanje rada funkcije bitra */

#include <stdio.h>

main () {
  int a[30], n=0, k; char z;

  /* Citanje niza za pretrazivanje */
  printf ("Rastuci niz brojeva: ");
  do scanf ("%d%c", &a[n++], &z); while (z != '\n');
  putchar ('\n');

  /* Citanje i trazenje pojedinacnih brojeva */
  while (printf ("Trazeni broj: "), scanf ("%d", &k) != EOF)
    printf ("Trazeni broj se%s nalazi u nizu\n",
                  (bitra (a, n, k)) ? "" : " NE");
}