/* Nalazenje skalarnog proizvoda pomocu funkcije skal_pro */

#include <stdio.h>

main () {
  double x[100], y[100];
  int i, k;
  double skal_pro (double [], double [], int);    /* Prototip funkcije */

  printf ("Duzina vektora: "); scanf ("%d", &k);
  printf ("Komponente vektora X: ");
  for (i=0; i<k; i++) scanf ("%lf", &x[i]);
  printf ("Komponente vektora Y: ");
  for (i=0; i<k; i++) scanf ("%lf", &y[i]);

  printf ("Skalarni proizvod X*Y: %g\n",  skal_pro (x, y, k));
}