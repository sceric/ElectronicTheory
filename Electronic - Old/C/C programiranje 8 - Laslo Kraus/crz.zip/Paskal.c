/* Program za ispisivanje Pascal-ovog trougla */

#include <stdio.h>
#include <stdlib.h>

int binko ();     /* Nepotpuni prototip funkcije */

main (argc, argv) int argc; char *argv[]; {
  int n, k, i, nmax = atoi (argv[1]);

  putchar ('\n');
  for (n=0; n<=nmax; n++) {
    for (i=0; i<nmax-n; i++) printf ("  ");
    for (k=0; k<=n; k++) printf ("%4d", binko (n, k));
    putchar ('\n');
  }
}