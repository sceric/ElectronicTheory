/* Funkcija za nalazenje binomnog koeficijenta */

int binko (n, k) int n, k; {
  return (0 < k && k < n) ? (binko (n-1, k) + binko (n-1, k-1)) : 1;
}