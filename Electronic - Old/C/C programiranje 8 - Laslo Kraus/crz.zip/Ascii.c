/* Program za prikazivanje tablice ASCII kodova */

#include <stdio.h>

main ()
{
  char c = ' ';
  int  i;

  printf ("\t\t  Tablica ASCII kodova\n\n");
  linija:
    i = 0;
    znak:
      printf ("%3d  %c      ", c+i, c+i); i = i + 19;
    if (i < 95) goto znak;
    printf ("\n");
    c = c + 1;
  if (c < ' ' + 19) goto linija;
}