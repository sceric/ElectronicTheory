/* Ispisivanje sadr�aja datoteke o stedisama */

#include <stdio.h>

main () {

  typedef struct { char prezime[16], licno_ime[16]; } Ime_i_prezime;
  typedef struct { Ime_i_prezime ime; double stanje; } Stedise;

  FILE *stednja;             /* Datoteka o stedisama                         */
  Stedise stedisa;           /* Podaci o jednom stedisi                      */
  unsigned int sifra;        /* Sifra stedise                                */
  unsigned int veldat;       /* Broj zapisa u datoteci                       */
  unsigned int i, k;         /* Pomocni brojaci                              */

  /* Otvaranje datoteke o stedisama */
  if (! (stednja = fopen ("stedise.dat", "r+b"))) exit (1);
  fread  (&veldat, sizeof veldat, 1, stednja);

  /* Ispisivanje podataka o pojedinim stedisama */
  for (sifra=1; sifra<=veldat; sifra++) {

    /* Citanje sledeceg zapisa iz datoteke */
    printf ("%3d", sifra);
    fread  (&stedisa, sizeof stedisa, 1, stednja);
    if (stedisa.ime.prezime[0] != '\0') {

      /* Prikaz podataka o postojecem stedisi */
      k = printf (" %s %s", stedisa.ime.prezime, stedisa.ime.licno_ime);
      for (i=k; i<34; i++) putchar (' ');
      printf ("%8.2f\n", stedisa.stanje);
    } else

      /* Prazan zapis, stedisa ne postoji */
      printf (" *** Ne postoji stedisa sa ovom sifrom ***\n");
  }
}