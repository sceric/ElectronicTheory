/* Program za sredjivanje recenica */

#include <stdio.h>
#include <ctype.h>

main () {

  enum {F, T};
  int znak, prvi = T;

  while ((znak = getchar ()) != EOF) {
    if      (isupper (znak))
      { if (! prvi) znak += 32; else prvi = F; }
    else if (islower (znak))
      { if (prvi) { znak -= 32; prvi = F; } }
    else
      if (znak == '.' || znak == '!' || znak == '?')
        prvi = T;
    putchar (znak);
  }
}