/* Funkcija za pretvaranje pravouglih u polarne koordinate */

#include <math.h>

void polar (double x, double y, double *r, double *fi) {
  *r  = sqrt (x * x + y * y);
  *fi = (x == 0 && y == 0) ? 0 : atan2 (y, x);
}

/* Nalazenje polarnih koordinata pomocu funkcije polar */

#include <stdio.h>

main () {
  double x, y, r, fi;

  while (printf ("x,y: "), scanf ("%lf%lf", &x, &y) != EOF) {
    polar (x, y, &r, &fi); printf ("r,fi: %g, %g\n", r, fi);
  }
}