/* Definisanje tipa Tacka */
struct tacka {int x, y;};
typedef struct tacka Tacka;

/* Formiranje tacke od zadatih koordinata */
Tacka pravi_tacku (int x, int y) {
  Tacka t;
  t.x = x; t.y = y;
  return t;
}

/* Izracunavanje rastojanja izmedju dve tacke */
#include <math.h>
double rastojanje (Tacka g, Tacka h) {
  return sqrt (pow(g.x-h.x, 2) + pow(g.y-h.y, 2));
}

/* Konstanta za oznacavanje koordinatnog pocetka */
const Tacka NULA = {0, 0};

/* Nalazenje najblize tacke koordinatnom pocetku u nizu tacaka */
Tacka *najbliza (Tacka a[], int n) {
  Tacka *min = a;  double r = rastojanje(a[0],NULA), s;  int i;
  for (i=1; i<n; i++) {
    s = rastojanje (a[i], NULA);
    if (s < r) {r = s; min = a + i;}
  }
  return min;
}