/* Program za sortiranje imena gradova smestenih u matricu */

#include <stdio.h>
#include <string.h>
#define MAX_GRAD 100
#define MAX_DUZ  30

main () {

  char gradovi[MAX_GRAD][MAX_DUZ], grad[MAX_DUZ];
  int  znak, br_grad=0, duz, i;

  do {

    /* Citanje sledeceg imena */
    for (duz=0; duz < MAX_DUZ - 1; duz++) 
      if ((znak = getchar()) != '\n') grad[duz] = znak; else break;
    grad[duz] = '\0';

    /* Kraj ako je duzina imena nula */
    if (! duz) break;

    /* Uvrstavanje novog imena u sortirani niz starih imena */
    for (i=br_grad-1; i>=0; i--)
      if (strcmp (gradovi[i], grad) > 0)
        strcpy (gradovi[i+1], gradovi[i]);
      else break;
    strcpy (gradovi[i+1], grad);

    /* Nastavak rada ako ima jos slobodnih vrsta u matrici */
  } while (++br_grad < MAX_GRAD);

  /* Ispisivanje sortiranog niza imena */
  for (i=0; i<br_grad; i++) printf ("%s\n", gradovi[i]);
}