#include <stdio.h>

/* Potprogram za tabeliranje realne funkcije jednog realnog argumenta */
void tabela (double (*pf)(double), double x1, double x2, double dx) {
  double x;
  printf ("\n          x                 f(x)"
          "\n========================================\n");
  for (x=x1; x<=x2; x+=dx) printf ("%20.10f%20.10f\n", x, (*pf)(x));
}

/* Glavni program za prikaz rada potprograma tabela */
main () {
  double x1, x2, dx, oscilac(double);
  printf ("x1, x2, dx: "); scanf ("%lf%lf%lf", &x1, &x2, &dx);
  tabela (oscilac, x1, x2, dx);
}

/* Primer funkcije za tabeliranje */
#include <math.h>
double oscilac (double x) {return exp (-0.1 * x) * sin (x); }