#include <stdio.h>
#include <math.h>

double x, y, r, fi;

void polar (void) {
  extern double x, y, r, fi;

  r  = sqrt (x * x + y * y);
  fi = (x == 0 && y == 0) ? 0 : atan2 (y, x); 
}

main () {
  extern double x, y, r, fi;

  while (printf ("x,y: "), scanf ("%lf%lf", &x, &y) != EOF) {
    polar (); printf ("r,fi: %g, %g\n", r, fi);
  }
}