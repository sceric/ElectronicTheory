/* Program za izracunavanje skalarnog proizvoda dva vektora */

#include <stdio.h>
#define DIM 50

main ()
{
  double a[DIM], b[DIM], skal_pro;
  int    i, n;

  sledeci:
    printf ("\nDuzina vektora (najvise %d): ", DIM);
    scanf ("%d", &n);
  if (n <= 0) goto kraj;
    if (n > DIM) goto sledeci;
    printf ("Komponente vektora A: "); i = 0;
    novo_a: scanf ("%lf", &a[i++]); if (i < n) goto novo_a;
    printf ("Komponente vektora B: "); i = 0;
    novo_b: scanf ("%lf", &b[i++]); if (i < n) goto novo_b;
    i = skal_pro = 0;
    dalje: skal_pro += a[i] * b[i]; if (++i < n) goto dalje;
    printf ("Skalarni proizvod A*B: %10.3f\n", skal_pro);
    goto sledeci;
  kraj: ;
}