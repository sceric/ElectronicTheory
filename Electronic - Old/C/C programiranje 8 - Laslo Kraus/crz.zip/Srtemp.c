/* Program za izracunavanje srednje temperature u toku godine */

#include <stdio.h>
#define BROJ_MESECI 12

main ()
{
  typedef enum { JAN = 1, FEB, MAR, APR, MAJ, JUN,
                     JUL, AVG, SEP, OKT, NOV, DEC } Meseci;
  Meseci mesec = JAN;
  float temp_po_mesecima [BROJ_MESECI];
  float srednja_temp = 0.;

  dalje:
    printf ("Srednja temperatura za mesec %2d:  ", mesec);
    scanf ("%f", &temp_po_mesecima[mesec-1]);
    srednja_temp = srednja_temp + temp_po_mesecima[mesec-1];
    if (mesec == DEC) goto kraj;
    mesec = mesec + 1;
    goto dalje;
  kraj:
  srednja_temp = srednja_temp / BROJ_MESECI;
  printf ("\nSrednja temperatura za godinu dana = %f\n",
                                            srednja_temp);
}