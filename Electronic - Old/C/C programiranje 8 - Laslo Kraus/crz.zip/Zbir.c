/* Program procita dva cela broja i napise njihov zbir */

#include <stdio.h>

main ()
{
  int a, b, c;
  printf ("a,b? ");
  scanf ("%d%d", &a, &b);
  c = a + b;
  printf ("a+b= %d\n", c);
}