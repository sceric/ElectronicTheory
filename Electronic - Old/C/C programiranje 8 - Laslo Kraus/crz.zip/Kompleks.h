/* Deklaracije paketa potprograma za rad sa kompleksnim brojevima */

typedef struct {double re, im;} Kompl;  /* Struktura kompleksnog broja       */

Kompl  cmplx (double, double); /* Formiranje kompleksnog broja               */
double creal (Kompl);          /* Realni deo kompleksnog broja               */
double cimag (Kompl);          /* Imaginarni deo kompleksnog broja           */
double cmod  (Kompl);          /* Apsolutna vrednost kompleksnog broja       */
double carg  (Kompl);          /* Argument kompleksnog broja                 */
Kompl  conjg (Kompl);          /* Konjugovani kompleksni broj                */
Kompl  cadd  (Kompl, Kompl);   /* Zbir dva kompleksna broja                  */
Kompl  csub  (Kompl, Kompl);   /* Razlika dva kompleksna broja               */
Kompl  cmul  (Kompl, Kompl);   /* Proizvod dva kompleksna broja              */
Kompl  cdiv  (Kompl, Kompl);   /* Kolicnik dva kompleksna broja              */
Kompl  cexp  (Kompl);          /* Eksponent sa kompleksnim brojem            */
Kompl  clog  (Kompl);          /* Logaritam kompleksnog broja                */
Kompl  cpow  (Kompl, Kompl);   /* Stepenovanje kompleksnih brojeva           */

extern const Kompl J;          /* Imaginarna jedinica                        */
extern const Kompl C1;         /* Realna jedinica kao kompleksan broj        */
extern const Kompl C0;         /* Nula kao kompleksan broj                   */