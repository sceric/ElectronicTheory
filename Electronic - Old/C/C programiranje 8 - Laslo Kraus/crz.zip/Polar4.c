/* Funkcija za nalazenje polarnih koordinata */

#include <math.h>

void polar (x, y, r, fi)
double x, y, *r, *fi;
{
  *r  = sqrt (x * x + y * y);
  *fi = (x == 0 && y == 0) ? 0 : atan2 (y, x);
}