/* Program za citanje niza celih brojeva sa tastature i
         izracunavanje njihove srednje vrednosti        */

#include <stdio.h>

main ()
{
  int n, a[100], i;
  float s;
  printf ("n= ");
  scanf ("%d", &n);
  i = 0; s = 0;
  dalje:
    if (i == n) goto kraj;
    printf ("a[%d]= ", i);
    scanf ("%d", &a[i]);
    s = s + a[i];
    i = i + 1;
    goto dalje;
  kraj:
  if (n != 0) s = s / n;
  printf ("\ns= %f\n", s);
}