/* Program za prenos tekst datoteka */

#include <stdio.h>

void prepis (FILE *ulaz, FILE *izlaz) {
  /* Prepisuje datoteku ulaz u izlaz */
  int zn;
  while ((zn = getc (ulaz)) != EOF) putc (zn, izlaz);
}

main (int argc, char *argv[]) {

  void prepis (FILE *, FILE *);
  FILE *datot;
  char *progr = argv[0];  /* adresa imena programa */

  if (argc == 1)  prepis (stdin, stdout);
  else
    while (--argc > 0)
      if ((datot = fopen (*++argv, "r")) != NULL)
        prepis (datot, stdout), fclose (datot);
      else {
        fprintf (stderr, "%s: ne postoji datoteka %s\n", progr, *argv);
        exit (1);
      }
  if (ferror (stdout)) {
    fprintf (stderr, "%s: greska pisanja u stdout\n", progr);
    exit (2);
  }
  exit (0);
}