#include <stdio.h>

main () {
  double a, b;
  typedef double *P_double;
  P_double pa = &a, pb = &b, pc;
  scanf ("%lf %lf", pa, pb);
  pc = (*pa < *pb) ? pa: pb;
  printf ("%g\n", *pc);
}