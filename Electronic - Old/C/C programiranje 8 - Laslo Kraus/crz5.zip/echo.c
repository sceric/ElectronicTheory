/* Ispisivanje poruke na ekranu.                                     */

#include <stdio.h>

void main (int barg, const char *varg[]) {
  int i;
  for (i=1; i<barg; i++)
    printf ("%s%c", varg[i], (i<barg-1)?(' '):('\n'));
}
