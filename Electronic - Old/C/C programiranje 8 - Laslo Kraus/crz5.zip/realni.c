/* Razni oblici prikazivanja realnih brojeva.                        */

#include <stdio.h>

main () {
  double x;
  printf ("Unesite realni broj: ");
  scanf ("%lf", &x);
  printf ("Uneti broj: %12.4f %12.4e %12.4g\n", x, x, x);
}
