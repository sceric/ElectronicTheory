/* Program za ispitivanje kompleksnih funkcija.                          */

#include <stdio.h>
#include "kompleks.h"

void main () {
  while (1) {
    Kompl x, y;
    printf ("x(re,im)? "); scanf ("%lf%lf%", &x.re, &x.im);
  if (x.re == 1E38) break;
    printf ("y(re,im)? "); scanf ("%lf%lf%", &y.re, &y.im);
    putchar ('\n');
    printf ("x     = (%f,%f)\n", creal(x), cimag(x));
    printf ("y     = (%f,%f)\n", creal(y), cimag(y));
    printf ("|x|   = %f\n",      cmod (x));
    printf ("|y|   = %f\n",      cmod (y));
    printf ("arg x = %f\n",      carg (x));
    printf ("arg y = %f\n",      carg (y));
    printf ("~x    = (%f,%f)\n", conjg(x).re,   conjg(x).im);
    printf ("~y    = (%f,%f)\n", conjg(y).re,   conjg(y).im);
    printf ("x+y   = (%f,%f)\n", cadd (x,y).re, cadd (x,y).im);
    printf ("x-y   = (%f,%f)\n", csub (x,y).re, csub (x,y).im);
    printf ("x*y   = (%f,%f)\n", cmul (x,y).re, cmul (x,y).im);
    printf ("x/y   = (%f,%f)\n", cdiv (x,y).re, cdiv (x,y).im);
    printf ("e^x   = (%f,%f)\n", cexp (x).re,   cexp (x).im);
    printf ("e^y   = (%f,%f)\n", cexp (y).re,   cexp (y).im);
    printf ("log x = (%f,%f)\n", clog (x).re,   clog (x).im);
    printf ("log y = (%f,%f)\n", clog (y).re,   clog (y).im);
    printf ("x^y   = (%f,%f)\n", cpow (x,y).re, cpow (x,y).im);
    putchar ('\n');
  }
}
