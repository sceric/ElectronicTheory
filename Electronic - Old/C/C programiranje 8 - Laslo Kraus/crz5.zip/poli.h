/* Zaglavlje paketa za obradu polinoma.                                  */

#ifndef _poli_h_
#define _poli_h_

double poli     (const double  *p , int  n ,   /* Vrednost polinoma.     */
                       double   x          ) ;

void   zbir     (const double  *p1, int  n1,   /* Zbir dva polinoma.     */
                 const double  *p2, int  n2,
                       double **p3, int *n3) ;

void   razlika  (const double  *p1, int  n1,   /* Razlika dva polinoma.  */
                 const double  *p2, int  n2,
                       double **p3, int *n3) ;

void   proizvod (const double  *p1, int  n1,   /* Proizvod dva polinoma. */
                 const double  *p2, int  n2,
                       double **p3, int *n3) ;

void   kolicnik (const double  *p1, int  n1,   /* Kolicnik dva polinoma. */
                 const double  *p2, int  n2,
                       double **p3, int *n3,
                       double **p4, int *n4) ;

void   citaj    (      double **p , int *n ) ; /* Citanje polinoma.      */

void   pisi     (const double  *p , int  n ,   /* Pisanje polinoma.      */
                 const char    *f          ) ;

#endif