/* Program za prenos tekstualnih datoteka.                           */

#include <stdio.h>

void prepis (FILE *ulaz, FILE *izlaz) {
  /* Prepisuje datoteku ulaz u izlaz */
  int zn;
  while ((zn = getc (ulaz)) != EOF) putc (zn, izlaz);
}

void main (int barg, const char *varg[]) {

  FILE *datot;
  const char *progr = varg[0];  /* adresa imena programa */

  if (barg == 1)  prepis (stdin, stdout);
  else
    while (--barg > 0)
      if ((datot = fopen (*++varg, "r")) != NULL)
        prepis (datot, stdout), fclose (datot);
      else {
        fprintf (stderr, "%s: ne postoji datoteka %s\n", progr, *varg);
        exit (1);
      }
  if (ferror (stdout)) {
    fprintf (stderr, "%s: greska pisanja u stdout\n", progr);
    exit (2);
  }
  exit (0);
}
