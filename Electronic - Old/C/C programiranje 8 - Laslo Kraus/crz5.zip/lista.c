/* Obrada jednostruko spregnutii lista.                                  */

#include <stdio.h>
#include <stdlib.h>

typedef struct elem { int broj; struct elem *sled; } Elem;

Elem *citaj () {                  /* Citanje brojeva i stvaranje liste   */
  Elem *lst = NULL, *tekuci = NULL; int broj;
  while (scanf ("%d", &broj)) {
    Elem *novi = malloc (sizeof (Elem));
    novi->broj = broj; novi->sled = NULL;
    if (! lst) lst = novi; else tekuci->sled = novi;
    tekuci = novi;
  }
  getchar ();
  return lst;
}

void pisi (Elem *lst) {           /* Ispisivanje liste                   */
  while (lst) { printf ("%d ", lst->broj); lst = lst->sled; }
}

void brisi (Elem *lst) {          /* Brisanje cele liste                 */
  while (lst) { Elem *stari = lst; lst = lst->sled; free (stari); }
}

Elem *izost (Elem *lst, int k) {  /* Izostavljanje zadatog broja         */
  Elem *preth = NULL, *tekuci = lst;
  while (tekuci)
    if (tekuci->broj != k) {
      preth = tekuci; tekuci = tekuci->sled;
    } else {
      Elem *stari = tekuci; tekuci = tekuci->sled;
      if (! preth) lst = tekuci; else preth->sled = tekuci;
      free (stari);
    }
  return lst;
}

void main () {                    /* Test glavni program                 */
  Elem *lista;
  while ((lista = citaj ()) != NULL) {
    int k;
    printf ("Ucitani niz   = "); pisi (lista); putchar ('\n');
    scanf ("%d", &k); printf ("Izostavlja se = %d\n", k);
    printf ("Novi niz      = "); pisi (lista = izost (lista, k));
    printf ("\n\n"); brisi (lista);
  }
}
