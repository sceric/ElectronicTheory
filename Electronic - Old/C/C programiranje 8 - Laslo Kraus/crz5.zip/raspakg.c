/* Prikazivanje rada funkcije raspak.                                */

#include <stdio.h>
#include <stdlib.h>

void raspak (unsigned int, char [], int *);    /* Prototip funkcije. */

void main (int barg, const char *varg[]) {
  int i, j, k; char niz[64];

  for (i=1; i<barg; i++) {
    raspak (atoi (varg[i]), niz, &k);
    for (j=1; j<=k; j++) {
      printf ("%d", niz[k-j]); if (j % 4 == 0) putchar (' ');
    }
    putchar ('\n');
  }
}
