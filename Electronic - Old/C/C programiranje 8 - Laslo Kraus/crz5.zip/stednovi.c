/* Dodavanje novih zapisa u datoteku o stedisama.                    */

#include <stdio.h>
#include "stedisa.h"

void main () {

  FILE *stednja;             /* Datoteka o stedisama                 */
  Stedisa stedisa;           /* Podaci o jednom stedisi              */
  Stedisa prazno = {0};      /* Prazan zapis (sadrzi sve nule)       */
  unsigned int sifra;        /* Sifra stedise                        */
  unsigned int veldat;       /* Broj zapisa u datoteci               */

  /* Otvaranje datoteke o stedisama */
  if ((stednja = fopen ("stedise.dat", "r+b")) != NULL)

    /* Datoteka postoji, citanje broja zapisa u datoteci */
    fread  (&veldat, sizeof veldat, 1, stednja);
  else {

    /* Datoteka ne postoji, stvaranje prazne datoteke */
    stednja = fopen ("stedise.dat", "w+b"); veldat = 0;
    fwrite (&veldat, sizeof veldat, 1, stednja);
  }

  /* Dodavanje zapisa o novim stedisama */
  while (1) {

    /* Citanje podataka o stedisi */
    printf ("\nSifra stedise?     "); scanf ("%d", &sifra);
  if (sifra == 0) break;   /* ... zavrsetak programa */
    printf ("Prezime stedise?   ");
    scanf ("%s", stedisa.ime.prezime);
    printf ("Licno ime stedise? ");
    scanf ("%s", stedisa.ime.licno_ime);
    stedisa.stanje = 0;

    /* Priprema za upisivanje podataka u datoteku */
    if (sifra > veldat) {

      /* Novi zapis je iza kraja datoteke, promena velicine datoteke */
      fseek  (stednja, 0L, SEEK_END);
      while (++veldat < sifra) fwrite (&prazno, sizeof prazno, 1, stednja);
      veldat = sifra;
    } else

      /* Novi zapis je pre kraja datoteke, nalazenje njegovog mesta */
      fseek (stednja,
             (sizeof veldat) + (long) (sifra - 1) * (sizeof stedisa),
             SEEK_SET);

    /* Upisivanje podataka u datoteku */
    fwrite (&stedisa, sizeof stedisa, 1, stednja);
    rewind (stednja); fwrite (&veldat, sizeof veldat, 1, stednja);
  }
}
