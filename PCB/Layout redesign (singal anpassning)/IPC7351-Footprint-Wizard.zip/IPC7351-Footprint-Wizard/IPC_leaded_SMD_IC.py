#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#
#  Coding and Design, Data Evaluation and Integration by
#  Daniel Schoeni, http://elnet.ch/
#  based on other KiCad footprint wizards.
#  This is my first Python project. So please excuse some coding mistakes ...
#

from __future__ import division
import pcbnew
import os
import math

import HelpfulFootprintWizardPlugin
import PadArray as PA


class MyWizard(HelpfulFootprintWizardPlugin.HelpfulFootprintWizardPlugin):

    def GetName(self):
        return "IPC-7351 Leaded and Leadless SMD IC"

    def GetDescription(self):
        return "IPC-7351B compliant footprint wizard"
    
    MY_name          = 'Footprint Name'
  
    ipc_suffix            = ["","M","N","L"]
    ipc_level        = 'Level: 1,2,3 (-> A,B,C)'
        
    body_width_min   = 'Body Width Min.'   
    body_width_max   = 'Body Width Max.'   
    body_length_min  = 'Body Length Min.'  
    body_length_max  = 'Body Length Max.'  
    body_height_max  = 'Max. Height'
    body_standoff    = 'Standoff Max.'
                   
    term_pitch       = 'Pitch'
    term_pos_hor     = 'Positions horizontal'
    span_width_min   = 'Span Width Min.'
    span_width_max   = 'Span Width Max.'
    term_pos_ver     = 'Positions vertical'
    span_length_min  = 'Span Length Min.'
    span_length_max  = 'Span Length Max.'
                   
    term_type        = 'Lead Type (0,1,2 -> Leads,Flat Leads,Leadless)'
    term_width_min   = 'Terminal Width Min.'
    term_width_max   = 'Terminal Width Max.'
    term_length_min  = 'Terminal Length Min.'
    term_length_max  = 'Terminal Length Max.'
    term_pullback    = 'Terminal Pullback (No-Lead)'
        
    expad_width_min  = 'Exposed Pad Width Min.'
    expad_width_max  = 'Exposed Pad Width Max.'
    expad_length_min = 'Exposed Pad Length Min.'
    expad_length_max = 'Exposed Pad Length Max.'
        
    view_index       = 'Index'
    term_home_pos    = 'Center Pin1'
    view_rounded     = 'Rounded Pads'
    view_fiducials   = 'Fiducials'
    view_bevel       = 'Bevel (%)'
    view_outline     = 'Outline Outside'
    view_IEC_level   = 'IEC 61188-7 Level (0,1 -> A,B)'
    view_name_unlock = 'Name Override'
        
    fab_fab_tol      = 'Fabrication Tolerance'
    fab_ass_tol      = 'Assembly Tolerance'
    fab_silk_width   = 'Silk Width'
    fab_clearance    = 'Clearance'
                   
    hint_start       = 'Show PDF'
    
    term_width  = 0
    term_length = 0
    term_span_width  = 0
    term_span_length = 0
    body_width       = 0
    body_length      = 0
    body_height      = 0
    
    IEC_map          = True
    
        
    def GenerateParameterList(self):
    
        self.AddParam("IPC", self.ipc_level, self.uNatural, 2)
        
        self.AddParam("Package", self.body_width_min,  self.uMM, 10)
        self.AddParam("Package", self.body_width_max,  self.uMM, 10)
        self.AddParam("Package", self.body_length_min, self.uMM, 10)
        self.AddParam("Package", self.body_length_max, self.uMM, 10)
        self.AddParam("Package", self.body_height_max, self.uMM, 1.2)
        self.AddParam("Package", self.body_standoff,   self.uMM, 0.15)
        
        self.AddParam("Shape", self.term_pitch,      self.uMM, 0.8)
        self.AddParam("Shape", self.term_pos_hor,    self.uNatural, 11)
        self.AddParam("Shape", self.span_width_min,   self.uMM, 12)
        self.AddParam("Shape", self.span_width_max,   self.uMM, 12)
        self.AddParam("Shape", self.term_pos_ver,    self.uNatural, 11)
        self.AddParam("Shape", self.span_length_min,  self.uMM, 12)
        self.AddParam("Shape", self.span_length_max,  self.uMM, 12)
        
        self.AddParam("Terminals", self.term_type,       self.uNatural, 0)
        self.AddParam("Terminals", self.term_width_min,  self.uMM, 0.3)
        self.AddParam("Terminals", self.term_width_max,  self.uMM, 0.45)
        self.AddParam("Terminals", self.term_length_min, self.uMM, 0.45)
        self.AddParam("Terminals", self.term_length_max, self.uMM, 0.75)
        self.AddParam("Terminals", self.term_pullback,   self.uMM, 0)
                
        self.AddParam("Exposed Pad", self.expad_width_min,  self.uMM, 0)
        self.AddParam("Exposed Pad", self.expad_width_max,  self.uMM, 0)
        self.AddParam("Exposed Pad", self.expad_length_min, self.uMM, 0)
        self.AddParam("Exposed Pad", self.expad_length_max, self.uMM, 0)
        
        self.AddParam("Views", self.view_index,     self.uMM, 0.5)
        self.AddParam("Views", self.term_home_pos,   self.uBool, 0)
        self.AddParam("Views", self.view_rounded,   self.uBool, True)
        self.AddParam("Views", self.view_fiducials, self.uBool, 0)
        self.AddParam("Views", self.view_bevel,     self.uNatural, 5)
        self.AddParam("Views", self.view_outline,   self.uBool, 0)
        self.AddParam("Views", self.view_IEC_level, self.uBool, True)
        self.AddParam("Views", self.view_name_unlock, self.uBool, 0)
        self.AddParam("Views", self.MY_name,        self.uString, 'Footprint Name')
        
        self.AddParam("Manufacturing", self.fab_fab_tol,    self.uMM, 0.1)
        self.AddParam("Manufacturing", self.fab_ass_tol,    self.uMM, 0.1)
        self.AddParam("Manufacturing", self.fab_silk_width, self.uMM, 0.15)
        self.AddParam("Manufacturing", self.fab_clearance,  self.uMM, 0.2)
        
        self.AddParam("Hints", self.hint_start, self.uBool, 0)
        
    def roundmeup(self, mynumber, mystep):
        return math.ceil(mynumber / mystep) * mystep
    
    def SetMinVal(self, destination, source):
        if destination < source:
            destination = source
        return destination

    def SetMaxVal(self, destination, source):
        if destination > source:
            destination = source 
        return destination

    def CheckHints(self, section, param):
        #param must be boolean
        if str(self.parameters[section][param]).lower() in [
                "true", "t", "y", "yes", "on", "1", "1.0"]:
            self.parameters[section][param] = False
            os.startfile("IPC-7351B-Hints.pdf") # Must be in KiCad main directory, command might be changed for LINUX or Apples
            return
        return

    def CheckParameters(self):
        self.CheckParamBool("Views", '*' + self.view_rounded)
        self.CheckParamBool("Views", '*' + self.view_fiducials)
        self.CheckParamBool("Views", '*' + self.view_name_unlock)
        self.CheckParamBool("Views", '*' + self.view_outline)
        self.CheckParamInt("IPC", '*' + self.ipc_level, min_value=0, max_value=3)
        self.CheckHints("Hints", '*' + self.hint_start)
        self.CheckParamBool("Views", '*' + self.term_home_pos)
        self.CheckParamBool("Views", '*' + self.view_IEC_level)
        ex_pad = self.parameters["Exposed Pad"]
        if ex_pad[self.expad_width_max] < ex_pad[self.expad_width_min]:
            ex_pad[self.expad_width_max] = ex_pad[self.expad_width_min]
        if ex_pad[self.expad_length_max] < ex_pad[self.expad_length_min]:
            ex_pad[self.expad_length_max] = ex_pad[self.expad_length_min]
        terminals = self.parameters["Terminals"]
        if terminals[self.term_width_max] < terminals[self.term_width_min]: 
            terminals[self.term_width_max] = terminals[self.term_width_min]
        if terminals[self.term_length_max] < terminals[self.term_length_min]: 
            terminals[self.term_length_max] = terminals[self.term_length_min] 
        shape = self.parameters["Shape"]
        if shape[self.span_length_max] < shape[self.span_length_min]: 
            shape[self.span_length_max] = shape[self.span_length_min]
        if shape[self.span_width_max] < shape[self.span_width_min]: 
            shape[self.span_width_max] = shape[self.span_width_min]
        package = self.parameters["Package"]
        if package[self.body_length_max] < package[self.body_length_min]: 
            package[self.body_length_max] = package[self.body_length_min]
        if package[self.body_width_max] < package[self.body_width_min]: 
            package[self.body_width_max] = package[self.body_width_min]
        p_term_type = terminals['*' + self.term_type]
        if p_term_type == 2:
            shape[self.span_width_min]  = package[self.body_width_min]  - terminals[self.term_pullback] * 2
            shape[self.span_width_max]  = package[self.body_width_max]  - terminals[self.term_pullback] * 2
            shape[self.span_length_min] = package[self.body_length_min] - terminals[self.term_pullback] * 2
            shape[self.span_length_max] = package[self.body_length_max] - terminals[self.term_pullback] * 2
        
        self.term_width       = pcbnew.ToMM(terminals[self.term_width_max]  + terminals[self.term_width_min])  / 2
        self.term_length      = pcbnew.ToMM(terminals[self.term_length_max] + terminals[self.term_length_min]) / 2
        self.term_span_width  = pcbnew.ToMM(shape[self.span_width_max]  + shape[self.span_width_min])  / 2
        self.term_span_length = pcbnew.ToMM(shape[self.span_length_max] + shape[self.span_length_min]) / 2
        self.body_width       = pcbnew.ToMM(package[self.body_width_max]  + package[self.body_width_min])  / 2
        self.body_length      = pcbnew.ToMM(package[self.body_length_max] + package[self.body_length_min]) / 2
        self.body_height      = pcbnew.ToMM(package[self.body_height_max]) # - package[self.body_standoff])
        
    def GetValue(self):
        views = self.parameters["Views"]
            
        if not views['*' + self.view_name_unlock]:
            ipc_level = self.parameters["IPC"]['*' + self.ipc_level]
            shape = self.parameters["Shape"]
            package = self.parameters["Package"]
            terminals = self.parameters["Terminals"]
            ex_pad = self.parameters["Exposed Pad"]
            
            pad_pitch = shape[self.term_pitch]
            hPads = shape['*' + self.term_pos_hor]
            vPads = shape['*' + self.term_pos_ver]
            nPads = (hPads + vPads) * 2
        
            MY_name = ""
            JP_h = (self.body_length > (self.term_span_length - 2 * self.term_length)) and (vPads > 0)
            JP_v = (self.body_width  > (self.term_span_width  - 2 * self.term_length)) and (hPads > 0)
            J_Pack  = JP_h or JP_v
            T_Pack  = False if (package[self.body_height_max] - package[self.body_standoff]) > pcbnew.FromMM(1.6) else True
            if T_Pack:
                MY_name += "T"
            S_Pack  = False if pad_pitch > pcbnew.FromMM(0.625) else True
            p_term_type = terminals['*' + self.term_type]
            Pullback = terminals[self.term_pullback] > 0
            if S_Pack:
                MY_name += "S"
            if (hPads == 0) or (vPads == 0):
                Q_Pack  = False  
                if p_term_type == 2:
                    if Pullback:
                        MY_name += "P"
                    MY_name += "SON"
                else:
                    if J_Pack:
                        MY_name += "SOJ"
                    else:
                        MY_name += "SOP"
            else:
                Q_Pack  = True
                if p_term_type == 2:
                    if Pullback:
                        MY_name += "P"
                    MY_name += "QFN"
                else:
                    if J_Pack:
                        MY_name = "PLCC"
                    else:
                        MY_name += "QFP"
            MY_name += "%03dP" % (pcbnew.ToMM(pad_pitch) * 100)
            nominal_width  = self.term_span_width  if (self.term_span_width > self.body_width)   and (vPads > 0) else self.body_width
            if vPads > 0:
                if nominal_width >= 10:
                    MY_name += "%dX" % (nominal_width * 100)
                else:
                    MY_name += "%03dX" % (nominal_width * 100)
            nominal_length = self.term_span_length if (self.term_span_length > self.body_length) and (hPads > 0) else self.body_length
            if hPads > 0:
                if nominal_length >= 10:
                    MY_name += "%dX" % (nominal_length * 100)
                else:
                    MY_name += "%03dX" % (nominal_length * 100)
            if self.body_height >= 10:
                MY_name += "%d" % (self.body_height * 100)
            else:
                MY_name += "%03d" % (self.body_height * 100)
            if (ex_pad[self.expad_width_min] > 0) and (ex_pad[self.expad_length_min] > 0):
                MY_name += "_HS"
            MY_name += "-%d" % nPads
            MY_name += self.ipc_suffix[ipc_level]
            
            views['*' + self.MY_name] = MY_name
        
        return "{}".format(self.parameters["Views"]['*' + self.MY_name])
        
    def BuildThisFootprint(self):
        
        ipc_level = self.parameters["IPC"]['*' + self.ipc_level]

        views = self.parameters["Views"]
        IEC_Level = not views['*' + self.view_IEC_level]
        pad_home_centered = views['*' + self.term_home_pos]
        silk_outline = views['*' + self.view_outline]
        silk_index = views[self.view_index] > 0
        terminals = self.parameters["Terminals"]
        p_term_type = terminals['*' + self.term_type]
        Pullback = terminals[self.term_pullback] > 0
        
        shape = self.parameters["Shape"]
        package = self.parameters["Package"]
        
        manufacturing = self.parameters["Manufacturing"]
        clearance = manufacturing[self.fab_clearance]
        
        ex_pad = self.parameters["Exposed Pad"]
        
        pad_pitch = shape[self.term_pitch]
        hPads = shape['*' + self.term_pos_hor]
        vPads = shape['*' + self.term_pos_ver]
        nPads = (hPads + vPads) * 2
            
        if (IEC_Level <> self.IEC_map) and not ((hPads == 0) and (vPads == 0)):
            
            if ((not IEC_Level) and (hPads == 0)) or ((IEC_Level) and (vPads == 0)):
                val_temp = hPads
                hPads = vPads
                vPads = val_temp
                shape['*' + self.term_pos_hor] = vPads
                shape['*' + self.term_pos_ver] = hPads
                
                val_temp = ex_pad[self.expad_width_max]
                ex_pad[self.expad_width_max] = ex_pad[self.expad_length_max]
                ex_pad[self.expad_length_max] = val_temp
                val_temp = ex_pad[self.expad_width_min]
                ex_pad[self.expad_width_min] = ex_pad[self.expad_length_min]
                ex_pad[self.expad_length_min] = val_temp
                
                val_temp = shape[self.span_width_max]
                shape[self.span_width_max] = shape[self.span_length_max]
                shape[self.span_length_max] = val_temp
                val_temp = shape[self.span_width_min]
                shape[self.span_width_min] = shape[self.span_length_min]
                shape[self.span_length_min] = val_temp
                
                val_temp = package[self.body_width_max]
                package[self.body_width_max] = package[self.body_length_max]
                package[self.body_length_max] = val_temp
                val_temp = package[self.body_width_min]
                package[self.body_width_min] = package[self.body_length_min]
                package[self.body_length_min] = val_temp
        
        if hPads == 0: 
            IEC_Level = True
            
        if vPads == 0:
            IEC_Level = False    
            
        views['*' + self.view_IEC_level] = not IEC_Level
        self.IEC_map = IEC_Level
        
        JP_h = (self.body_length > (self.term_span_length - 2 * self.term_length)) and (vPads > 0)
        JP_v = (self.body_width  > (self.term_span_width  - 2 * self.term_length)) and (hPads > 0)
        J_Pack  = JP_h or JP_v
        S_Pack  = False if pad_pitch > pcbnew.FromMM(0.625) else True
        T_Pack  = False if (package[self.body_height_max] - package[self.body_standoff]) > pcbnew.FromMM(1.6) else True
        if (hPads == 0) or (vPads == 0):
            Q_Pack  = False  
            pad_home_centered = False
            views['*' + self.term_home_pos] = False
        else:
            Q_Pack  = True
        
        #IPC parameters
        
        if p_term_type == 0:
            pTOE    = [0,0.55,0.35,0.15]
            pHEEL_n = [0,0.45,0.35,0.25]
            pHEEL_s = [0,0.25,0.15,0.05] if not J_Pack else [0,0.1,0,-0.1]
            pSIDE   = [0,0.05,0.03,0.01] if not S_Pack else [0,0.01,-0.02,-0.04]
            pROUND = 0.05
            pCOURT = [0,0.5,0.25,0.1]
        elif p_term_type == 1:
            pTOE    = [0,0.3,0.2,0.1]
            pHEEL_n = [0,0,0,0]
            pHEEL_s = [0,0,0,0] if not J_Pack else [0,0,0,0]
            pSIDE   = [0,0.05,0,-0.05] if not S_Pack else [0,0.05,0,-0.05]
            pROUND = 0.05
            pCOURT = [0,0.2,0.15,0.1]
        else:
            pTOE    = [0,0.4,0.3,0.2] if not Pullback else [0,0.05,0,-0.05]
            pHEEL_n = [0,0,0,0]
            pHEEL_s = [0,0,0,0]
            pSIDE   = [0,-0.04,-0.04,-0.04]
            pROUND = 0.05
            pCOURT = [0,0.5,0.25,0.1]
        
        #calculating distances and tolerances
        F_tol    = manufacturing[self.fab_fab_tol]
        P_tol    = manufacturing[self.fab_ass_tol]
        T_tol    = terminals[self.term_length_max] - terminals[self.term_length_min] 
        W_tol    = terminals[self.term_width_max]  - terminals[self.term_width_min] 
        
        pad_width = self.roundmeup(terminals[self.term_width_min] + 2 * pcbnew.FromMM(pSIDE[ipc_level]) + (W_tol ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2), pcbnew.FromMM(pROUND))
        if pad_width > (pad_pitch - manufacturing[self.fab_clearance]):
            pad_width = pad_pitch - manufacturing[self.fab_clearance]
        
        pad_area_h = ((hPads - 1) * pad_pitch) + pad_width
        pad_area_v = ((vPads - 1) * pad_pitch) + pad_width
        
        if hPads > 0:
            L_tol_v  = shape[self.span_width_max] - shape[self.span_width_min]
            Z_max_v  = shape[self.span_width_min] + 2 * pcbnew.FromMM(pTOE[ipc_level]) + (L_tol_v ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)
        else:
            L_tol_v  = package[self.body_width_max] - package[self.body_width_min] 
            Z_max_v  = package[self.body_width_min] + (L_tol_v ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)
            if Z_max_v < pad_area_v:
                Z_max_v = pad_area_v
        
        if vPads > 0:
            L_tol_h  = shape[self.span_length_max] - shape[self.span_length_min]
            Z_max_h  = shape[self.span_length_min] + 2 * pcbnew.FromMM(pTOE[ipc_level]) + (L_tol_h ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)
        else:
            L_tol_h  = package[self.body_length_max] - package[self.body_length_min]
            Z_max_h  = package[self.body_length_min] + (L_tol_h ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)
            if Z_max_h < pad_area_h:
                Z_max_h = pad_area_h
        
        
        S_tol_h  = L_tol_h + 2 * T_tol
        dS_tol_h = S_tol_h - (L_tol_h ** 2 + 2 * T_tol ** 2) ** (1 / 2)
        S_min_h  = shape[self.span_length_min] - 2 * terminals[self.term_length_max] + dS_tol_h / 2
        S_max_h  = shape[self.span_length_max] - 2 * terminals[self.term_length_min] - dS_tol_h / 2
        pHEEL = pHEEL_n if S_min_h > package[self.body_length_max] else pHEEL_s
        G_min_h  = S_max_h - 2 * pcbnew.FromMM(pHEEL[ipc_level]) - (S_tol_h ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)
        if G_min_h < clearance: G_min_h = clearance
        
        S_tol_v  = L_tol_v + 2 * T_tol
        dS_tol_v = S_tol_v - (L_tol_v ** 2 + 2 * T_tol ** 2) ** (1 / 2)
        S_min_v  = shape[self.span_width_min] - 2 * terminals[self.term_length_max] + dS_tol_v / 2
        S_max_v  = shape[self.span_width_max] - 2 * terminals[self.term_length_min] - dS_tol_v / 2
        pHEEL = pHEEL_n if S_min_v > package[self.body_width_max] else pHEEL_s
        G_min_v  = S_max_v - 2 * pcbnew.FromMM(pHEEL[ipc_level]) - (S_tol_v ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)
        if G_min_v < clearance: G_min_v = clearance
        
        #exposed pad
        exposed_h = (ex_pad[self.expad_length_max] + ex_pad[self.expad_length_min]) / 2
        exposed_v = (ex_pad[self.expad_width_max] + ex_pad[self.expad_width_min]) / 2
        if (exposed_h > 0) and (exposed_v > 0):    
            #distance from maximum required, even the exposed pad is normally smaller
            exposed_G_h = ex_pad[self.expad_length_max] + (clearance + (F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)) * 2
            exposed_G_v = ex_pad[self.expad_width_max] + (clearance + (F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)) * 2
            if G_min_h < exposed_G_h: 
                G_min_h = exposed_G_h
            if G_min_v < exposed_G_v: 
                G_min_v = exposed_G_v 
            
            pad_count = (hPads + vPads) * 2 + 1
            pad_drill = pcbnew.FromMM(0.3)
            
            exp_n_h = int(pcbnew.ToMM(exposed_h)) 
            exp_n_v = int(pcbnew.ToMM(exposed_v))
            exp_l_h = exposed_h / exp_n_h
            exp_w_v = exposed_v / exp_n_v
            exp_pad = PA.PadMaker(self.module).THPad(exp_l_h, exp_w_v, pad_drill, shape=pcbnew.PAD_RECT, rot_degree=90.0)
        
            #generate drills to improve thermal flow trough PCB
            for exp_x in range(0, exp_n_h):
                for exp_y in range(0, exp_n_v):
                    exp_val_h = (-(exp_n_h - 1) / 2.0 + exp_x) * exp_l_h
                    exp_val_v = (-(exp_n_v - 1) / 2.0 + exp_y) * exp_w_v
                    exp_pad_pos = pcbnew.wxPoint(exp_val_h, exp_val_v)
                    array = PA.PadLineArray(exp_pad, 1, 0, False, exp_pad_pos)
                    array.SetFirstPadInArray(pad_count)
                    array.AddPadsToModule(self.draw)
                
            #place additional pad to keep SolderPasteMask
            exp_pad = PA.PadMaker(self.module).SMDPad(exposed_h, exposed_v, shape=pcbnew.PAD_RECT, rot_degree=90.0)
            exp_pad_pos = pcbnew.wxPoint(0, 0)
            array = PA.PadLineArray(exp_pad, 1, 0, False, exp_pad_pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
                        
        # pad calculations
        pad_rounded = views['*' + self.view_rounded]
        pad_fiducials = views['*' + self.view_fiducials]
        
        pad_length_h = self.roundmeup((Z_max_h - G_min_h) / 2, pcbnew.FromMM(pROUND))
        pad_length_v = self.roundmeup((Z_max_v - G_min_v) / 2, pcbnew.FromMM(pROUND))
        
        h_distance = self.roundmeup((Z_max_h + G_min_h) / 2, pcbnew.FromMM(pROUND))
        v_distance = self.roundmeup((Z_max_v + G_min_v) / 2, pcbnew.FromMM(pROUND))
        
        # checking pad conflicts (rectangular shape check also for rounded pads used)
        pad_left_over = ((h_distance - pad_length_h) / 2) - ((hPads - 1) * pad_pitch + pad_width) / 2
        pad_top_under = ((v_distance - pad_length_v) / 2) - ((vPads - 1) * pad_pitch + pad_width) / 2
        pad_distance  = (pad_left_over ** 2 + pad_top_under ** 2) ** (1 / 2)
        if (pad_left_over < clearance) and (pad_top_under < clearance):
            if (pad_left_over < 0) or (pad_top_under < 0): 
                pad_distance = -pad_distance
            if pad_distance < clearance:
                pad_correction = ((clearance ** 2) / 2) ** (1 / 2)
                pad_correction_h = self.roundmeup(pad_left_over - pad_correction, pcbnew.FromMM(pROUND))
                pad_correction_v = self.roundmeup(pad_top_under - pad_correction, pcbnew.FromMM(pROUND))
                pad_length_h += pad_correction_h
                pad_length_v += pad_correction_v
                h_distance -= pad_correction_h
                v_distance -= pad_correction_v
                h_distance = self.roundmeup(h_distance, pcbnew.FromMM(pROUND))
                v_distance = self.roundmeup(v_distance, pcbnew.FromMM(pROUND))
        
        # building pads
        pad_shape = pcbnew.PAD_SHAPE_OVAL if pad_rounded and not Pullback else pcbnew.PAD_SHAPE_RECT

        h_pad = PA.PadMaker(self.module).SMDPad( pad_length_h, pad_width, shape=pad_shape, rot_degree=90.0)
        v_pad = PA.PadMaker(self.module).SMDPad( pad_length_v, pad_width, shape=pad_shape)
        
        vPad_startsize = vPads // 2
        vPad_endsize   = vPads - vPad_startsize
        hPad_startsize = hPads // 2
        hPad_endsize   = hPads - hPad_startsize
        
        if not IEC_Level:
            pad_count = nPads - vPad_startsize + 1 if pad_home_centered else nPads - vPads + 1
            
            #left row start
            pin1Pos = pcbnew.wxPoint(-h_distance / 2, -pad_pitch * (vPads - vPad_startsize) / 2)
            array = PA.PadLineArray(h_pad, vPad_startsize, pad_pitch, True, pin1Pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
            
            #left row end
            pad_count = 1 if pad_home_centered else nPads - vPad_endsize + 1
            
            pin1Pos = pcbnew.wxPoint(-h_distance / 2, pad_pitch * (vPads - vPad_endsize) / 2)
            array = PA.PadLineArray(h_pad, vPad_endsize, pad_pitch, True, pin1Pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
            
            pad_count = vPad_endsize + 1 if pad_home_centered else 1
        else:
            pad_count = vPad_endsize + 1 if pad_home_centered else 1
            
            #left row
            pin1Pos = pcbnew.wxPoint(-h_distance / 2, 0)
            array = PA.PadLineArray(h_pad, vPads, pad_pitch, True, pin1Pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
            
            pad_count += vPads

        #bottom row
        pin1Pos = pcbnew.wxPoint(0, v_distance / 2)
        array = PA.PadLineArray(v_pad, hPads, pad_pitch, False, pin1Pos)
        array.SetFirstPadInArray(pad_count)
        array.AddPadsToModule(self.draw)
        
        pad_count += hPads

        #right row
        pin1Pos = pcbnew.wxPoint(h_distance / 2, 0)
        array = PA.PadLineArray(h_pad, vPads, -pad_pitch, True, pin1Pos)
        array.SetFirstPadInArray(pad_count)
        array.AddPadsToModule(self.draw)
        
        if IEC_Level:
            pad_count = nPads - hPad_startsize + 1 if pad_home_centered else nPads - hPads + 1
            
            #top row start
            pin1Pos = pcbnew.wxPoint(pad_pitch * (hPads - hPad_startsize) / 2, -v_distance / 2)
            array = PA.PadLineArray(v_pad, hPad_startsize, -pad_pitch, False, pin1Pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
            
            #top row end
            pad_count = 1 if pad_home_centered else nPads - hPad_endsize + 1
            
            pin1Pos = pcbnew.wxPoint(-pad_pitch * (hPads - hPad_endsize) / 2, -v_distance / 2)
            array = PA.PadLineArray(v_pad, hPad_endsize, -pad_pitch, False, pin1Pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
        else:
            pad_count += vPads

            #top row
            pin1Pos = pcbnew.wxPoint(0, -v_distance / 2)
            array = PA.PadLineArray(v_pad, hPads, -pad_pitch, False, pin1Pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
        
        #Fiducials
        if pad_fiducials:
            pad_count = (hPads + vPads) * 2 + 2
            fid_pad = PA.PadMaker(self.module).SMDPad(pcbnew.FromMM(1), pcbnew.FromMM(1), shape=pcbnew.PAD_OVAL)
            fid_pad.SetLocalSolderMaskMargin(pcbnew.FromMM(0.5))
            
            if IEC_Level:
                fid_pad_pos = pcbnew.wxPoint(-h_distance / 2, v_distance / 2)
            else:
                fid_pad_pos = pcbnew.wxPoint(-h_distance / 2, -v_distance / 2)
            array = PA.PadLineArray(fid_pad, 1, 0, False, fid_pad_pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
            
            pad_count += 1
            
            if IEC_Level:
                fid_pad_pos = pcbnew.wxPoint(h_distance / 2, -v_distance / 2)
            else:
                fid_pad_pos = pcbnew.wxPoint(h_distance / 2, v_distance / 2)
            array = PA.PadLineArray(fid_pad, 1, 0, False, fid_pad_pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
        
        # Graphics
        lim_x = package[self.body_length_max] / 2
        lim_y = package[self.body_width_max] / 2
    
        bevel = lim_y * views['*' + self.view_bevel] * 2 / 100
        bevel_h = lim_x - bevel
        bevel_v = lim_y - bevel
        
        # Fabrication graphics
        self.draw.SetLayer(pcbnew.F_Fab)
        self.draw.SetLineTickness(pcbnew.FromMM(0.1))
        if IEC_Level:
            self.draw.Polyline([(-lim_x, -bevel_v), (-bevel_h, -lim_y), (lim_x, -lim_y), (lim_x, lim_y), (-lim_x, lim_y), (-lim_x, -bevel_v)])
            if silk_index:
                if pad_home_centered:
                    self.draw.Circle(pad_pitch * ((hPads - 1) / 2 - hPad_endsize + 1), -lim_y + pcbnew.FromMM(0.75), pcbnew.FromMM(0.5), filled=False)    
                else:
                    pad_pos = -pad_pitch * (vPads - 1 ) / 2
                    if pad_pos - pcbnew.FromMM(0.75) < -lim_y:
                        pad_pos = -lim_y + pcbnew.FromMM(0.75)
                    self.draw.Circle(-lim_x + pcbnew.FromMM(0.75), pad_pos, pcbnew.FromMM(0.5), filled=False)  
        else:
            self.draw.Polyline([(-lim_x, bevel_v), (-bevel_h, lim_y), (lim_x, lim_y), (lim_x, -lim_y), (-lim_x, -lim_y), (-lim_x, bevel_v)])
            if silk_index:
                if pad_home_centered:
                    self.draw.Circle(-lim_x + pcbnew.FromMM(0.75), pad_pitch * ((vPads - 1) / 2 - vPad_endsize + 1), pcbnew.FromMM(0.5), filled=False)    
                else:
                    pad_pos = -pad_pitch * (hPads - 1 ) / 2
                    if pad_pos - pcbnew.FromMM(0.75) < -lim_x:
                        pad_pos = -lim_x + pcbnew.FromMM(0.75)
                    self.draw.Circle(pad_pos, lim_y - pcbnew.FromMM(0.75), pcbnew.FromMM(0.5), filled=False)
        
        # calculate silk
        self.draw.SetLayer(pcbnew.F_SilkS)
        self.draw.SetLineTickness(manufacturing[self.fab_silk_width])
        silk_clearance = manufacturing[self.fab_clearance] + manufacturing[self.fab_silk_width] / 2
        outline_distance_v = (v_distance + pad_length_v) / 2 + silk_clearance
        outline_distance_h = (h_distance + pad_length_h) / 2 + silk_clearance
        inline_distance_v = (v_distance - pad_length_v) / 2 - silk_clearance
        inline_distance_h = (h_distance - pad_length_h) / 2 - silk_clearance
        slk_area_h = pad_area_h / 2 + silk_clearance
        slk_area_v = pad_area_v / 2 + silk_clearance
        if silk_outline:
            #lim_x = slk_area_h if vPads == 0 else outline_distance_h
            lim_x = self.SetMinVal(lim_x + manufacturing[self.fab_silk_width], slk_area_h if vPads == 0 else outline_distance_h)
            #lim_y = slk_area_v if hPads == 0 else outline_distance_v
            lim_y = self.SetMinVal(lim_y + manufacturing[self.fab_silk_width], slk_area_v if hPads == 0 else outline_distance_v)
        else:
            lim_x += manufacturing[self.fab_silk_width]
            lim_y += manufacturing[self.fab_silk_width]
        
        if hPads == 0:
            inner_h = 0
        else:
            if lim_y < outline_distance_v:
                if lim_y > inline_distance_v:
                    if lim_x < slk_area_h:
                        lim_y = inline_distance_v
                        inner_h = 0
                    else:
                        inner_h = slk_area_h
                else:
                    inner_h = 0
            else:
                inner_h = 0
        
        if vPads == 0:
            inner_v = 0 
        else:
            if lim_x < outline_distance_h:
                if lim_x > inline_distance_h:
                    if lim_y < slk_area_v:
                        lim_x = inline_distance_h
                        inner_v = 0
                    else:
                        inner_v = slk_area_v
                else:
                    inner_v = 0
            else:
                inner_v = 0
        
        bevel_h = lim_x - bevel
        bevel_v = lim_y - bevel
        
        if bevel_h < inner_h:
            bevel_v += (inner_h - bevel_h)
            bevel_h = inner_h
        if bevel_v < inner_v:
            bevel_h += (inner_v - bevel_v)
            bevel_v = inner_v
        if IEC_Level:
            # top left
            self.draw.Polyline([(-lim_x, -inner_v), (-lim_x, -bevel_v), (-bevel_h, -lim_y), (-inner_h, -lim_y)])
            # top right
            self.draw.Polyline([(inner_h, -lim_y), (lim_x, -lim_y), (lim_x, -inner_v)])
            # bottom left
            self.draw.Polyline([(-inner_h, lim_y), (-lim_x, lim_y), (-lim_x, inner_v)])
            # bottom right
            self.draw.Polyline([(inner_h, lim_y), (lim_x, lim_y), (lim_x, inner_v)])
        else:
            # top left
            self.draw.Polyline([(-inner_h, -lim_y), (-lim_x, -lim_y), (-lim_x, -inner_v)])
            # top right
            self.draw.Polyline([(inner_h, -lim_y), (lim_x, -lim_y), (lim_x, -inner_v)])
            # bottom left
            self.draw.Polyline([(-lim_x, inner_v), (-lim_x, bevel_v), (-bevel_h, lim_y), (-inner_h, lim_y)])
            # bottom right
            self.draw.Polyline([(inner_h, lim_y), (lim_x, lim_y), (lim_x, inner_v)])
        
        #index
        if silk_index:
            self.draw.SetLayer(pcbnew.F_SilkS)
            self.draw.SetLineTickness(manufacturing[self.fab_silk_width])
            index_clearance = silk_clearance + views[self.view_index] / 2
            
            if IEC_Level: # A
                if pad_home_centered: # top centered above pin 1
                    index_h = pad_pitch * ((hPads - 1) / 2 - hPad_endsize + 1)
                    if lim_y < (v_distance + pad_length_v) / 2:
                        index_v = -(v_distance + pad_length_v) / 2 - index_clearance
                        index_v = self.SetMaxVal(index_v, -(lim_y + index_clearance))
                    else:
                        index_v = -(lim_y + index_clearance)
                else:                 # left, above pin 1
                    index_v = -pad_pitch * (vPads - 1 ) / 2
                    if lim_x < (h_distance + pad_length_h) / 2:
                        index_v -= (pad_width / 2 + index_clearance)
                        index_h = -h_distance / 2
                        index_h = self.SetMaxVal(index_h, -(lim_x + index_clearance))
                    else:
                        index_h = -(lim_x + index_clearance)
            else:         # B
                if pad_home_centered: # left centered left from pin 1
                    index_v = pad_pitch * ((vPads - 1) / 2 - vPad_endsize + 1) 
                    if lim_x < (h_distance + pad_length_h) / 2:
                        index_h = -(h_distance + pad_length_h) / 2 - index_clearance
                        index_h = self.SetMaxVal(index_h, -(lim_x + index_clearance))
                    else:
                        index_h = -(lim_x + index_clearance)
                else:                 # bottom, left from pin 1
                    index_h = -pad_pitch * (hPads - 1 ) / 2
                    if lim_y < (v_distance + pad_length_v) / 2:
                        index_h -= (pad_width / 2 + index_clearance)
                        index_v = v_distance / 2  
                        index_v = self.SetMinVal(index_v, lim_y + index_clearance)
                    else:
                        index_v = lim_y + index_clearance
                    
                    
            self.draw.Circle(index_h, index_v, pcbnew.FromMM(pcbnew.ToMM(views[self.view_index]) / 2), filled=True)
            #self.draw.Circle(index_h, index_v, views[self.view_index] / 2, filled=True)
            
        # Courtyard
        cmargin = pcbnew.FromMM(pCOURT[ipc_level])
        
        size_x = self.roundmeup(Z_max_h + cmargin * 2, pcbnew.FromMM(pROUND))
        size_y = self.roundmeup(Z_max_v + cmargin * 2, pcbnew.FromMM(pROUND))
        
        self.draw.SetLayer(pcbnew.F_CrtYd)
        self.draw.SetLineTickness(pcbnew.FromMM(0.05))
        self.draw.Box(0, 0, size_x, size_y)
        self.draw.Line(pcbnew.FromMM(-0.25), 0, pcbnew.FromMM(0.25), 0)
        self.draw.Line(0, pcbnew.FromMM(-0.25), 0, pcbnew.FromMM(0.25))
        
        #reference and value
        text_size = self.GetTextSize()  # IPC nominal
        #text_offset = v_distance / 2 + text_size + pad_length_v / 2
        
        text_offset = size_y / 2 + text_size + manufacturing[self.fab_silk_width]
        text_offset = self.SetMinVal(text_offset, lim_y + manufacturing[self.fab_silk_width])
        
        self.draw.Value(0, text_offset, text_size)
        self.draw.Reference(0, -text_offset, text_size)

MyWizard().register()
