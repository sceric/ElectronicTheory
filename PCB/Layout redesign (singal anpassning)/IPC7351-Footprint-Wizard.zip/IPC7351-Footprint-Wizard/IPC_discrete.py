#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#
#  Coding and Design, Data Evaluation and Integration by
#  Daniel Schoeni, http://elnet.ch/
#  based on other KiCad footprint wizards.
#  This is my first Python project. So please excuse some coding mistakes ...
#

from __future__ import division
import pcbnew
import os
import math

import HelpfulFootprintWizardPlugin
import PadArray as PA


class MyWizard(HelpfulFootprintWizardPlugin.HelpfulFootprintWizardPlugin):

    def GetName(self):
        return "IPC-7351 Discrete SMD"

    def GetDescription(self):
        return "IPC-7351B compliant footprint wizard"
    
    MY_name          = 'Footprint Name'
  
    ipc_suffix            = ["","M","N","L"]
    ipc_level        = 'Level: 1,2,3 (-> A,B,C)'
        
    body_width_min   = 'Body Width Min.'   
    body_width_max   = 'Body Width Max.'   
    body_length_min  = 'Body Length Min.'  
    body_length_max  = 'Body Length Max.'  
    body_height_max  = 'Max. Height'
    body_standoff    = 'Standoff Max.'
    term_type        = 'Type (0,1,2,3,4 -> Chip, Molded, Leaded, Leadless, MELF)'
    view_name_prefix = 'Name Prefix (0,1,2,3,4 -> SOT,RES,CAP,IND,DIO)'
                   
    term_pos_bas     = 'Positions first Side'
    term_pitch       = 'Pitch'
    term_pos_opp     = 'opposite Positions'
    term_pitch_opp   = 'opposite Pitch'
    span_width_min   = 'Span Width Min.'
    span_width_max   = 'Span Width Max.'
    
    term_width_min   = 'Terminal Width Min.'
    term_width_max   = 'Terminal Width Max.'
    term_length_min  = 'Terminal Length Min.'
    term_length_max  = 'Terminal Length Max.'
        
    view_index       = 'Index'
    view_rounded     = 'Rounded Pads'
    view_pol_mark    = 'Polarity Mark (optional)'
    view_outline     = 'Outline Outside'
    view_IEC_level   = 'IEC 61188-7 Level (0,1 -> A,B)'
    view_name_unlock = 'Name Override'
        
    fab_fab_tol      = 'Fabrication Tolerance'
    fab_ass_tol      = 'Assembly Tolerance'
    fab_silk_width   = 'Silk Width'
    fab_clearance    = 'Clearance'
                   
    hint_start       = 'Show PDF'
    
    term_width  = 0
    term_length = 0
    term_span_width  = 0
    #term_span_length = 0
    body_width       = 0
    body_length      = 0
    body_height      = 0
    
    IEC_map          = True
        
    def GenerateParameterList(self):
    
        self.AddParam("IPC", self.ipc_level, self.uNatural, 2)
        
        self.AddParam("Package", self.body_width_min,   self.uMM, 8)
        self.AddParam("Package", self.body_width_max,   self.uMM, 8)
        self.AddParam("Package", self.body_length_min,  self.uMM, 8)
        self.AddParam("Package", self.body_length_max,  self.uMM, 8)
        self.AddParam("Package", self.body_height_max,  self.uMM, 10)
        self.AddParam("Package", self.body_standoff,    self.uMM, 0.3)
        self.AddParam("Package", self.term_type,        self.uNatural, 2)
        self.AddParam("Package", self.view_name_prefix, self.uNatural, 2)
        
        self.AddParam("Shape", self.term_pos_bas,    self.uNatural, 1)
        self.AddParam("Shape", self.term_pitch,      self.uMM, 0.8)
        self.AddParam("Shape", self.term_pos_opp,    self.uNatural, 1)
        self.AddParam("Shape", self.term_pitch_opp,  self.uMM, 0.8)
        self.AddParam("Shape", self.span_width_min,  self.uMM, 10.4)
        self.AddParam("Shape", self.span_width_max,  self.uMM, 10.8)
        
        self.AddParam("Terminals", self.term_width_min,  self.uMM, 1.1)
        self.AddParam("Terminals", self.term_width_max,  self.uMM, 1.1)
        self.AddParam("Terminals", self.term_length_min, self.uMM, 3.5)
        self.AddParam("Terminals", self.term_length_max, self.uMM, 3.8)
                
        self.AddParam("Views", self.view_index,       self.uMM, 0.5)
        self.AddParam("Views", self.view_rounded,     self.uBool, False)
        self.AddParam("Views", self.view_pol_mark,    self.uNatural, 0)
        self.AddParam("Views", self.view_outline,     self.uBool, 0)
        self.AddParam("Views", self.view_IEC_level,   self.uBool, True)
        self.AddParam("Views", self.view_name_unlock, self.uBool, 0)
        self.AddParam("Views", self.MY_name,          self.uString, 'Footprint Name')
        
        self.AddParam("Manufacturing", self.fab_fab_tol,    self.uMM, 0.1)
        self.AddParam("Manufacturing", self.fab_ass_tol,    self.uMM, 0.1)
        self.AddParam("Manufacturing", self.fab_silk_width, self.uMM, 0.15)
        self.AddParam("Manufacturing", self.fab_clearance,  self.uMM, 0.2)
        
        self.AddParam("Hints", self.hint_start, self.uBool, 0)
        
    def roundmeup(self, mynumber, mystep):
        return math.ceil(mynumber / mystep) * mystep
    
    def SetMinVal(self, destination, source):
        if destination < source:
            destination = source
        return destination

    def SetMaxVal(self, destination, source):
        if destination > source:
            destination = source 
        return destination

    def CheckHints(self, section, param):
        #param must be boolean
        if str(self.parameters[section][param]).lower() in [
                "true", "t", "y", "yes", "on", "1", "1.0"]:
            self.parameters[section][param] = False
            os.startfile("IPC-7351B-Hints.pdf") # Must be in KiCad main directory, command might be changed for LINUX or Apples
            return
        return

    def CheckParameters(self):
        self.CheckParamBool("Views", '*' + self.view_rounded)
        self.CheckParamBool("Views", '*' + self.view_name_unlock)
        self.CheckParamBool("Views", '*' + self.view_outline)
        self.CheckParamInt("IPC", '*' + self.ipc_level, min_value=0, max_value=3)
        self.CheckParamInt("Package", '*' + self.term_type, min_value=0, max_value=4)
        self.CheckParamInt("Package", '*' + self.view_name_prefix, min_value=0, max_value=4)
        self.CheckParamBool("Views", '*' + self.view_IEC_level)
        self.CheckParamBool("Views", '*' + self.view_pol_mark)
        self.CheckHints("Hints", '*' + self.hint_start)
        terminals = self.parameters["Terminals"]
        if terminals[self.term_width_max] < terminals[self.term_width_min]: 
            terminals[self.term_width_max] = terminals[self.term_width_min]
        if terminals[self.term_length_max] < terminals[self.term_length_min]: 
            terminals[self.term_length_max] = terminals[self.term_length_min] 
        shape = self.parameters["Shape"]
        if shape[self.span_width_max] < shape[self.span_width_min]: 
            shape[self.span_width_max] = shape[self.span_width_min]
        package = self.parameters["Package"]
        if package[self.body_length_max] < package[self.body_length_min]: 
            package[self.body_length_max] = package[self.body_length_min]
        if package[self.body_width_max] < package[self.body_width_min]: 
            package[self.body_width_max] = package[self.body_width_min]
        p_term_type = package['*' + self.term_type]
        if (p_term_type == 0) or (p_term_type == 3):
            shape[self.span_width_max] = package[self.body_width_max]
            shape[self.span_width_min] = package[self.body_width_min]
        if (p_term_type == 0):
            terminals[self.term_width_max] = package[self.body_length_max]
            terminals[self.term_width_min] = package[self.body_length_min]
        
        self.term_width       = pcbnew.ToMM(terminals[self.term_width_max]  + terminals[self.term_width_min])  / 2
        self.term_length      = pcbnew.ToMM(terminals[self.term_length_max] + terminals[self.term_length_min]) / 2
        self.term_span_width  = pcbnew.ToMM(shape[self.span_width_max]  + shape[self.span_width_min])  / 2
        self.body_width       = pcbnew.ToMM(package[self.body_width_max]  + package[self.body_width_min])  / 2
        self.body_length      = pcbnew.ToMM(package[self.body_length_max] + package[self.body_length_min]) / 2
        self.body_height      = pcbnew.ToMM(package[self.body_height_max]) # - package[self.body_standoff])
        
    def GetValue(self):
        views = self.parameters["Views"]
            
        if not views['*' + self.view_name_unlock]:
            ipc_level = self.parameters["IPC"]['*' + self.ipc_level]
            shape = self.parameters["Shape"]
            package = self.parameters["Package"]
            terminals = self.parameters["Terminals"]
            silk_index = views[self.view_index] > 0
            
            pad_pitch = shape[self.term_pitch]
            hPads = shape['*' + self.term_pos_bas]
            vPads = shape['*' + self.term_pos_opp]
            nPads = (hPads + vPads)
        
            p_term_type = package['*' + self.term_type]             #'Type (0,1,2,3,4 -> Chip, Molded, Leaded, Leadless, MELF)'
            name_prefix = package['*' + self.view_name_prefix] #'Name Prefix (0,1,2,3,4 -> SOT,RES,CAP,IND,DIO)'
            
            name_values = ["SOT","RES","CAP","IND","DIO"]
            MY_name = ""
            if name_prefix == 0:
                if p_term_type == 3:
                    MY_name = "SON"
                else:
                    T_Pack  = False if (package[self.body_height_max] - package[self.body_standoff]) > pcbnew.FromMM(1.6) else True
                    if T_Pack:
                        MY_name += "T"
                    S_Pack  = False if pad_pitch > pcbnew.FromMM(0.625) else True
                    if S_Pack:
                        MY_name += "S"
                    MY_name += "SOT"
            else:
                MY_name += name_values[name_prefix]
                if p_term_type == 0:
                    MY_name += "C"
                    if silk_index and (name_prefix == 2):
                        MY_name += "P"
                elif p_term_type == 1:
                    MY_name += "M"
                    if silk_index and (name_prefix == 2):
                        MY_name += "P"
                elif p_term_type == 2:
                    if name_prefix == 2:
                        MY_name += "AE"    
                    elif name_prefix == 3:
                        MY_name += "P"
                    elif name_prefix == 4:
                        MY_name = "SOD"
                    else:
                        MY_name = "SO"   
                elif p_term_type == 3:
                    MY_name = "SON"
                elif p_term_type == 4:
                    MY_name += "MELF"  
            
            if nPads > 2:
                MY_name += "%03dP" % (pcbnew.ToMM(pad_pitch) * 100)
            nominal_width  = self.term_span_width  if (self.term_span_width > self.body_width) else self.body_width
            if p_term_type in [0, 1]:
                MY_name += "%02d" % (nominal_width * 10)
            else:
                if nominal_width >= 10:
                    MY_name += "%dX" % (nominal_width * 100)
                else:
                    MY_name += "%03dX" % (nominal_width * 100)
            nominal_length = self.body_length
            if p_term_type in [0, 1]:
                MY_name += "%02dX" % (nominal_length * 10)
            else:
                if nominal_length >= 10:
                    MY_name += "%dX" % (nominal_length * 100)
                else:
                    MY_name += "%03dX" % (nominal_length * 100)
            if p_term_type in [0, 1]:
                MY_name += "%02d" % (self.body_height * 10)
            else:
                if self.body_height >= 10:
                    MY_name += "%d" % (self.body_height * 100)
                else:
                    MY_name += "%03d" % (self.body_height * 100)
            if nPads > 2:
                MY_name += "-%d" % nPads
            MY_name += self.ipc_suffix[ipc_level]
            
            views['*' + self.MY_name] = MY_name
        
        return "{}".format(self.parameters["Views"]['*' + self.MY_name])
        
    def BuildThisFootprint(self):
        
        ipc_level = self.parameters["IPC"]['*' + self.ipc_level]

        views = self.parameters["Views"]
        IEC_Level = not views['*' + self.view_IEC_level]
        silk_outline = views['*' + self.view_outline]
        silk_index = views[self.view_index] > 0
        
        shape = self.parameters["Shape"]
        package = self.parameters["Package"]
        
        manufacturing = self.parameters["Manufacturing"]
        clearance = manufacturing[self.fab_clearance]
        
        terminals = self.parameters["Terminals"]
        pad_pitch = shape[self.term_pitch]
        pad_pitch_opp = shape[self.term_pitch_opp]
        hPads = shape['*' + self.term_pos_bas]
        vPads = shape['*' + self.term_pos_opp]
        nPads = hPads + vPads
        
        name_prefix = package['*' + self.view_name_prefix]
        p_term_type = package['*' + self.term_type]
            
        J_Pack  = self.body_width  > (self.term_span_width  - 2 * self.term_length) 
        S_Pack  = False if pad_pitch > pcbnew.FromMM(0.625) else True
        T_Pack  = False if (package[self.body_height_max] - package[self.body_standoff]) > pcbnew.FromMM(1.6) else True
        H_Cap   = not (package[self.body_height_max] < pcbnew.FromMM(10))
        S_Chip  = package[self.body_width_max] < pcbnew.FromMM(1.6)
        
        #    p_term_type = 0,1,2,3,4 -> Chip, Molded, Leaded, Leadless, MELF)'
        #    name_prefix = 0,1,2,3,4 -> SOT,RES,CAP,IND,DIO)'

        #IPC parameters
        if p_term_type == 0:
            pTOE    = [0,0.55,0.35,0.15] if not S_Chip else [0,0.3,0.2,0.1]
            pHEEL_n = [0,0,0,0]
            pHEEL_s = [0,0,0,0]
            pSIDE   = [0,0.05,0,-0.05]
            pROUND = 0.05 if not S_Chip else 0.02
            pCOURT = [0,0.5,0.25,0.1] if not S_Chip else [0,0.2,0.15,0.1]
        elif p_term_type == 1:
            pTOE    = [0,0.25,0.15,0.07]
            pHEEL_n = [0,0.8,0.5,0.2]
            pHEEL_s = [0,0.8,0.5,0.2]
            pSIDE   = [0,0.01,-0.05,-0.1]
            pROUND = 0.05
            pCOURT = [0,0.5,0.25,0.1]
        elif p_term_type == 2:
            if (name_prefix == 2) and (nPads == 2):
                pTOE    = [0,0.7,0.5,0.3] if not H_Cap else [0,1,0.7,0.4]
                pHEEL_n = [0,0,-0.1,-0.2] if not H_Cap else [0,0,-0.05,-0.1]
                pHEEL_s = [0,0,-0.1,-0.2] if not H_Cap else [0,0,-0.05,-0.1]
                pSIDE   = [0,0.5,0.4,0.3] if not H_Cap else [0,0.6,0.5,0.4]
                pROUND = 0.05
                pCOURT = [0,1,0.5,0.25]
            else:
                pTOE    = [0,0.55,0.35,0.15]
                pHEEL_n = [0,0.45,0.35,0.25]
                pHEEL_s = [0,0.25,0.15,0.05] if not J_Pack else [0,0.1,0,-0.1]
                pSIDE   = [0,0.05,0.03,0.01] if not S_Pack else [0,0.01,-0.02,-0.04]
                pROUND = 0.05
                pCOURT = [0,0.5,0.25,0.1]
        elif p_term_type == 3:
            pTOE    = [0,0.4,0.3,0.2]
            pHEEL_n = [0,0,0,0]
            pHEEL_s = [0,0,0,0]
            pSIDE   = [0,-0.04,-0.04,-0.04]
            pROUND = 0.05
            pCOURT = [0,0.5,0.25,0.1]
        else:
            pTOE    = [0,0.6,0.4,0.2]
            pHEEL_n = [0,0.2,0.1,0.02]
            pHEEL_s = [0,0.2,0.1,0.02]
            pSIDE   = [0,0.1,0.05,0.01]
            pROUND = 0.05
            pCOURT = [0,0.5,0.25,0.1]
        
        #calculating distances and tolerances
        F_tol    = manufacturing[self.fab_fab_tol]
        P_tol    = manufacturing[self.fab_ass_tol]
        T_tol    = terminals[self.term_length_max] - terminals[self.term_length_min] 
        W_tol    = terminals[self.term_width_max]  - terminals[self.term_width_min] 
        
        pad_width = self.roundmeup(terminals[self.term_width_min] + 2 * pcbnew.FromMM(pSIDE[ipc_level]) + (W_tol ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2), pcbnew.FromMM(pROUND))
        pad_width_opp = pad_width
        if (hPads > 1) and (pad_width > (pad_pitch - manufacturing[self.fab_clearance])):
            pad_width = pad_pitch - manufacturing[self.fab_clearance]
        if (vPads > 1) and (pad_width_opp > (pad_pitch_opp - manufacturing[self.fab_clearance])):
            pad_width_opp = pad_pitch_opp - manufacturing[self.fab_clearance]
        
        pad_area_h = ((hPads - 1) * pad_pitch) + pad_width
        pad_area_v = ((vPads - 1) * pad_pitch_opp) + pad_width_opp
        
        L_tol_v  = shape[self.span_width_max] - shape[self.span_width_min]
        Z_max_v  = shape[self.span_width_min] + 2 * pcbnew.FromMM(pTOE[ipc_level]) + (L_tol_v ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)
        
        L_tol_h  = package[self.body_length_max] - package[self.body_length_min]
        Z_max_h  = package[self.body_length_min] + (L_tol_h ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)
        Z_max_h  = self.SetMinVal(Z_max_h, pad_area_h)
        Z_max_h  = self.SetMinVal(Z_max_h, pad_area_v)
        
        S_tol_v  = L_tol_v + 2 * T_tol
        dS_tol_v = S_tol_v - (L_tol_v ** 2 + 2 * T_tol ** 2) ** (1 / 2)
        S_min_v  = shape[self.span_width_min] - 2 * terminals[self.term_length_max] + dS_tol_v / 2
        S_max_v  = shape[self.span_width_max] - 2 * terminals[self.term_length_min] - dS_tol_v / 2
        pHEEL = pHEEL_n if S_min_v > package[self.body_width_max] else pHEEL_s
        G_min_v  = S_max_v - 2 * pcbnew.FromMM(pHEEL[ipc_level]) - (S_tol_v ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)
        if G_min_v < clearance: G_min_v = clearance
        
        # pad calculations
        pad_rounded = views['*' + self.view_rounded]
        
        pad_length_v = self.roundmeup((Z_max_v - G_min_v) / 2, pcbnew.FromMM(pROUND))
        
        v_distance = self.roundmeup((Z_max_v + G_min_v) / 2, pcbnew.FromMM(pROUND))
        
        # building pads
        if nPads == 2:
            IEC_Level = True
        
        pad_shape = pcbnew.PAD_SHAPE_OVAL if pad_rounded and (p_term_type in [2, 3]) else pcbnew.PAD_SHAPE_RECT

        h_pad     = PA.PadMaker(self.module).SMDPad( pad_length_v, pad_width, shape=pad_shape, rot_degree=90.0)
        h_pad_opp = PA.PadMaker(self.module).SMDPad( pad_length_v, pad_width_opp, shape=pad_shape, rot_degree=90.0)
        v_pad     = PA.PadMaker(self.module).SMDPad( pad_length_v, pad_width, shape=pad_shape)
        v_pad_opp = PA.PadMaker(self.module).SMDPad( pad_length_v, pad_width_opp, shape=pad_shape)
        
        pad_count =  1

        if IEC_Level:    
            #left row
            pin1Pos = pcbnew.wxPoint(-v_distance / 2, 0)
            array = PA.PadLineArray(h_pad, hPads, pad_pitch, True, pin1Pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
        else:
            #bottom row
            pin1Pos = pcbnew.wxPoint(0, v_distance / 2)
            array = PA.PadLineArray(v_pad, hPads, pad_pitch, False, pin1Pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
        
        pad_count += hPads

        if IEC_Level:    
            #right row
            pin1Pos = pcbnew.wxPoint(v_distance / 2, 0)
            array = PA.PadLineArray(h_pad_opp, vPads, -pad_pitch_opp, True, pin1Pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
        else:
            #top row
            pin1Pos = pcbnew.wxPoint(0, -v_distance / 2)
            array = PA.PadLineArray(v_pad_opp, vPads, -pad_pitch_opp, False, pin1Pos)
            array.SetFirstPadInArray(pad_count)
            array.AddPadsToModule(self.draw)
        
        # Graphics
        lim_x = package[self.body_length_max] / 2
        lim_y = package[self.body_width_max] / 2
    
        polarity_mark = views['*' + self.view_pol_mark]
        
        # Fabrication graphics
        self.draw.SetLayer(pcbnew.F_Fab)
        self.draw.SetLineTickness(pcbnew.FromMM(0.1))
        if IEC_Level:
            if (p_term_type == 2) and (name_prefix == 2) and (nPads == 2):
                bevel_h = lim_x - self.SetMaxVal(lim_x / 2, lim_y / 2)
                bevel_v = lim_y - self.SetMaxVal(lim_x / 2, lim_y / 2)
                self.draw.Polyline([(-lim_y,-bevel_h), (-bevel_v,-lim_x), ( lim_y,-lim_x), ( lim_y, lim_x), (-bevel_v, lim_x), (-lim_y, bevel_h), (-lim_y,-bevel_h)])
            else:
                self.draw.Box(0, 0, package[self.body_width_max], package[self.body_length_max])
            if silk_index:
                pad_pos = -pad_pitch * (hPads - 1 ) / 2
                if pad_pos - pcbnew.FromMM(0.7) < -lim_x:
                    pad_pos = -lim_x + pcbnew.FromMM(0.7)
                self.draw.Circle(-(lim_y - pcbnew.FromMM(0.7)), pad_pos, pcbnew.FromMM(0.5), filled=False)
                if polarity_mark:
                    if (p_term_type == 2) and (name_prefix == 2): 
                        self.draw.Polyline([(lim_y - pcbnew.FromMM(0.7),-lim_x), (lim_y - pcbnew.FromMM(0.7),lim_x)])
                    else:
                        self.draw.Polyline([(-(lim_y - pcbnew.FromMM(0.7)),-lim_x), (-(lim_y - pcbnew.FromMM(0.7)),lim_x)])
        else:
            self.draw.Box(0, 0, package[self.body_length_max], package[self.body_width_max])
            if silk_index:
                pad_pos = -pad_pitch * (hPads - 1 ) / 2
                if pad_pos - pcbnew.FromMM(0.7) < -lim_x:
                    pad_pos = -lim_x + pcbnew.FromMM(0.7)
                self.draw.Circle(pad_pos, lim_y - pcbnew.FromMM(0.7), pcbnew.FromMM(0.5), filled=False)
        
        # calculate silk
        self.draw.SetLayer(pcbnew.F_SilkS)
        self.draw.SetLineTickness(manufacturing[self.fab_silk_width])
        silk_clearance = manufacturing[self.fab_clearance] + manufacturing[self.fab_silk_width] / 2
        slk_area_h = pad_area_h / 2 + silk_clearance
        slk_area_v = pad_area_v / 2 + silk_clearance
        
        outline_distance_v = (v_distance + pad_length_v) / 2 + silk_clearance
        inline_distance_v = (v_distance - pad_length_v) / 2 - silk_clearance
        
        if silk_outline:
            lim_x = self.SetMinVal(lim_x, slk_area_h)
            lim_x = self.SetMinVal(lim_x, slk_area_v)
            lim_y = outline_distance_v
        else:
            lim_x += manufacturing[self.fab_silk_width]
            lim_y += manufacturing[self.fab_silk_width]
        
        if (lim_y < outline_distance_v) or (lim_x < slk_area_h):
            inner_v = lim_y
            if lim_y > inline_distance_v:
                if lim_x < slk_area_h:
                    inner_v = inline_distance_v
                    inner_h = lim_x
                    inner_h_opp = lim_x
                else:
                    inner_h = slk_area_h
                    inner_h_opp = slk_area_v
            else:
                inner_h = 0
                inner_h_opp = 0
            
            if inner_v > 0:
                if IEC_Level:
                    if (p_term_type == 2) and (name_prefix == 2) and (nPads == 2):
                        bevel_h = lim_x - self.SetMaxVal(lim_x / 2, lim_y / 2)
                        bevel_v = lim_y - self.SetMaxVal(lim_x / 2, lim_y / 2)
                        if bevel_h < inner_h:
                            bevel_v += (inner_h - bevel_h)
                            bevel_h = inner_h
                        self.draw.Polyline([(-inner_v,-inner_h), (-inner_v,-bevel_h), (-bevel_v,-lim_x), ( inner_v,-lim_x), ( inner_v,-inner_h_opp)])
                        self.draw.Polyline([(-inner_v, inner_h), (-inner_v, bevel_h), (-bevel_v, lim_x), ( inner_v, lim_x), ( inner_v, inner_h_opp)])
                    else:
                        self.draw.Polyline([(-inner_v,-inner_h), (-inner_v,-lim_x), ( inner_v,-lim_x), ( inner_v,-inner_h_opp)])
                        self.draw.Polyline([(-inner_v, inner_h), (-inner_v, lim_x), ( inner_v, lim_x), ( inner_v, inner_h_opp)])
                else: 
                    self.draw.Polyline([(-inner_h_opp,-inner_v), (-lim_x,-inner_v), (-lim_x, inner_v), (-inner_h, inner_v)])
                    self.draw.Polyline([( inner_h_opp,-inner_v), ( lim_x,-inner_v), ( lim_x, inner_v), ( inner_h, inner_v)]) 
            if lim_y >= outline_distance_v:
                if IEC_Level:
                    self.draw.Polyline([(-outline_distance_v,-lim_x), (-lim_y,-lim_x), (-lim_y, lim_x), (-outline_distance_v, lim_x)])
                    self.draw.Polyline([( outline_distance_v,-lim_x), ( lim_y,-lim_x), ( lim_y, lim_x), ( outline_distance_v, lim_x)])
                else: 
                    self.draw.Polyline([(-lim_x,-outline_distance_v), (-lim_x,-lim_y), ( lim_x,-lim_y), ( lim_x,-outline_distance_v)])
                    self.draw.Polyline([(-lim_x, outline_distance_v), (-lim_x, lim_y), ( lim_x, lim_y), ( lim_x, outline_distance_v)]) 
        else:
            if IEC_Level:
                self.draw.Box(0, 0, lim_y * 2, lim_x * 2)
            else:
                self.draw.Box(0, 0, lim_x * 2, lim_y * 2)
            
        #index
        if silk_index: # draw index if enabled in views
            self.draw.SetLayer(pcbnew.F_SilkS)
            self.draw.SetLineTickness(manufacturing[self.fab_silk_width])
            index_clearance = silk_clearance + views[self.view_index] / 2
            
            index_h = -pad_pitch * (hPads - 1 ) / 2
                
            if lim_y < (v_distance + pad_length_v) / 2:
                index_h -= (pad_width / 2 + index_clearance)
                index_v = v_distance / 2  
                index_v = self.SetMinVal(index_v, lim_y + index_clearance)
            else:
                index_v = lim_y + index_clearance
                    
            if IEC_Level: # B
                self.draw.Circle(-index_v, index_h, pcbnew.FromMM(pcbnew.ToMM(views[self.view_index]) / 2), filled=True)
                if polarity_mark:
                    lin_v = lim_y - index_clearance
                    if lin_v < inline_distance_v:
                        inner_h = 0
                    if inner_h < lim_x:
                        if (p_term_type == 2) and (name_prefix == 2): 
                            self.draw.Polyline([( lin_v,-lim_x), ( lin_v,-inner_h)])
                            self.draw.Polyline([( lin_v, lim_x), ( lin_v, inner_h)])
                        else:
                            self.draw.Polyline([(-lin_v,-lim_x), (-lin_v,-inner_h)])
                            self.draw.Polyline([(-lin_v, lim_x), (-lin_v, inner_h)])
            else:         # A
                self.draw.Circle(index_h, index_v, pcbnew.FromMM(pcbnew.ToMM(views[self.view_index]) / 2), filled=True)
            
        # Courtyard
        cmargin = pcbnew.FromMM(pCOURT[ipc_level])
        
        L_tol_v  = package[self.body_width_max] - package[self.body_width_min]
        temp_val  = package[self.body_width_min] + (L_tol_h ** 2 + F_tol ** 2 + P_tol ** 2 ) ** (1 / 2)
        if Z_max_v < temp_val:
            Z_max_v = temp_val
        
        size_x = self.roundmeup(Z_max_h + cmargin * 2, pcbnew.FromMM(pROUND))
        size_y = self.roundmeup(Z_max_v + cmargin * 2, pcbnew.FromMM(pROUND))
        
        self.draw.SetLayer(pcbnew.F_CrtYd)
        self.draw.SetLineTickness(pcbnew.FromMM(0.05))
        if IEC_Level: # B
            self.draw.Box(0, 0, size_y, size_x)
        else:
            self.draw.Box(0, 0, size_x, size_y)
        self.draw.Line(pcbnew.FromMM(-0.25), 0, pcbnew.FromMM(0.25), 0)
        self.draw.Line(0, pcbnew.FromMM(-0.25), 0, pcbnew.FromMM(0.25))
        
        #reference and value
        text_size = self.GetTextSize()  # IPC nominal
        if IEC_Level: # B
            text_offset = size_x / 2 + text_size + manufacturing[self.fab_silk_width]
            text_offset = self.SetMinVal(text_offset, lim_x + manufacturing[self.fab_silk_width])
        else:
            text_offset = size_y / 2 + text_size + manufacturing[self.fab_silk_width]
            text_offset = self.SetMinVal(text_offset, lim_y + manufacturing[self.fab_silk_width])
        
        self.draw.Value(0, text_offset, text_size)
        self.draw.Reference(0, -text_offset, text_size)

MyWizard().register()
