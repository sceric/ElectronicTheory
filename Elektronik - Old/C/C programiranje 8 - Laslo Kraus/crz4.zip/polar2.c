/* Izmena podataka pomocu globalnih promenljivih.                    */

#include <stdio.h>
#include <math.h>

double x, y, r, fi;              /* Defincija globalnih podataka.    */

void polar () {                  /* Definicija funkcije.             */
  r  = sqrt (x * x + y * y);
  fi = (x == 0 && y == 0) ? 0 : atan2 (y, x); 
}

main () {                        /* Definicija glavnog programa.     */
  while (printf ("x,y? "), scanf ("%lf%lf", &x, &y), x != 1E38) {
    polar (); printf ("r,fi= %g, %g\n", r, fi);
  }
}
