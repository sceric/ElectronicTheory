/* Rekurzivna funkcija za odredjivanje binomnog koeficijenta.        */

int binko (int n, int k) {
  return (0 < k && k < n) ? (binko (n-1, k) + binko (n-1, k-1)) : 1;
}
