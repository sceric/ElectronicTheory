/* Funkcija za binarno pretrazivanje rastuce uredjenog niza.         */

int bitra (const int a[], int n, int k) {
  int d = 0, g = n-1, s;
  enum {NE, DA};

  while (d <= g)
    if (a [s = (d + g) / 2] == k)
      return DA;
    else if (k < a[s])
      g = s - 1;
    else
      d = s + 1;
  return NE;
}

/* Glavni program za prikazivanje rada funkcije bitra.               */

#include <stdio.h>

void main () {
  int a[30], n=0, k; char z;

  /* Citanje niza za pretrazivanje */
  printf ("Rastuci niz brojeva? ");
  do scanf ("%d%c", &a[n++], &z); while (z != '\n');
  putchar ('\n');

  /* Citanje i trazenje pojedinacnih brojeva */
  while (1) {
    printf ("Trazeni broj? "); scanf ("%d", &k);
  if (k == 9999) break;
    printf ("Trazeni broj se%s nalazi u nizu.\n",
                      (bitra(a,n,k) ? "" : " NE"));
  }
}
