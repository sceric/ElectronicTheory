/* Deklaracija funkcije za izracunavanje skalarnog proizvoda.        */

double skal_pro (const double a[], const double b[], int n) ;
