/* Izracunavanje skalarnog proizvoda pomocu funkcije skal_pro.       */

#include "skalpro.h"
#include <stdio.h>

main () {
  double x[100], y[100];
  int i, k;

  printf ("Duzina vektora: "); scanf ("%d", &k);
  printf ("Komponente vektora X: ");
  for (i=0; i<k; scanf ("%lf", &x[i++]));
  printf ("Komponente vektora Y: ");
  for (i=0; i<k; scanf ("%lf", &y[i++]));

  printf ("Skalarni proizvod X*Y: %g\n",  skal_pro (x, y, k));
}
