/* Sortiranje niza brojeva metodom umetanja.                         */

#include <stdio.h>
#include <stdlib.h>
#define DIM 500

main () {
  for (;;) {
    int n, a[DIM], i, j;

    /* Citanje duzine niza */
    printf ("\nDuzina niza (max %d): ", DIM); scanf ("%d", &n);
  if (n <= 0 || n > DIM) break;

    /* Stvaranje i ispisivanje niza */
    printf ("\nPocetni niz:\n\n");
    for (i=0; i<n; i++) {
      printf ("%d ", a[i] = rand() / ((double)RAND_MAX + 1) * 10);
      if (i%30==29 || i==n-1) printf ("\n");
    }

    /* Sortiranje niza */
    for (i=1; i<n; i++) {
      register int b = a[i];
      for (j=i-1; j>=0; j--)
        if (a[j] > b) a[j+1] = a[j]; else break;
      a[j+1] = b;
    }

    /* Ispisivanje sortiranog niza */
    printf ("\nSortirani niz:\n\n");
    for (i=0; i<n; i++) {
      printf ("%d ", a[i]);
      if (i%30==29 || i==n-1) printf ("\n");
    }
  }
}
