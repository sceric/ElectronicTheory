/* Prolazni i trajni podaci.                                         */

#include <stdio.h>

main () {
  int i;                             /* Prolazni podatak u memoriji. */
  for (i=0; i<5; i++) {
    register int x=1;                /* Prolazni podatak u registru. */
    static   int y=1;                /* Trajni podatak.              */
    printf ("i=%d  x=%d  y=%d\n", i, x++, y++);
 
  }
}
