/* Nalazenje unije skupova.                                          */

#include <stdio.h>
#include <stdlib.h>

main () {
  while (1) {
    int n1, n2, n3, i, j;
    double *s1, *s2, *s3;

    /* Citanje velicine skupova */
    printf ("Broj elemenata prvog i drugog skupa ? ");
    scanf ("%d%d", &n1, &n2);
  if (n1 < 0 || n2 < 0) break;

    /* Citanje elemenata skupova */
    s1 = malloc (n1 * sizeof (double));
    printf ("Elementi prvog skupa?   ");
    for (i=0; i<n1; scanf ("%lf", &s1[i++]));
    if (n1 == 0) putchar ('\n');
    s2 = malloc (n2 * sizeof (double));
    printf ("Elementi drugog skupa?  ");
    for (i=0; i<n2; scanf ("%lf", &s2[i++]));
    if (n2 == 0) putchar ('\n');

    /* Nalazenje unije skupova */
    s3 = malloc ((n1 + n2) * sizeof (double));
    for (n3=0; n3<n1; n3++) s3[n3] = s1[n3];
    for (j=0; j<n2; j++) {
      for (i=0; i<n1; i++) if (s2[j] == s1[i]) break;
      if (i == n1) s3[n3++] = s2[j];
    }
    s3 = realloc (s3, n3 * sizeof (double));

    /* Ispisivanje rezultata */
    printf ("Unija pocetnih skupova:");
    for (i=0; i<n3; printf (" %.2f", s3[i++]));
    printf ("\n\n");

    /* Unistavanje skupova */
    free (s1); free (s2); free (s3);
  }
}
