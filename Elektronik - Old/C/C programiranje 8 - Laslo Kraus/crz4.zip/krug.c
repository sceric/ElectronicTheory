/* Izra�unavanje obima i povr�ine kruga.                             */

#include <stdio.h>
#define PI 3.14159265359

main () {
  double r;
  printf ("Polurecnik? ");
  scanf  ("%lf", &r);
  printf ("Obim      = %.3f\n", 2*r*PI);
  printf ("Povrsina  = %.3f\n", r*r*PI);
}
