/* Prikazivanje celih brojeva u raznim brojevnim sistemima.          */

#include <stdio.h>

main () {
  int k;
  printf ("Unesite ceo broj: ");
  scanf ("%i", &k);
  printf ("- decimalno:      %d (%u)\n", k, k);
  printf ("- oktalno:        %o\n", k);
  printf ("- heksadecimalno: %x (%X)\n", k, k);
}

