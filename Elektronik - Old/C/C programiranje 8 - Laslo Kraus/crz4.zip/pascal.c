/* Program za ispisivanje Pascalovog trougla.                        */

#include <stdio.h>
#include <stdlib.h>

int binko (int, int);                   /* Prototip funkcije.        */

void main (int bpar, const char *vpar[]) {
  int n, k, i, nmax = atoi (vpar[1]);

  putchar ('\n');
  for (n=0; n<=nmax; n++) {
    for (i=0; i<nmax-n; i++) printf ("  ");
    for (k=0; k<=n; k++) printf ("%4d", binko (n, k));
    putchar ('\n');
  }
}
