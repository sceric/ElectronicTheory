/* Globalni podaci u zasebnoj datoteci.                              */

double x, y, r, fi;              /* Defincija globalnih podataka.    */
