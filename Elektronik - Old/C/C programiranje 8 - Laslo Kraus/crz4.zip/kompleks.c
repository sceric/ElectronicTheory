/* Definicije funkcija za rad sa kompleksnim brojevima.                  */

#include "kompleks.h"
#include <math.h>

Kompl  cmplx (double x, double y) { Kompl c; c.re=x; c.im=y; return c; }

double creal (Kompl a) { return a.re; }

double cimag (Kompl a) { return a.im; }

double cmod  (Kompl a) { return sqrt (pow(a.re, 2) + pow(a.im, 2)); }

double carg  (Kompl a)
  { return (a.im == 0 && a.re == 0) ? 0 : atan2 (a.im, a.re); }

Kompl  conjg (Kompl a) { a.im = -a.im; return a; }

Kompl  cadd  (Kompl a, Kompl b) { a.re += b.re; a.im += b.im; return a; }

Kompl  csub  (Kompl a, Kompl b) { a.re -= b.re; a.im -= b.im; return a; }

Kompl  cmul  (Kompl a, Kompl b) {
  Kompl c;
  c.re = a.re * b.re - a.im * b.im; c.im = a.im * b.re + a.re * b.im;
  return c;
}

Kompl  cdiv  (Kompl a, Kompl b) {
  Kompl c; double d = pow(b.re, 2) + pow(b.im, 2);
  c.re = (a.re*b.re + a.im*b.im)/d; c.im = (a.im*b.re - a.re*b.im)/d;
  return c;
}

Kompl  cexp  (Kompl a) {
  double abs = exp (a.re), arg = a.im;
  return cmplx (abs * cos (arg), abs * sin (arg));
}

Kompl  clog  (Kompl a) { return cmplx (log (cmod (a)), carg (a)); }

Kompl  cpow  (Kompl a, Kompl b) { return cexp (cmul (b, clog (a))); }

const Kompl J  = {0, 1};
const Kompl C1 = {1, 0};
const Kompl C0 = {0, 0};
