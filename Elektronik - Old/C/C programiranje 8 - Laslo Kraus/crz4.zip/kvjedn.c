/* Resavanje kvadratne jednacine.                                        */

#include <stdio.h>
#include <math.h>

main () {
  double a, b, c, /* Koeficijenti jednacine.                             */
         d,       /* Diskriminanta jednacine.                            */
         x1, x2,  /* Realni delovi korena.                               */
         y1, y2;  /* Imaginarni delovi korena.                           */
  typedef enum { REALNI, DVOSTRUKI, KOMPLEKSNI, LINEARNA, POGRESNA } Vrsta;
  Vrsta  vrsta;   /* Vrsta resenja jednacine.                            */

  printf ("Koeficijenti kvadratne jednacine? ");
  scanf ("%lf%lf%lf", &a, &b, &c);

  if (a) {
    d = b * b - 4 * a * c;
    if (d > 0) {
      vrsta = REALNI;
      x1 = (- b + sqrt (d)) / (2 * a);
      x2 = (- b - sqrt (d)) / (2 * a);
    } else if (d == 0) {
      vrsta = DVOSTRUKI;
      x1 = - b / (2 * a);
    } else {
      vrsta = KOMPLEKSNI;
      x1 = - b / (2 * a);            x2 = x1;
      y1 = sqrt (- d) / (2 * a);     y2 = - y1;
    }
  } else
    if (b) {
      vrsta = LINEARNA;
      x1 = - c / b;
    } else
      vrsta = POGRESNA;

  switch (vrsta) {
    case REALNI:
      printf ("Realni koreni su %.2f i %.2f\n", x1, x2);
      break;
    case DVOSTRUKI:
      printf ("Dvostruki realni koren je %.2f\n", x1);
      break;
    case KOMPLEKSNI:
      printf ("Kompleksni koreni su (%.2f,%.2f) i (%.2f,%.2f)\n",
              x1, y1, x2, y2);
      break;
    case LINEARNA:
      printf ("Resenje linearne jednacine je %.2f\n", x1);
      break;
    case POGRESNA:
      printf ("Podaci nemaju smisla!\n");
      break;
  }
}
