/* Srednja vrednost i standardna devijacija niza realnih brojeva.   */

#include <stdio.h>
#include <math.h>

main () {
  while (1) {
    double a, s, d;
    int n, i;
    printf ("\nBroj elemenata niza? "); scanf ("%d", &n);
  if (n <= 0) break;
    printf ("Elementi niza? ");
    for (s=d=0, i=1; i<=n; i++)
      { scanf ("%lf", &a); s += a; d += a * a; }
    s /= n;
    d = sqrt (d / n - s * s);
    printf ("Srednja vrednost:      %.4f\n", s);
    printf ("Standardna devijacija: %.4f\n", d);
  }
}
