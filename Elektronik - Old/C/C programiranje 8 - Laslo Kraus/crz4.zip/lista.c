/* Rad sa jednostruko lancanim listama.                                  */

#include <stdio.h>
#include <stdlib.h>

typedef struct elem { int broj; struct elem *sled; } Elem;

Elem *citaj () {                  /* Citanje brojeva i stvaranje liste   */
  Elem *niz = NULL, *tekuci = NULL; int broj;
  while (scanf ("%d", &broj)) {
    Elem *novi = malloc (sizeof (Elem));
    novi->broj = broj; novi->sled = NULL;
    if (! niz) niz = novi; else tekuci->sled = novi;
    tekuci = novi;
  }
  getchar ();
  return niz;
}

void pisi (Elem *niz) {           /* Ispisivanje liste                   */
  while (niz) { printf ("%d ", niz->broj); niz = niz->sled; }
}

void brisi (Elem *niz) {          /* Brisanje cele liste                 */
  while (niz) { Elem *stari = niz; niz = niz->sled; free (stari); }
}

Elem *izost (Elem *niz, int k) {  /* Izostavljanje zadatog broja         */
  Elem *preth = NULL, *tekuci = niz;
  while (tekuci)
    if (tekuci->broj != k) {
      preth = tekuci; tekuci = tekuci->sled;
    } else {
      Elem *stari = tekuci; tekuci = tekuci->sled;
      if (! preth) niz = tekuci; else preth->sled = tekuci;
      free (stari);
    }
  return niz;
}

void main () {                    /* Test glavni program                 */
  Elem *lista;
  while ((lista = citaj ()) != NULL) {
    int k;
    printf ("Ucitani niz   = "); pisi (lista); putchar ('\n');
    scanf ("%d", &k); printf ("Izostavlja se = %d\n", k);
    printf ("Novi niz      = "); pisi (lista = izost (lista, k));
    printf ("\n\n"); brisi (lista);
  }
}
