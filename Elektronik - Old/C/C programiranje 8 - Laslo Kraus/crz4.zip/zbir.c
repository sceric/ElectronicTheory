/* Program pro�ita dva cela broja i napise njihov zbir               */

#include <stdio.h>

main ()
{
  int a, b, c;
  printf ("Unesite dva cela broja: ");
  scanf ("%d%d", &a, &b);
  c = a + b;
  printf ("Zbir unetih brojeva: %d\n", c);
}
