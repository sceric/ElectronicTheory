/* Sortiranje imena gradova smestenih u matricu.                     */

#include <stdio.h>
#include <string.h>
#define MAX_GRAD 100
#define MAX_DUZ  30

main () {

  char gradovi[MAX_GRAD][MAX_DUZ], grad[MAX_DUZ];
  int  br_grad=0, i;

  /* Citanje i obrada pojedinacnih imena */
  printf ("\nNeuredjeni niz imena gradova:\n\n");
  do {

    gets (grad);    /* Citanje sledeceg imena */

  /* Kraj ako je duzina imena nula */
  if (! strlen (grad)) break;

    puts (grad);    /* Ispisivanje procitanog imena */

    /* Uvrstavanje novog imena u sortirani niz starih imena */
    for (i=br_grad-1; i>=0; i--)
      if (strcmp (gradovi[i], grad) > 0)
        strcpy (gradovi[i+1], gradovi[i]);
      else break;
    strcpy (gradovi[i+1], grad);

    /* Nastavak rada ako ima jos slobodnih vrsta u matrici */
  } while (++br_grad < MAX_GRAD);

  /* Ispisivanje sortiranog niza imena */
  printf ("\nUredjeni niz imena gradova:\n\n");
  for (i=0; i<br_grad; puts (gradovi[i++]));
}
