/* Glavni program u zasebnoj datoteci.                               */

#include <stdio.h>

extern double x, y, r, fi;       /* Deklaracija globalnih podataka.  */
void polar (void);               /* Deklaracija (prototip) funkcije. */

main () {                        /* Definicija glavnog programa.     */
  while (printf ("x,y? "), scanf ("%lf%lf", &x, &y), x != 1E38) {
    polar (); printf ("r,fi= %g, %g\n", r, fi);
  }
}
