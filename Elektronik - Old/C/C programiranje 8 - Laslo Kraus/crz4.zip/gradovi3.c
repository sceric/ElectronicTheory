/* Sortiranje imena gradova smestenih u vektor.                      */

#include <stdio.h>
#include <string.h>
#define MAX_GRAD   100
#define MAX_DUZ    30
#define MAX_UK_DUZ 3000

main () {

  char gradovi[MAX_UK_DUZ];
  char *adrese[MAX_GRAD], *adresa, *sled_znak = gradovi;
  int  br_grad=0, duz, i;

  /* Citanje i obrada pojedinacnih imena */
  printf ("\nNeuredjeni niz imena gradova:\n\n");
  do {

    adresa = sled_znak;
    gets (adresa);    /* Citanje sledeceg imena */
    sled_znak += (duz = strlen (adresa)) + 1;

  /* Kraj ako je duzina imena nula */
  if (! duz) break;

    puts (adresa);    /* Ispisivanje procitanog imena */

    /* Uvrstavanje novog imena u sortirani niz starih imena */
    for (i=br_grad-1; i>=0; i--)
      if (strcmp (adrese[i], adresa) > 0)
        adrese[i+1] = adrese[i];
      else break;
    adrese[i+1] = adresa;

    /* Nastavak rada ako ima jos slobodnih mesta u vektoru */
  } while (++br_grad < MAX_GRAD && sled_znak+MAX_DUZ < gradovi+MAX_UK_DUZ);

  /* Ispisivanje sortiranog niza imena */
  printf ("\nUredjeni niz imena gradova:\n\n");
  for (i=0; i<br_grad; puts (adrese[i++]));
}
