/* Funkcija u zasebnoj datoteci.                                     */

#include <math.h>

extern double x, y, r, fi;       /* Deklaracija globalnih podataka.  */

void polar () {                  /* Definicija funkcije.             */
  r  = sqrt (x * x + y * y);
  fi = (x == 0 && y == 0) ? 0 : atan2 (y, x); 
}
