/* Sortiranje imena gradova smestenih u vektor.                      */

#include <stdio.h>
#include <string.h>
#define MAX_GRAD   100
#define MAX_DUZ    30
#define MAX_UK_DUZ 3000

main () {

  char gradovi[MAX_UK_DUZ];
  int indeksi[MAX_GRAD];
  int  br_grad=0, uk_duz=0, duz, indeks, i;

  /* Citanje i obrada pojedinacnih imena */
  printf ("\nNeuredjeni niz imena gradova:\n\n");
  do {

    indeks = uk_duz;
    gets (&gradovi[indeks]);    /* Citanje sledeceg imena */
    uk_duz += (duz = strlen (&gradovi[indeks])) + 1;

  /* Kraj ako je duzina imena nula */
  if (! duz) break;

    puts (&gradovi[indeks]);    /* Ispisivanje procitanog imena */

    /* Uvrstavanje novog imena u sortirani niz starih imena */
    for (i=br_grad-1; i>=0; i--)
      if (strcmp (&gradovi[indeksi[i]], &gradovi[indeks]) > 0)
        indeksi[i+1] = indeksi[i];
      else break;
    indeksi[i+1] = indeks;

    /* Nastavak rada ako ima jos slobodnih mesta u vektoru */
  } while (++br_grad < MAX_GRAD && uk_duz + MAX_DUZ < MAX_UK_DUZ);

  /* Ispisivanje sortiranog niza imena */
  printf ("\nUredjeni niz imena gradova:\n\n");
  for (i=0; i<br_grad; puts (&gradovi[indeksi[i++]]));
}
