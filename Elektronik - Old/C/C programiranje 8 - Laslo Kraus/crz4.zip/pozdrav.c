#include <stdio.h>

main () {
  printf ( "Pozdrav svima!\n" ) ;
}

