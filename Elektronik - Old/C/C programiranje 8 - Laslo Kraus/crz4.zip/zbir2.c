/* Zbir promenljivog broja argumenata.                               */

#include <stdarg.h>

int zbir (int n, ...) {
  int s, i;
  va_list pa;                      /* Pokazivac na argumente.        */
  va_start(pa, n);                 /* Inicijalizacija pokazivaca     */
                                   /*   na argumente.                */
  for (s=i=0; i<n; i++)
    s += va_arg(pa, int);          /* Dohvatanje sledeceg argumenta. */
  va_end(pa);                      /* Kraj dohvatanja argumenata.    */
  return s;
}

#include <stdio.h>

void main () {
  printf ("1+2=   %d\n", zbir(2,1,2));
  printf ("1+2+3= %d\n", zbir(3,1,2,3));
}
