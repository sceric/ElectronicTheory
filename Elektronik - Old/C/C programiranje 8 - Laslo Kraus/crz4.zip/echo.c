/* Ispisivanje poruke na ekranu.                                     */

#include <stdio.h>

void main (int bpar, const char *vpar[]) {
  int i;
  for (i=1; i<bpar; i++)
    printf ("%s%c", vpar[i], (i<bpar-1)?(' '):('\n'));
}
