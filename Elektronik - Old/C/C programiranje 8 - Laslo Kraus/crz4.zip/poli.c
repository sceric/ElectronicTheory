/* Potprogrami paketa za rad sa polinomima.                              */

#include "poli.h"
#include <stdio.h>
#include <stdlib.h>

double poli     (const double  *p , int  n ,   /* Vrednost polinoma.     */
                       double   x          ) {
  int i; double s = p[n];
  for (i=n-1; i>=0; s = s * x + p[i--]);
  return s;
}

void   zbir     (const double  *p1, int  n1,   /* Zbir dva polinoma.     */
                 const double  *p2, int  n2,
                       double **p3, int *n3) {
  int i, n;
  if (n1 != n2) n = (n1 > n2) ? n1 : n2;
    else        for (n=n1; n>=0 && p1[n]+p2[n]==0; n--) ;
  *p3 = malloc (((*n3=n)+1) * sizeof(double));
  for (i=0; i<=n; i++)
    (*p3)[i] = (i > n2) ?  p1[i] :
               (i > n1) ?  p2[i] :
                           p1[i] + p2[i];
}

void   razlika  (const double  *p1, int  n1,   /* Razlika dva polinoma.  */
                 const double  *p2, int  n2,
                       double **p3, int *n3) {
  int i, n;
  if (n1 != n2) n = (n1 > n2) ? n1 : n2;
    else        for (n=n1; n>=0 && p1[n]-p2[n]==0; n--) ;
  *p3 = malloc (((*n3=n)+1) * sizeof(double));
  for (i=0; i<=n; i++)
    (*p3)[i] = (i > n2) ?  p1[i] :
               (i > n1) ? -p2[i] :
                           p1[i] - p2[i];
}

void   proizvod (const double  *p1, int  n1,   /* Proizvod dva polinoma. */
                 const double  *p2, int  n2,
                       double **p3, int *n3) {
  int i, j, n;
  n = (n1<0 || n2<0) ? -1 : n1+n2;
  *p3 = calloc (((*n3=n)+1), sizeof(double));
  for (i=0; i<=n1; i++)
    for (j=0; j<=n2; j++)
      (*p3)[i+j] += p1[i] * p2[j];
}

void   kolicnik (const double  *p1, int  n1,   /* Kolicnik dva polinoma. */
                 const double  *p2, int  n2,
                       double **p3, int *n3,
                       double **p4, int *n4) {
  int n, m, i, j;
  if (n2 < 0) {
    printf ("\n*** Deljenje polinoma nulom! ***\n\a");
    exit (1);
  }
  *p3 = malloc (((*n3=n)+1) * sizeof(double));
  *p4 = malloc ((n1+1) * sizeof(double));
  for (i=0; i<=n1; i++) (*p4)[i] = p1[i];
  for (i=n; i>=0; i--) {
    (*p3)[i] = (*p4)[n2+i] / p2[n2];
    for (j=0; j<=n2; j++) (*p4)[j+i] -= p2[j] * (*p3)[i];
  }
  if (n1 >= n2) for (m=n2; m>=0 && (*p4)[m]==0; m--) ;
    else        m = n1;
  *p4 = realloc (*p4, ((*n4=m)+1)*sizeof(double));
}

void   citaj    (      double **p , int *n ) { /* Citanje polinoma.      */
  int i;
  scanf ("%d", n);
  *p = malloc ((*n+1)*sizeof(double));
  for (i=*n; i>=0; scanf ("%lf", &(*p)[i--]));
}

void   pisi     (const double  *p , int  n ,   /* Pisanje polinoma.      */
                 const char    *f          ) {
  int i;
  printf ("p[");
  for (i=n; i>=0; i--) { printf (f, p[i]); if (i>0) putchar (','); }
  putchar (']');
}
