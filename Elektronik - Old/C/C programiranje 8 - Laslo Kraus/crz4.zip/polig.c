/* Ispitivanje paketa potprograma za rad sa polinomima.                  */

#include "poli.h"
#include <stdio.h>
#include <stdlib.h>

int main () {
  while (1) {
    double *p1, *p2, *p3, *p4;
    int     n1,  n2,  n3,  n4;
    citaj (&p1, &n1);
    citaj (&p2, &n2);
  if (n2 < 0) break;
    printf ("P1    = "); pisi     (p1, n1, "%.2f"); putchar ('\n');
    printf ("P2    = "); pisi     (p2, n2, "%.2f"); putchar ('\n');
    printf ("P1+P2 = "); zbir     (p1, n1, p2, n2, &p3, &n3);
                         pisi     (p3, n3, "%.2f"); putchar ('\n');
                         free (p3);
    printf ("P1-P2 = "); razlika  (p1, n1, p2, n2, &p3, &n3);
                         pisi     (p3, n3, "%.2f"); putchar ('\n');
                         free (p3);
    printf ("P1*P2 = "); proizvod (p1, n1, p2, n2, &p3, &n3);
                         pisi     (p3, n3, "%.2f"); putchar ('\n');
                         free (p3);
    printf ("P1/P2 = "); kolicnik (p1, n1, p2, n2, &p3, &n3, &p4, &n4);
                         pisi     (p3, n3, "%.2f"); putchar ('\n');
    printf ("P1%%P2 = ");pisi     (p4, n4, "%.2f"); putchar ('\n');
                         free (p3); free (p4);
    putchar ('\n');
    free (p1); free (p2);
  }
  return 0;
}
