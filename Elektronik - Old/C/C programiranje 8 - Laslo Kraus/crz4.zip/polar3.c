/* Izmena podataka pomo�u deklarisannih globalnih promenljivih.      */

#include <stdio.h>
#include <math.h>

main () {                        /* Definicija glavnog programa.     */
  extern double x, y, r, fi;     /* Deklaracija globalnih podataka.  */
  void polar (void);             /* Deklaracija (prototip) funkcije. */
  while (printf ("x,y? "), scanf ("%lf%lf", &x, &y), x != 1E38) {
    polar (); printf ("r,fi= %g, %g\n", r, fi);
  }
}

void polar () {                  /* Definicija funkcije.             */
  extern double x, y, r, fi;     /* Deklaracija globalnih podataka.  */
  r  = sqrt (x * x + y * y);
  fi = (x == 0 && y == 0) ? 0 : atan2 (y, x); 
}

double x, y, r, fi;              /* Defincija globalnih podataka.    */
