/* Azuriranje zapisa u datoteci o stedisama.                         */

#include <stdio.h>
#include "stedisa.h"

void main () {

  FILE *stednja;             /* Datoteka o stedisama                 */
  Stedisa stedisa;           /* Podaci o jednom stedisi              */
  unsigned int sifra;        /* Sifra stedise                        */
  unsigned int veldat;       /* Broj zapisa u datoteci               */
  double promena;            /* Promena stanja uloga                 */

  /* Otvaranje datoteke o stedisama */
  if ((stednja = fopen ("stedise.dat", "r+b")) == NULL) exit (1);
  fread  (&veldat, sizeof veldat, 1, stednja);

  /* Azuriranje stanja uloga pojedinih stedisa */
  while (1) {

    /* Citanje sifre sledeceg stedise za obradu */
    printf ("\nSifra stedise?     "); scanf ("%d", &sifra);
  if (sifra == 0) break;   /* ... kraj programa */
    if (sifra <= veldat) {

      /* Citanje zatecenih podataka o stedisi iz datoteke */
      fseek (stednja,
             (sizeof veldat) + (long) (sifra - 1) * (sizeof stedisa),
             SEEK_SET);
      fread (&stedisa, sizeof stedisa, 1, stednja);
      if (stedisa.ime.prezime[0]) {

        /* Prikazivanje zatecenih podataka o stedisi */
        printf ("Stedisa = %s %s\n", stedisa.ime.prezime,
                                     stedisa.ime.licno_ime);
        printf ("Staro stanje= %8.2f\n", stedisa.stanje);

        /* Citanje promene stanja uloga */
        printf ("Promena stanja?    "); scanf ("%lf", &promena);
        stedisa.stanje += promena;

        /* Upisivanje novog sadrzaja zapisa o stedisi u datoteku */
        fseek (stednja, - (long) (sizeof stedisa), SEEK_CUR);
        fwrite (&stedisa, sizeof stedisa, 1, stednja);
      } else
        printf ("*** Ne postoji stedisa sa tom sifrom ***\a\n");
    } else
      printf ("*** Ne postoji stedisa sa tom sifrom ***\a\n");
  }
}
