/* Program za prenos tekstualnih datoteka.                           */

#include <stdio.h>

void prepis (FILE *ulaz, FILE *izlaz) {
  /* Prepisuje datoteku ulaz u izlaz */
  int zn;
  while ((zn = getc (ulaz)) != EOF) putc (zn, izlaz);
}

void main (int bpar, const char *vpar[]) {

  FILE *datot;
  const char *progr = vpar[0];  /* adresa imena programa */

  if (bpar == 1)  prepis (stdin, stdout);
  else
    while (--bpar > 0)
      if ((datot = fopen (*++vpar, "r")) != NULL)
        prepis (datot, stdout), fclose (datot);
      else {
        fprintf (stderr, "%s: ne postoji datoteka %s\n", progr, *vpar);
        exit (1);
      }
  if (ferror (stdout)) {
    fprintf (stderr, "%s: greska pisanja u stdout\n", progr);
    exit (2);
  }
  exit (0);
}
