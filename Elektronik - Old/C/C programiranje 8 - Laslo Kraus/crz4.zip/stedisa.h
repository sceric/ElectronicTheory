/* Struktura zapisa o stedisi.                                       */

#ifndef _stedisa_h_
#define _stedisa_h_

typedef struct { char prezime[16], licno_ime[16]; } Ime_i_prezime;
typedef struct { Ime_i_prezime ime; double stanje; } Stedisa;

#endif
