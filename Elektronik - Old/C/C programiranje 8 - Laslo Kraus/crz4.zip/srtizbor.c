/* Sortiranje niza brojeva metodom izbora.                           */

#include <stdio.h>
#include <stdlib.h>
#define DIM 500

main () {
  for (;;) {
    int n, a[DIM], i, j;

    /* Citanje duzine niza */
    printf ("\nDuzina niza (max %d): ", DIM); scanf ("%d", &n);
  if (n <= 0 || n > DIM) break;

    /* Stvaranje i ispisivanje niza */
    printf ("\nPocetni niz:\n\n");
    for (i=0; i<n; i++) {
      printf ("%d ", a[i] = rand() / ((double)RAND_MAX + 1) * 10);
      if (i%30==29 || i==n-1) printf ("\n");
    }

    /* Sortiranje niza */
    for (i=0; i<n-1; i++)
      for (j=i+1; j<n; j++)
        if (a[i] > a[j])
          { register int b = a[i]; a[i] = a[j]; a[j] = b; }

    /* Ispisivanje sortiranog niza */
    printf ("\nSortirani niz:\n\n");
    for (i=0; i<n; i++) {
      printf ("%d ", a[i]);
      if (i%30==29 || i==n-1) printf ("\n");
    }
  }
}
