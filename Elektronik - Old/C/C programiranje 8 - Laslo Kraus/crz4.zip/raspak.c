/* Funkcija za raspakivanje bit po bit na masinski nezavisan nacin.  */

void raspak (unsigned int k, char bit[], int *n) {
  unsigned int i;
  for (*n=0, i=~0; i!=0; i>>=1) { bit[(*n)++] = k & 1; k >>= 1; }
}
