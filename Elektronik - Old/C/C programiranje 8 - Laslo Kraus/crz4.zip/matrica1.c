/* Dinamicka matrica pomocu niza pokazivaca.                         */

#include <stdio.h>
#include <stdlib.h>

main () {
  int *a[20];             /* Niz pokazivaca na int.                  */
  int m, n, i, j;

  /* Broj vrsta i kolona: */
  printf ("m,n? "); scanf ("%d%d", &m, &n);

  /* Stvaranje matrice: */
  for (i=0; i<m; i++) {
    a[i] = malloc (n*sizeof(int));
    for (j=0; j<n; j++) printf ("%4.4d ", *(a[i]+j)=100*i+j);
    putchar ('\n');
  }

  /* Unistavanje matrice: */
  for (i=0; i<m; i++) free(a[i]); 
}
