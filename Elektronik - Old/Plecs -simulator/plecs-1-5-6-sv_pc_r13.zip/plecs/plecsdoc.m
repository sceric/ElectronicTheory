function p = plecsdoc

p = fullfile(fileparts(which('plecsedit')), 'onlinehelp');
