function [RL, K] = plrrdiode(If0, dIrdt, trr, Irrm, Qrr, Lrr)

dIrdt = abs(dIrdt);
if ~trr & Irrm & Qrr,
  trr = log(10)/Irrm * (Qrr-(.5-1/log(10))/dIrdt*Irrm^2);
elseif trr & ~Irrm & Qrr,
  Irrm = -trr*dIrdt/(log(10)-2) + sqrt((trr*dIrdt/(log(10)-2))^2 + Qrr*dIrdt/(.5-1/log(10)));
elseif trr & Irrm,
  Qrr = (.5-1/log(10))/dIrdt*Irrm^2 + trr/log(10)*Irrm;
end
if ~(Qrr<trr^2/2*dIrdt & Irrm<trr*dIrdt & Qrr>Irrm^2/2/dIrdt) ,
  error('Parameters for reverse recovery do not match.');
end
RL = Lrr * log(10) / (trr - Irrm/dIrdt);
errorfun = inline('abs(x - Irrm/Lrr/dIrdt / (1 - exp( -(If0+Irrm)/(Lrr*dIrdt*(x+1/RL)) )))', 'x', 'If0', 'dIrdt', 'trr', 'Irrm', 'Lrr', 'RL');
K = fminsearch(errorfun, 100, optimset('Display', 'off'), If0, dIrdt, trr, Irrm, Lrr, RL);
