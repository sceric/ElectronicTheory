%PLECSCONFIG Edit 'plecsconfig.m' to configure PLECS.
%
% - Change the values below to your needs. You may also copy this file to your
%   Matlab home directory, to your working directory, or anywhere else on your
%   Matlab path.
% - Don't change the format of this file.

function config=plecsconfig

% Wether resistors and capacitors are drawn in ANSI (1) or DIN style (0)
config.drawANSI = 0;
