PLECS - Piece-wise Linear Electrical Circuit Simulation.

http://www.plexim.com


-----------------------------------------------------------------------
License
-----------------------------------------------------------------------

This software is distributed under the terms found in 'license.txt'.


-----------------------------------------------------------------------
Installation
-----------------------------------------------------------------------

You do not need to have system administrator permissions. Since PLECS
requires MATLAB and Simulink make sure these programs are installed on
your system.


Windows:
----------------------------

Unzip the appropriate package file in a directory of your choice either
with 'pkzip -d filename.zip' or with WinZIP. This will create a new
sub-directory 'plecs' with the files required. If you use WinZIP make
sure that "Use Folder Names" is checked in the "Extract" menu.

In MATLAB, add the new directory and the subdirectory 'demos' to your
search path using the Path Browser. The Path Browser is found under the
menu item "File -> Set Path -> Add Folder".

If you previously had installed an older version of PLECS and you are
running MATLAB 6.0 or higher execute 'rehash toolboxcache' in the MATLAB
command line.



Mac OS X / Linux / Solaris:
----------------------------

If applicable, unzip with gunzip filename.tar.gz

Untar with tar -xf filename.tar in a directory of your choice. This will
create a new sub-directory named 'plecs' with the files required. (On
Mac OS X you may also double click the file 'filename.tar.gz' to have it
de-compressed by your compression utility.)

In MATLAB, add the new directory and the 'demos' subdirectory to your
search path. Use the Path Browser under the menu item "File -> Set Path
-> Add Folder". Alternatively, edit directly the file 'pathdef.m' in the
directory 'MATLABROOT/toolbox/local/'. If you do not have file system
permission to modify the file 'pathdef.m' add the commands
'addpath('plecs_directory');' and 'addpath('plecs_directory/demos');' to
the file '~/matlab/startup.m'. (In case the file does not exist create
an empty file 'startup.m' in the subdirectory 'matlab' of your home
directory.)

If you previously had installed an older version of PLECS execute 
'rehash toolboxcache' in the MATLAB command line.



License File:
----------------------------

When you install the full version of PLECS you must have a valid license
file 'license.dat'. This file will be sent to you by email when you
purchase a license for PLECS. Copy the file 'license.dat' into the
directory where you have installed PLECS.

If the license file is not present or contains invalid data you will
still be able to open or save models containing PLECS circuits. However,
you cannot modify a circuit or run a simulation.

Note: PLECS scans the license file only once when the module is loaded
by MATLAB. Therefore, if you reinstall the license file you need to
clear the PLECS module before the changes can become effective. You can
do this by entering 'plecsclear' at the MATLAB command prompt.

See the PLECS manual for more details about the different types of
licensing.



Installing Different PLECS Versions in Parallel:
----------------------------

If you want to keep different versions of PLECS installed in parallel on
one computer, you must ensure that only one version is on your MATLAB path
at any time during a MATLAB session. Otherwise, loss of data may occur.
Before changing the MATLAB path, be sure to clear the currently loaded
PLECS module by entering 'plecsclear' at the MATLAB command prompt.
As an additional precaution you should restart MATLAB after the change.



Documentation:
----------------------------

The PLECS user manual is included in the distribution as a PDF file 
('plecsmanual.pdf'). It can also be downloaded from the Plexim web
page at:
http://www.plexim.com/downloads/plecs_documentation.html
