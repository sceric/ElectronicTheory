% Thermal capacitances are multiplied with the factor Cth_fac.
% Set Cth_fac to 0 to obtain an accelerated thermal steady state.
Cth_fac = 1;

% Initial temperature of thermal capacitances.
if Cth_fac,
  T_init = 25;
else
  T_init = 0;
end;

% MOSFET:
Ron_mosfet = 0.38; % T = 125

% V_GS = 10 V
Von_mosfet.i = [0 20 30];
Von_mosfet.T = [25 150];
Von_mosfet.v = [0 3.3 5.4 ;
              0 8.3 14.2]';

% R_G = 3.6 Ohm; T = 125
Eon_mosfet.v = [190 380];
Eon_mosfet.i = [3 6 9 18];
Eon380 = [3.5 6.5 10 22]*1e-6; % V_CE= 380 V
Eon_mosfet.E = [Eon380/2; Eon380];

Eoff_mosfet.v = [190 380];
Eoff_mosfet.i = [3 6 9 18];
Eoff380 = [10.5 15 23 62.5]*1e-6;
Eoff_mosfet.E = [Eoff380/2; Eon380];

% Internal reverse diode
Vdf_mosfet = 0.5;
Rdon_mosfet = .015;


% Silicon carbide free-wheeling diode:

Vf_d = 0.96;
Ron_d = 0.246;

Von_d.i = [0 0 8];
Von_d.T = [25 125];
Von_d.v = [0 0.85 2.37;
           0 0.96 2.93]';
% No turn-on loss and negligible reverse-recovery loss
Eon_d = [];
Eoff_d = [];

