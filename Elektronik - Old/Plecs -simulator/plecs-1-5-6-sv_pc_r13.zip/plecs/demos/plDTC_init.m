% Control matrix

Z0 = [0 0 0];
Z1 = [1 0 0];
Z2 = [1 1 0];
Z3 = [0 1 0];
Z4 = [0 1 1];
Z5 = [0 0 1];
Z6 = [1 0 1];
Z7 = [1 1 1];

Tab = [ Z0; Z3; Z7; Z2;
        Z7; Z4; Z0; Z3;
        Z0; Z5; Z7; Z4;
        Z7; Z6; Z0; Z5;
        Z0; Z1; Z7; Z6;
        Z7; Z2; Z0; Z1;
        Z0; Z0; Z0; Z0;
        Z0; Z0; Z0; Z0; ];

% Induction machine
% 20 hp, 220 V, 60 Hz, n_n = 1748.3 1/min, I_n = 49.68 A, P_n = 14.72 kW

V_n = sqrt(2/3)*220;
Rs = 0.1062;
Rr = 0.0764;
Lls = 0.2145/(2*pi*60);
Llr = Lls;
Lm = 5.834/(2*pi*60);
zp = 2;
J = 2.8;
F = 0;
T_n = 80.4;
Psi_ref = 0.46;

delta_T = 0.05*T_n;
delta_Psi = 0.02*Psi_ref;

