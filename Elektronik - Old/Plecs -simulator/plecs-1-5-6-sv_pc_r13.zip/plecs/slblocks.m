function blkStruct = slblocks
%SLBLOCKS Defines the Simulink library block representation
%   for the PLECS Library.

blkStruct.Name    = 'PLECS';
blkStruct.OpenFcn = 'plecslib';

blkStruct.MaskDisplay = ['plot(-25,-25,25,25,[20,12],[0,0],[-20,-12],[0,0],[-12,12,12,-12],[0,-15,15,0],[-12,-12],[15,-15]);'];

Browser(1).Library = 'plecslib';
Browser(1).Name    = 'PLECS';
Browser(1).IsFlat  = 1;% Is this library "flat" (i.e. no subsystems)?

if (str2num(strtok(version,'.')) >= 7)
  Browser(2).Library = 'plecslib_extras2';
else
  Browser(2).Library = 'plecslib_extras';
end
Browser(2).Name    = 'PLECS Extras';
Browser(2).IsFlat  = 0;% Is this library "flat" (i.e. no subsystems)?

blkStruct.Browser = Browser;

% End of slblocks.m
