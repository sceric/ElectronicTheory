function plecsclear
%PLECSCLEAR   Close all models containing PLECS blocks and clear the module
%   PLECSCLEAR closes all Simulink models that contain blocks from the PLECS
%   library. If a model has been modified, PLECSCLEAR will ask for confirmation
%   before closing the model.
%   Upon successful clearing PLECS will issue the message "Cleared PLECS module"

%   Copyright 2004 - 2005 Plexim GmbH

%
% find all blocks from the PLECS library
%
blocks = [find_system('FollowLinks', 'on', ...
                      'LookUnderMasks', 'all', ...
                      'MaskType', 'PlecsCircuit'); ...
          find_system('FollowLinks', 'on', ...
                      'LookUnderMasks', 'all', ...
                      'MaskType', 'PlecsLibrary')];

%
% find the models containing these blocks
%
models = unique(bdroot(blocks));

%
% for each model ...
%
for m = models',
  %
  % check whether the model has been modified
  %
  if (~strcmp(get_param(m, 'Dirty'), 'off')),
    open_system(char(m));
    choice = questdlg(['Do you want to save changes to ''' char(m) ...
                       ''' before closing the model?' char(10) ...
                       'If you don''t save, your changes will be lost.'], ...
                      'Unsaved changes', ...
                      'Don''t save', 'Cancel', 'Save', 'Save');
    switch(choice),
      case 'Don''t save',
        close_system(char(m), 0);
      case 'Cancel',
        error(['Cancelled due to unsaved changes to model ''' char(m) '''.']);
      case 'Save'
        close_system(char(m), 1);
    end
  else
    close_system(char(m));
  end
end

%
% when all models are closed, the plecsedit MEX file is unlocked and can be
% cleared
%
clear plecsedit

%
% check whether plecsedit was actually cleared
%
[m, mex] = inmem;
if (~isempty(strmatch('plecsedit', mex, 'exact')))
  warndlg(['The PLECS module cannot be cleared because there are PLECS ' ...
           'blocks in the Simulink clipboard. To clear the PLECS module ' ...
           'please select any non-PLECS block and press Ctrl-C or select ' ...
           'Copy from the Edit menu. Afterwards, rerun ''plecsclear''.'], ...
           'Unable to clear PLECS', ...
           'modal');
end