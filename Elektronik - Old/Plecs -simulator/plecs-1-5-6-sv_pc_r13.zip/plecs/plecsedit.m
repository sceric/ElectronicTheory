%PLECSEDIT Command Line Interface for PLECS.
%
% PLECSEDIT('CMD','PARAMETER1','PARAMETER2',...) allows you to access PLECS 
% component and circuit parameters directly from the MATLAB command line.
% 'CMD' is one of the following commands:  get, set, hostid.
%
% PLECSEDIT('get','COMPONENT_PATH',['PARAMETER']) returns the value of 
% PARAMETER of the PLECS component indicated by the COMPONENT_PATH as a string.
% If PARAMETER is omitted a cell aray with all available parameters is returned.
%
% PLECSEDIT('set','COMPONENT_PATH', 'PARAMETER', 'VALUE') set the value of 
% PARAMETER of the PLECS component indicated by the COMPONENT_PATH to 'VALUE'.
%
% PLECSEDIT('hostid') prints the hostid information.
%
% Examples:
%
% plecsedit('get', 'mdl/Circuit1')          % returns the parameters of Circuit1
%                                           % in the simulink model mdl
%
% plecsedit('get', 'mdl/Circuit1', 'Name')  % returns the name of Circuit1
%
% plecsedit('get', 'mdl/Circuit1', 'CircuitModel') 
%                                           % returns the circuit simulation
%                                           % method of Circuit1
%
% plecsedit('get', 'mdl/Circuit1/R1')       % returns the parameters of component
%                                           % R1 in circuit Circuit1
%
% plecsedit('set', 'mdl/Circuit1/R1', 'R', '2')
%                                           % sets the resistance of component
%                                           % R1 in circuit Circuit1 to 2
