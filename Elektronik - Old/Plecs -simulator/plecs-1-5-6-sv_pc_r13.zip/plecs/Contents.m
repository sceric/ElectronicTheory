% PLECS Piece-wise Linear Electrical Circuit Simulation
%  Version 1.5.6 15-May-2007
%
% PLECS Commands:
%   plecslib    - Open the PLECS library.
%   plecsconfig - Edit 'plecsconfig.m' to configure PLECS.
%
%  For demos type 'demo simulink plecs'
%
%  For more information read the manual by opening the file
%  'plecsmanual.pdf'
