/* Java source code for DTMF Tone Generator applet (C) 1998 Dr Iain A Robin
   This code may be used for any non-commercial educational or scientific purposes,
   although acknowledgment of its origin would be appreciated.

   Note that this is Java 1.1 code and must be compiled using a JDK 1.1 compliant compiler.

   If you have any queries about the applet code please e-mail i.robin@bell.ac.uk */

/*------------------------------------------------------------------------*/

package dtmf;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class ToneGenerator extends Applet implements Runnable{
  Thread runner;
  boolean isStandalone = false;
  boolean isTextFieldEntry = false;
  Panel pnlKeyPad = new Panel();
  GridLayout gridLayout1 = new GridLayout();
  Button btnZero = new Button();
  Button btnOne = new Button();
  Button btnTwo = new Button();
  Button btnThree = new Button();
  Button btnFour = new Button();
  Button btnFive = new Button();
  Button btnSix = new Button();
  Button btnSeven = new Button();
  Button btnEight = new Button();
  Button btnNine = new Button();
  Button btnStar = new Button();
  Button btnHash = new Button();
  Button btnA = new Button();
  Button btnB = new Button();
  Button btnC = new Button();
  Button btnD = new Button();
  AudioClip toneZero, toneOne, toneTwo, toneThree, toneFour,
            toneFive, toneSix, toneSeven, toneEight,
            toneNine, toneStar, toneHash, toneA, toneB, toneC, toneD;
  TextField tfNumber = new TextField();
  Button btnDial = new Button();
  BorderLayout borderLayout1 = new BorderLayout();
  Panel pnlNumberEntry = new Panel();
  FlowLayout flowLayout1 = new FlowLayout();

  //Construct the applet
  public ToneGenerator() {
  }

  public void start() {
    if (runner == null) {
      runner = new Thread(this);
      runner.start();
    }
  }

  public void stop() {
    if (runner != null) {
      runner.stop();
      runner = null;
    }
  }

  public void run() {
  }

  //Initialize the applet
  public void init() {
    try { jbInit(); } catch (Exception e) { e.printStackTrace(); }
  }

  //Component initialization
  public void jbInit() throws Exception{
    this.setSize(new Dimension(175, 231));
    this.addKeyListener(new ToneGenerator_this_keyAdapter(this));
    gridLayout1.setRows(4);
    gridLayout1.setHgap(5);
    gridLayout1.setColumns(4);
    gridLayout1.setVgap(5);
    btnOne.setLabel("1");
    btnOne.addActionListener(new ToneGenerator_btnOne_actionAdapter(this));
    btnTwo.setLabel("2");
    btnTwo.addActionListener(new ToneGenerator_btnTwo_actionAdapter(this));
    btnThree.setLabel("3");
    btnThree.addActionListener(new ToneGenerator_btnThree_actionAdapter(this));
    btnA.setLabel("A");
    btnA.addActionListener(new ToneGenerator_btnA_actionAdapter(this));
    btnFour.setLabel("4");
    btnFour.addActionListener(new ToneGenerator_btnFour_actionAdapter(this));
    btnFive.setLabel("5");
    btnFive.addActionListener(new ToneGenerator_btnFive_actionAdapter(this));
    btnSix.setLabel("6");
    btnSix.addActionListener(new ToneGenerator_btnSix_actionAdapter(this));
    btnB.setLabel("B");
    btnB.addActionListener(new ToneGenerator_btnB_actionAdapter(this));
    btnSeven.setLabel("7");
    btnSeven.addActionListener(new ToneGenerator_btnSeven_actionAdapter(this));
    btnEight.setLabel("8");
    btnEight.addActionListener(new ToneGenerator_btnEight_actionAdapter(this));
    btnNine.setLabel("9");
    btnNine.addActionListener(new ToneGenerator_btnNine_actionAdapter(this));
    btnC.setLabel("C");
    btnC.addActionListener(new ToneGenerator_btnC_actionAdapter(this));
    btnStar.setLabel("*");
    btnStar.addActionListener(new ToneGenerator_btnStar_actionAdapter(this));
    btnZero.setLabel("0");
    btnZero.addActionListener(new ToneGenerator_btnZero_actionAdapter(this));
    btnHash.setLabel("#");
    btnHash.addActionListener(new ToneGenerator_btnHash_actionAdapter(this));
    btnD.setLabel("D");
    btnD.addActionListener(new ToneGenerator_btnD_actionAdapter(this));
    tfNumber.setColumns(12);
    tfNumber.addFocusListener(new ToneGenerator_tfNumber_focusAdapter(this));
    btnDial.setLabel("Dial");
    btnDial.addActionListener(new ToneGenerator_btnDial_actionAdapter(this));
    borderLayout1.setVgap(20);
    pnlNumberEntry.setLayout(flowLayout1);
    pnlKeyPad.setLayout(gridLayout1);
    this.setLayout(borderLayout1);
    this.add(pnlNumberEntry, BorderLayout.NORTH);
    pnlNumberEntry.add(tfNumber, null);
    pnlNumberEntry.add(btnDial, null);
    this.add(pnlKeyPad, BorderLayout.CENTER);
    pnlKeyPad.add(btnOne, null);
    pnlKeyPad.add(btnTwo, null);
    pnlKeyPad.add(btnThree, null);
    pnlKeyPad.add(btnA, null);
    pnlKeyPad.add(btnFour, null);
    pnlKeyPad.add(btnFive, null);
    pnlKeyPad.add(btnSix, null);
    pnlKeyPad.add(btnB, null);
    pnlKeyPad.add(btnSeven, null);
    pnlKeyPad.add(btnEight, null);
    pnlKeyPad.add(btnNine, null);
    pnlKeyPad.add(btnC, null);
    pnlKeyPad.add(btnStar, null);
    pnlKeyPad.add(btnZero, null);
    pnlKeyPad.add(btnHash, null);
    pnlKeyPad.add(btnD, null);
    toneZero  = getAudioClip(getCodeBase(), "zero.au");
    toneOne   = getAudioClip(getCodeBase(), "one.au");
    toneTwo   = getAudioClip(getCodeBase(), "two.au");
    toneThree = getAudioClip(getCodeBase(), "three.au");
    toneFour  = getAudioClip(getCodeBase(), "four.au");
    toneFive  = getAudioClip(getCodeBase(), "five.au");
    toneSix   = getAudioClip(getCodeBase(), "six.au");
    toneSeven = getAudioClip(getCodeBase(), "seven.au");
    toneEight = getAudioClip(getCodeBase(), "eight.au");
    toneNine  = getAudioClip(getCodeBase(), "nine.au");
    toneStar  = getAudioClip(getCodeBase(), "star.au");
    toneHash  = getAudioClip(getCodeBase(), "hash.au");
    toneA     = getAudioClip(getCodeBase(), "A.au");
    toneB     = getAudioClip(getCodeBase(), "B.au");
    toneC     = getAudioClip(getCodeBase(), "C.au");
    toneD     = getAudioClip(getCodeBase(), "D.au");
    this.requestFocus();
  }

  void pause() {
    try { Thread.sleep(200); }
    catch (InterruptedException e) { return; }
  }

  public void dialDigitString() {
    String s = tfNumber.getText();
    int l = s.length();
    for (int i = 0; i<l; i++) {
      char c = s.charAt(i);
      switch (c) {
        case '0': toneZero.play();  pause(); break;
        case '1': toneOne.play();   pause(); break;
        case '2': toneTwo.play();   pause(); break;
        case '3': toneThree.play(); pause(); break;
        case '4': toneFour.play();  pause(); break;
        case '5': toneFive.play();  pause(); break;
        case '6': toneSix.play();   pause(); break;
        case '7': toneSeven.play(); pause(); break;
        case '8': toneEight.play(); pause(); break;
        case '9': toneNine.play();  pause(); break;
        case '*': toneStar.play();  pause(); break;
        case '#': toneHash.play();  pause(); break;
        case 'A': toneA.play();     pause(); break;
        case 'B': toneB.play();     pause(); break;
        case 'C': toneC.play();     pause(); break;
        case 'D': toneD.play();     pause(); break;
      }
    }
  }

  //Get Applet information
  public String getAppletInfo() {
    return "(C) 1998 Dr Iain A Robin";
  }

  //Get parameter info
  public String[][] getParameterInfo() {
    return null;
  }

  void btnZero_actionPerformed(ActionEvent e) {
    toneZero.play();
    this.requestFocus();
  }

  void btnOne_actionPerformed(ActionEvent e) {
    toneOne.play();
    this.requestFocus();
  }

  void btnTwo_actionPerformed(ActionEvent e) {
    toneTwo.play();
    this.requestFocus();
  }

  void btnThree_actionPerformed(ActionEvent e) {
    toneThree.play();
    this.requestFocus();
  }

  void btnFour_actionPerformed(ActionEvent e) {
    toneFour.play();
    this.requestFocus();
  }

  void btnFive_actionPerformed(ActionEvent e) {
    toneFive.play();
    this.requestFocus();
  }

  void btnSix_actionPerformed(ActionEvent e) {
    toneSix.play();
    this.requestFocus();
  }

  void btnSeven_actionPerformed(ActionEvent e) {
    toneSeven.play();
    this.requestFocus();
  }

  void btnEight_actionPerformed(ActionEvent e) {
    toneEight.play();
    this.requestFocus();
  }

  void btnNine_actionPerformed(ActionEvent e) {
    toneNine.play();
    this.requestFocus();
  }

  void btnStar_actionPerformed(ActionEvent e) {
    toneStar.play();
    this.requestFocus();
  }

  void btnHash_actionPerformed(ActionEvent e) {
    toneHash.play();
    this.requestFocus();
  }

  void btnA_actionPerformed(ActionEvent e) {
    toneA.play();
    this.requestFocus();
  }

  void btnB_actionPerformed(ActionEvent e) {
    toneB.play();
    this.requestFocus();
  }

  void btnC_actionPerformed(ActionEvent e) {
    toneC.play();
    this.requestFocus();
  }

  void btnD_actionPerformed(ActionEvent e) {
    toneD.play();
    this.requestFocus();
  }

  void btnDial_actionPerformed(ActionEvent e) {
    dialDigitString();
    this.requestFocus();
  }

  void tfNumber_focusGained(FocusEvent e) {
    isTextFieldEntry = true;
  }

  void tfNumber_focusLost(FocusEvent e) {
    isTextFieldEntry = false;
  }
  
  void this_keyPressed(KeyEvent e) {
    if (!isTextFieldEntry) {
      switch (e.getKeyChar()) {
        case '0': toneZero.play(); break;
        case '1': toneOne.play(); break;
        case '2': toneTwo.play(); break;
        case '3': toneThree.play(); break;
        case '4': toneFour.play(); break;
        case '5': toneFive.play(); break;
        case '6': toneSix.play(); break;
        case '7': toneSeven.play(); break;
        case '8': toneEight.play(); break;
        case '9': toneNine.play(); break;
        case '#': toneHash.play(); break;
        case '*': toneStar.play(); break;
        case 'a':
        case 'A': toneA.play(); break;
        case 'b':
        case 'B': toneB.play(); break;
        case 'c':
        case 'C': toneC.play(); break;
        case 'd':
        case 'D': toneD.play(); break;
        default:
      }
    }
  }
}

class ToneGenerator_btnZero_actionAdapter implements java.awt.event.ActionListener{
  ToneGenerator adaptee;

  ToneGenerator_btnZero_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnZero_actionPerformed(e);
  }
}

class ToneGenerator_btnOne_actionAdapter implements java.awt.event.ActionListener{
  ToneGenerator adaptee;

  ToneGenerator_btnOne_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnOne_actionPerformed(e);
  }
}

class ToneGenerator_btnTwo_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnTwo_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnTwo_actionPerformed(e);
  }
}

class ToneGenerator_btnThree_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnThree_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnThree_actionPerformed(e);
  }
}

class ToneGenerator_btnFour_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnFour_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnFour_actionPerformed(e);
  }
}

class ToneGenerator_btnFive_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnFive_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnFive_actionPerformed(e);
  }
}

class ToneGenerator_btnSix_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnSix_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnSix_actionPerformed(e);
  }
}

class ToneGenerator_btnSeven_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnSeven_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnSeven_actionPerformed(e);
  }
}

class ToneGenerator_btnEight_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnEight_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnEight_actionPerformed(e);
  }
}

class ToneGenerator_btnNine_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnNine_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnNine_actionPerformed(e);
  }
}

class ToneGenerator_btnStar_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnStar_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnStar_actionPerformed(e);
  }
}

class ToneGenerator_btnHash_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnHash_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnHash_actionPerformed(e);
  }
}

class ToneGenerator_btnA_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnA_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnA_actionPerformed(e);
  }
}

class ToneGenerator_btnB_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnB_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnB_actionPerformed(e);
  }
}

class ToneGenerator_btnC_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnC_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnC_actionPerformed(e);
  }
}

class ToneGenerator_btnD_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnD_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnD_actionPerformed(e);
  }
}

class ToneGenerator_btnDial_actionAdapter implements java.awt.event.ActionListener {
  ToneGenerator adaptee;

  ToneGenerator_btnDial_actionAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.btnDial_actionPerformed(e);
  }
}

class ToneGenerator_tfNumber_focusAdapter extends java.awt.event.FocusAdapter {
  ToneGenerator adaptee;

  ToneGenerator_tfNumber_focusAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void focusGained(FocusEvent e) {
    adaptee.tfNumber_focusGained(e);
  }

  public void focusLost(FocusEvent e) {
    adaptee.tfNumber_focusLost(e);
  }
}

class ToneGenerator_this_keyAdapter extends java.awt.event.KeyAdapter {
  ToneGenerator adaptee;

  ToneGenerator_this_keyAdapter(ToneGenerator adaptee) {
    this.adaptee = adaptee;
  }

  public void keyPressed(KeyEvent e) {
    adaptee.this_keyPressed(e);
  }
}