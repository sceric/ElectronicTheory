/************************************************************
	Copyright (c) 2000 Karl Backstr�m

	This code is under GPL - see COPYING.
************************************************************/

#ifndef __CHANGEDIALOG_H__
#define __CHANGEDIALOG_H__

#include <qdialog.h>
#include <qpushbutton.h>
#include <qlistbox.h>
#include <qstring.h>
#include <qstrlist.h>
#include <qgroupbox.h>
#include <qcheckbox.h>
#include <qlineedit.h>
#include <qcombobox.h>
#include <qfont.h>
#include <qlabel.h>
#include <qlistview.h>

class changeDialog : public QDialog
{
    Q_OBJECT
public:
    changeDialog( QListViewItem *object, QWidget* parent = 0, const char* name = 0);
    virtual ~changeDialog();
    QListViewItem* getItem();
protected slots:
    void Ok_Click();
    void Cancel_Click();
protected:
    QPushButton *Ok_Button, *Cancel_Button;
    QLabel *label;
    QLineEdit *number_e, *name_e;
    QListViewItem *store_object;
    bool wasCanceled;
};

#endif
