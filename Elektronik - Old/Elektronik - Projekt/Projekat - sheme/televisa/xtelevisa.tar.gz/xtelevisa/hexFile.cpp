#include <qfile.h>

int hexFile::Chars2Hex (char cUpper,char cLower)
{
  int nUpper,nLower;
  
  if ((cUpper>='0') && (cUpper<='9'))
    nUpper=cUpper-'0';
  else if ((cUpper>='a') && (cUpper<='f'))
    nUpper=cUpper-'a'+10;
  else if ((cUpper>='A') && (cUpper<='F'))
    nUpper=cUpper-'A'+10;
  else
    return -1;
  if ((cLower>='0') && (cLower<='9'))
    nLower=cLower-'0';
  else if ((cLower>='a') && (cLower<='f'))
    nLower=cLower-'a'+10;
  else if ((cLower>='A') && (cLower<='F'))
    nLower=cLower-'A'+10;
  else
    return -1;
  return nUpper*16+nLower;
}

void hexFile::RowError(int Row)
{
  char szMess[256];

  wsprintf(szMess,"Error in hex file on row %d!",Row);
  QMessageBox::warning(this,"Verify Error",szMess,"OK");
}

BOOL hexFile::ExtractRow(char *FileData, DWORD *BufPos, DWORD BytesRead, BOOL *pStateBuffer,UINT *pBuffer)
{
  BYTE CheckSum;
  DWORD BufPos2,NoOfBytes,Address,AddressHigh,identification,Data,i;
  
  if ((*BufPos+1)>=BytesRead)
    {
      return FALSE;
    }
  if ((NoOfBytes=Chars2Hex(FileData[*BufPos],FileData[*BufPos+1]))==-1)
    return FALSE;
  CheckSum=(BYTE)NoOfBytes;
  if ((*BufPos+9+NoOfBytes*2)>=BytesRead)
    return FALSE;
  if ((AddressHigh=Chars2Hex(FileData[*BufPos+2],FileData[*BufPos+3]))==-1)
    return FALSE;
  CheckSum+=(BYTE)AddressHigh;
  if ((Address=Chars2Hex(FileData[*BufPos+4],FileData[*BufPos+5]))==-1)
    return FALSE;
  CheckSum+=(BYTE)Address;
  Address+=AddressHigh*256;
  if ((Address)>=BUFFER_SIZE)
    return FALSE;
  if ((identification=Chars2Hex(FileData[*BufPos+6],FileData[*BufPos+7]))==1)
    {
      CheckSum+=(BYTE)identification;
      if ((Data=Chars2Hex(FileData[*BufPos+8+NoOfBytes*2],FileData[*BufPos+9+NoOfBytes*2]))==-1)
        return FALSE;
      CheckSum+=(BYTE)Data;
      if (CheckSum)
        return FALSE;
      *BufPos=BytesRead;
      return TRUE;
    }
  BufPos2=*BufPos+8;
  for (i=0;i<NoOfBytes;i++)
    {
      if ((Data=Chars2Hex(FileData[BufPos2],FileData[BufPos2+1]))==-1)
        return FALSE;
      BufPos2+=2;
      CheckSum+=(BYTE)Data;
      if ((Address)>=BUFFER_SIZE)
        return FALSE;
      pStateBuffer[Address]=TRUE;
      //  	pBuffer[Address^1]=Data;	
      pBuffer[Address]=Data;	
      Address++;
    }
  if ((Data=Chars2Hex(FileData[BufPos2],FileData[BufPos2+1]))==-1)
    return FALSE;
  CheckSum+=(BYTE)Data;
  if (CheckSum)
    return FALSE;
  *BufPos=*BufPos+10+NoOfBytes*2;
  return TRUE;
}

BOOL hexFile::ReadHexFile(char *FileName,BOOL *pStateBuffer,UINT *pBuffer,int *pLastValiedCell)
{
  QFile *file;
  char *FileData,szMess[256],temp;
  int FileSize;
  DWORD Row=1,BufPos=0,i;
  BOOL FoundRow=FALSE,Result=TRUE;

  while(file->readLine(tmp,255) >= 0)

  
  *pLastValiedCell=-1;
  QFile *file = new QFile(fileName);
  if (file->open(IO_ReadOnly | IO_Translate))
    {
      wsprintf(szMess,"Can't open the file : %s",FileName);
      QMessageBox::warning(this,"Error",szMess,"OK");
      return FALSE;
    }
  
  FileSize = file->size();
  FileData = new char[FileSize];
  file->readBlock(FileData, FileSize);
  file->close();
  delete file;
  
  for (i=0;i<BUFFER_SIZE;i++)
    {
      pStateBuffer[i]=FALSE;
      pBuffer[i]=0;
    }
  
  /*--- Scan the HEX-file ---*/
  while (BufPos<dwBytesRead)
    {
      while ((FileData[BufPos]!=':') && (BufPos<dwBytesRead))
        {
          if (FileData[BufPos]=='\n') 
            Row++;
          BufPos++;
        }
      if (BufPos<dwBytesRead)
        {
          BufPos++;
          FoundRow=TRUE;
          lstrcpyn(szMess,FileData+BufPos,40);
          if (!ExtractRow(FileData,&BufPos,dwBytesRead,pStateBuffer,pBuffer))
            {
              temp=FileData[BufPos];
              RowError(Row);
              LocalFree(FileData);
              return FALSE;
            }
        }
    }
  if (!FoundRow)
    {
      wsprintf(szMess,"No data in HEX-file : %s",FileName);
      LocalFree(FileData);
      MessageBox(hMainWnd,szMess,NULL,0);
      return FALSE;
    }
  
  LocalFree(FileData);
  *pLastValiedCell=-1;
  for (i=0;i<BUFFER_SIZE;i++)
    if (pStateBuffer[i]) *pLastValiedCell=i;
  return TRUE;
}

BOOL hexFile::ReadHexFiles(char *FileName)
{
  char EEFileName[256];
  
  if (ReadHexFile(FileName,StateBuffer,Buffer,&LastValiedProgramCell))
    {
      strcpy(EEFileName,FileName);
      if (strlen(EEFileName) > 3)
        {
          EEFileName[strlen(EEFileName)-1]='p';
          EEFileName[strlen(EEFileName)-2]='e';
          EEFileName[strlen(EEFileName)-3]='e';
          ReadHexFile(EEFileName,EEStateBuffer,EEBuffer,&LastValiedEEPROMCell);
        }
      return TRUE;
    }
  else
    return FALSE;
}
