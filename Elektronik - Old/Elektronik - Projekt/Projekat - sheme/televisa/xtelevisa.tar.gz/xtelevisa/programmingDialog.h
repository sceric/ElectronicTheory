/************************************************************
	Copyright (c) 2001 Karl Backstr�m

	This code is under GPL - see COPYING.
************************************************************/

#ifndef __PROGRAMMINGDIALOG_H__
#define __PROGRAMMINGDIALOG_H__

#include <sys/ioctl.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h>

#include <qapplication.h>
#include <qprogressdialog.h>
#include <qfiledialog.h>
#include <qdialog.h>
#include <qpushbutton.h>
#include <qlistbox.h>
#include <qstring.h>
#include <qstrlist.h>
#include <qgroupbox.h>
#include <qcheckbox.h>
#include <qlineedit.h>
#include <qcombobox.h>
#include <qfont.h>
#include <qlabel.h>
#include <qmessagebox.h>

#define BYTE unsigned char
#define DWORD unsigned int
#define UINT unsigned int
#define BOOL bool
#define BUFFER_SIZE        0x4000

enum State {prog_code, verify_code, eeprom};

class programmingDialog : public QProgressDialog
{
    Q_OBJECT
public:
    programmingDialog(int _delay, const char *serialport = 0, QWidget* parent = 0, const char* name = 0);
    virtual ~programmingDialog();
protected:
  //  void timerEvent( QTimerEvent * );
  void setProgress(int progress);
  bool startProgramming();
  bool openPort(const char *port);
  void Delay_50ns();
  bool port_out(int port, unsigned char d);
  bool GetDataPin();
  void SetDataPin(bool Bit);
  void SetClockPin(bool Bit);
  void SendByte(unsigned char Data);
  unsigned char ReadByte();
  void ChipErase();
  bool EnterProgramMode();
  void ReadSignatureBytes(char *Byte0, char *Byte1, char *Byte2);
  bool ProgramCodeMemory();
  bool VerifyCodeMemory();
  bool ProgramEEPROMMemory();
  int Chars2Hex (char cUpper,char cLower);
  void RowError(int Row);
  BOOL ExtractRow(char *FileData, DWORD *BufPos, DWORD BytesRead, BOOL *pStateBuffer,UINT *pBuffer);    
  BOOL ReadHexFile(const char *fileName,BOOL *pStateBuffer,UINT *pBuffer,int *pLastValiedCell);
  BOOL ReadHexFiles(const char *fileName);

    int fd;
    int LastValiedProgramCell;
    int LastValiedEEPROMCell;
    unsigned int Buffer[BUFFER_SIZE];
    bool StateBuffer[BUFFER_SIZE];
    unsigned int EEBuffer[BUFFER_SIZE];
    bool EEStateBuffer[BUFFER_SIZE];
  int delay;
  //  QApplication qApp;
  //  unsigned int currentAddress;
  //  int timerId;
  //  enum State state;

};

#endif
