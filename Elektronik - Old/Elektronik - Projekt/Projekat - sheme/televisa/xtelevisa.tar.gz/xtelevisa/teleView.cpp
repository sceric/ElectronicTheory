#include <qdatetime.h>
#include <stdio.h>
#include "teleView.h"
#include "teleView.moc"

int teleView::listMagic[] = { 1,2,3,4,5,6,7,8,0 };

teleView::teleView(QWidget *parent)
  : QListView(parent)
{
  addColumn("Name:",140);
  addColumn("Phone nr:",100);
  addColumn("Nr in:",40);
  addColumn("Nr ut:",46);
  addColumn("Date in:",140);
  addColumn("Date out:",140);
  addColumn("Total in:",60);
  addColumn("Total out:",60);
  addColumn("",0); //H�r ska ljudfilen ligga sedan
  setShowSortIndicator(true);
  setMinimumSize(QSize(400,100));
}

teleView::~teleView()
{
}

QListViewItem *teleView::searchNumber(const char *searchString)
{
  QListViewItem *searchItem;
  for ( searchItem=firstChild(); searchItem != 0; searchItem=searchItem->nextSibling() )
    {

      if (searchString == searchItem->text(1))
	{
	  return searchItem;
	}
    }
  //  fprintf(stderr,"Debug: Nonexisting element = %s\n",searchString);
  return NULL;

}

QString teleView::searchNameByNumber(const char *searchString)
{
  QListViewItem *searchItem;
  for ( searchItem=firstChild(); searchItem != 0; searchItem=searchItem->nextSibling() )
    {
      if (searchString == searchItem->text(1))
	return searchItem->text(0);

    }
  return "";
}

QString teleView::insert(QString Number, QString StartDate, QString StopDate,bool Incomming, bool JustUpdate)
{
  QListViewItem *object;
  QString Name;
  object  = searchNumber(Number);
  if(!Incomming) // Is outgoing
    {
      if(object == NULL ) // New object
	{
	  object = new QListViewItem(this);
	  object->setText(1,Number);
	  object->setText(2,"0");
	  object->setText(3,"1");
          object->setText(5,StartDate);
	  object->setText(6,"0");
          if (StopDate != "")
            object->setText(7,time2time(StartDate,StopDate));
          else
            object->setText(7,"0");
	}
      else // Existing object
	{
	  QString holder;
          if (!JustUpdate)
            {
              holder.sprintf("%d",object->text(3).toInt() + 1);
              object->setText(3,holder);
            }
          object->setText(5,StartDate);
          if (StopDate != "")
            {
              holder.sprintf("%d",object->text(7).toInt() + time2time(StartDate,StopDate).toInt());
              object->setText(7,holder);
            }
          Name = object->text(0);
        }
    }
  else // Is incoming
    {
      if(object == NULL) // New object
	{
	  object = new QListViewItem(this);
	  object->setText(1,Number);
	  object->setText(2,"1");
	  object->setText(3,"0");
	  object->setText(4,StartDate);
          if (StopDate != "")
            object->setText(6,time2time(StartDate,StopDate));
          else
            object->setText(6,"0");
	  object->setText(7,"0");
	}
      else // Existing object
	{
	  QString holder;
          if (!JustUpdate)
            {
              holder.sprintf("%d",object->text(2).toInt() + 1);
              object->setText(2,holder);
            }
	  object->setText(4,StartDate);
          if (StopDate != "")
            {
              holder.sprintf("%d",object->text(6).toInt() + time2time(StartDate,StopDate).toInt());
              object->setText(6,holder);
            }
          Name = object->text(0);
        }
    }
  ensureItemVisible(object);
  sort();
  return Name;
}

QString teleView::time2time(QString StartDate, QString StopDate, int plus = 0)
{
  QString date_s1,date_s2;
  // Input is ex. "2000-01-01 00:05:13,2000-01-01 00:10:13"
  if((StartDate.find(QRegExp("[1-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]"))==0) &&
     (StopDate.find(QRegExp("[1-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]"))==0))
    {
      QString date_s1 = StartDate.left(StartDate.find(' '));
      QDate date_d1(date_s1.left(date_s1.find('-')).toInt(),
		    date_s1.mid(date_s1.find('-')+1,date_s1.find('-',date_s1.find('-'))-date_s1.find('-')+2).toInt(),
		    date_s1.right(date_s1.length()-date_s1.findRev('-')-1).toInt());

      QString time_s1 = StartDate.right(StartDate.find(' '));
      QTime time_t1(time_s1.left(time_s1.find(':')).toInt(),
		    time_s1.mid(time_s1.find(':')+1,time_s1.find(':',time_s1.find(':'))-time_s1.find(':')+2).toInt(),
		    time_s1.right(time_s1.length()-time_s1.findRev(':')-1).toInt());
      
      QString date_s2 = StopDate.left(StopDate.find(' '));
      QDate date_d2(date_s2.left(date_s2.find('-')).toInt(),
		    date_s2.mid(date_s2.find('-')+1,date_s2.find('-',date_s2.find('-'))-date_s2.find('-')+2).toInt(),
		    date_s2.right(date_s2.length()-date_s2.findRev('-')-1).toInt());
      
      QString time_s2 = StopDate.right(StopDate.find(' '));
      QTime time_t2(time_s2.left(time_s2.find(':')).toInt(),
		    time_s2.mid(time_s2.find(':')+1,time_s2.find(':',time_s2.find(':'))-time_s2.find(':')+2).toInt(),
		    time_s2.right(time_s2.length()-time_s2.findRev(':')-1).toInt());
      
      QString ret_time;
      ret_time.sprintf("%d",date_d1.daysTo(date_d2)*86400 + time_t1.secsTo(time_t2) + plus);
      return ret_time;
    }
  else
    {
      printf("Fel i time2time: \"%s, %s\"\n",(const char*)date_s1,(const char*)date_s2);
      return "0";
    }
}

void teleView::readList(const char *fileName)
{
  int i = 0;
  QString tmp;
  QListViewItem *obj;
  QFile *file = new QFile(fileName);
  file->open(IO_ReadOnly | IO_Translate);

  while(file->readLine(tmp,255) >= 0)
    {
      if(tmp.find(QRegExp("[\n]")) >= 0)
	tmp = tmp.remove(tmp.find(QRegExp("[\n]")),1);
      if(tmp.find(QRegExp("[\r]")) >= 0)
	tmp = tmp.remove(tmp.find(QRegExp("[\r]")),1);
      obj = new QListViewItem(this);
      i = 0;
      while(i < 8)
	{
	  obj->setText(listMagic[i],tmp.left(tmp.find(',')).simplifyWhiteSpace());
	  tmp = tmp.right(tmp.length()-tmp.find(',')-1);
	  ++i;
	}
      if(tmp.find(' ') == 0)
	tmp.remove(0,1);
      obj->setText(listMagic[i],tmp);
    }
  file->close();
  delete file;
  sort();
}

void teleView::saveList(const char *fileName)
{
  QListViewItem *saveItem;
  QFile *file = new QFile(fileName);
  if(file->open(IO_WriteOnly))
    {
      QString writeString;
      int count;
      for(int i = 0 ; i < childCount() ; i++)
	{
	  if(i == 0)
	    saveItem = firstChild();
	  else
	    saveItem = saveItem->nextSibling();
	  
	  count = 0;
	  writeString = "";
	  while(count < 8)
	    {
	      writeString.append(saveItem->text(listMagic[count]));
	      writeString.append(',');
	      ++count;
		}
	  writeString.append(saveItem->text(listMagic[count]));
	  writeString.append("\n");
	  file->writeBlock((const char*)writeString,writeString.length());
	    }
      file->close();
    }
  else
    ; //Error Message
  delete file;
}

