#ifndef SERIALCOMM_H
#define SERIALCOMM_H

#include <stdio.h>   /* Standard input/output definitions */
#include <string.h>  /* String function definitions */
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include <qstring.h>
#include <qdatetime.h>

class SerialComm
{
public:
  SerialComm(const char*);
  virtual ~SerialComm();
  int queryDate();
  int queryID();
  int SendNumber(const char*);
  int setTime(const char*);
  int setTime();
  int queryRecord();
  int getHandle();
  QString recvCmd();
  int sendCmd(const char*);
private:

protected:
  int fd;
  QString stored_buffer;
};

#endif 



