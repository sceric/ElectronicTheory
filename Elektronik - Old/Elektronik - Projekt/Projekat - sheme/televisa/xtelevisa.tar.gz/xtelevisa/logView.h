#ifndef __LOGVIEW_H__
#define __LOGVIEW_H__

#include <qfile.h>
#include <qdialog.h>
#include <qpushbutton.h>
#include <qlistbox.h>
#include <qstring.h>
#include <qstrlist.h>
#include <qgroupbox.h>
#include <qcheckbox.h>
#include <qlineedit.h>
#include <qcombobox.h>
#include <qfont.h>
#include <qlabel.h>
#include <qlistview.h>

class logView : virtual public QListView
{
  Q_OBJECT
public:
  logView(QWidget *parent);
  virtual ~logView();
  void setLogSize(int logSize);
  void insertLog(QString Name, QString Number, QString StartDate, QString StopDate, bool JustUpdate);
  void readLog(const char *fileName);
  void saveLog(const char *fileName);
private:
  static int logMagic[4];
  int logsize_i;

};

#endif // __LOGVIEW_H__
