/************************************************************
        Copyright (c) 2000 Karl Backstr�m

        This code is under GPL - see COPYING.
************************************************************/

#include "changeDialog.h"
#include "changeDialog.moc"
#include <qlabel.h>
#include <qlayout.h>

#define LINE_WIDTH 110

changeDialog::changeDialog (QListViewItem *object,
			QWidget* parent, const char* name) 
                        : QDialog ( parent, name, TRUE, 634880 )
{
  store_object = object;

  QBoxLayout *topLayout = new QVBoxLayout(this, 5);
  QGridLayout *settingsLayout = new QGridLayout(2,2);
  QBoxLayout *buttonLayout = new QHBoxLayout();

  topLayout->addLayout(settingsLayout, 10);

  label = new QLabel("Name:", this);
  label->setMinimumSize(label->sizeHint());
  settingsLayout->addWidget(label,0,0);
  
  name_e = new QLineEdit((const char*)store_object->text(0),this);
  name_e->setMinimumSize(QSize(LINE_WIDTH,20));
  settingsLayout->addWidget(name_e,0,1);

  label = new QLabel("Phone nr:", this);
  label->setMinimumSize(label->sizeHint());
  settingsLayout->addWidget(label,1,0);

  number_e = new QLineEdit((const char*)store_object->text(1),this);
  number_e->setMinimumSize(QSize(LINE_WIDTH,20));
  settingsLayout->addWidget(number_e,1,1);

  topLayout->addLayout(buttonLayout, 0);

  buttonLayout->addStretch(10);

  Ok_Button = new QPushButton("Ok", this);
  Ok_Button->setMinimumSize(Ok_Button->sizeHint());
  connect( Ok_Button, SIGNAL(clicked()), SLOT(Ok_Click()) );
  buttonLayout->addWidget(Ok_Button);

  Cancel_Button = new QPushButton("Cancel", this);
  Cancel_Button->setMinimumSize(Cancel_Button->sizeHint());
  connect( Cancel_Button, SIGNAL(clicked()), SLOT(Cancel_Click()) );
  buttonLayout->addWidget(Cancel_Button);

  setCaption("Name/Number");

  setMinimumSize(sizeHint());
  topLayout->activate();
  name_e->setFocus();
}


changeDialog::~changeDialog()
{
}

void changeDialog::Ok_Click()
{
  wasCanceled = FALSE;
  store_object->setText(0,name_e->text());
  store_object->setText(1,number_e->text());
  close();
}

void changeDialog::Cancel_Click()
{
  wasCanceled = TRUE;
  close(TRUE);
}

QListViewItem* changeDialog::getItem()
{
  if(!wasCanceled)
    return store_object;
  else
    return 0;
}
