#include "serial.h"

#define SLEEP_A_LOT  usleep(160000) // 300000

SerialComm::SerialComm(const char *port)
{
  stored_buffer = "";
  fd = open(port, O_RDWR);// | O_NOCTTY | O_SYNC); //| O_NDELAY);
  if (fd == -1)
    {      
      printf("open_port: Unable to open %s - \n",port);
    }
  else
    {
      struct termios options;
      //fcntl(fd, F_SETFL, FNDELAY); 
      tcgetattr(fd, &options);
      cfsetispeed(&options, B1200);
      cfsetospeed(&options, B1200);
      options.c_cflag &= ~PARENB;
      options.c_cflag &= ~CSTOPB;
      options.c_cflag &= ~CSIZE;
      options.c_cflag |= CS8;
      options.c_cflag |= (CLOCAL | CREAD);
      options.c_cflag &= ~CRTSCTS;    /* Also called CRTSCTS */
      options.c_lflag &= ~ICANON;
      options.c_iflag |= IGNBRK;
      tcsetattr(fd, TCSANOW, &options);
    }
};

SerialComm::~SerialComm() 
{ 
  close(fd);
};

int SerialComm::sendCmd(const char *a)
{
  //printf("Debug: Write \"%s\"\n",a);
  QString s = a;
  int n = write(fd, (const char*)s, s.length());
  if(n < 0)
    {
      printf("write() of %d bytes failed!\n",s.length());
      return 0;
    }
  return 1;
};

QString SerialComm::recvCmd()
{
  char buffer[255] = "";  /* Input buffer */
  int  nbytes,i;            /* Number of bytes read */

  nbytes = read(fd, buffer, sizeof(buffer));

  for (i = 0; i < nbytes; i++)
    {
      stored_buffer += buffer[i];
      if (buffer[i] == '\n' || buffer[i] == '\r' ||
	  buffer[i] == 'K' || buffer[i] == 'N' ||
	  buffer[i] == 'R' || buffer[i] == 'S' ||
	  buffer[i] == 'H' || buffer[i] == 'L' )
        {
          QString answer = stored_buffer;
          stored_buffer = "";
          for (i++; i < nbytes; i++)
            stored_buffer += buffer[i];
          return answer;          
        }
    }

  return 0;
};

int SerialComm::queryDate()
{
  int i =  this->sendCmd("G");
  SLEEP_A_LOT;
  return i;
}

int SerialComm::queryID()
{
  int i = this->sendCmd("V");
  SLEEP_A_LOT;
  return i;
}

int SerialComm::SendNumber(const char *number)
{
  char qst[256];
  sprintf(qst,"D%s\r\n",number);
  int i = this->sendCmd(qst);
  SLEEP_A_LOT;
  return i;
}


int SerialComm::setTime(const char *number)
{
  char qst[256];
  sprintf(qst,"S%s\r\n",number);
  int i =  this->sendCmd(qst);
  SLEEP_A_LOT;
  return i;
}

int SerialComm::setTime()
{
  QDate date = QDate::currentDate();
  QTime time = QTime::currentTime();
  char qst[256];

  sprintf(qst,"S%04d-%02d-%02d %02d:%02d:%02d\r\n",
	  date.year(),date.month(),date.day(),
	  time.hour(),time.minute(),time.second());
  int i = this->sendCmd(qst);
  SLEEP_A_LOT;
  return i;
}

int SerialComm::getHandle()
{
  return fd;
}

int SerialComm::queryRecord()
{
  int i = this->sendCmd("N");
  SLEEP_A_LOT;
  return i;
}


#ifdef STANDALONE

main()
{
  QString a;
  SerialComm *l = new SerialComm("/dev/ttyS1");
  a = l->setTime();
  printf("1:A=%s\n",(const char*)a);
  //a = l->queryDate();
  //a = l->queryID();
  //printf("2:A=%s\n",(const char*)a);
  //a = l->SendNumber("0134740221");
  //printf("3:A=%s\n",(const char*)a);
  delete l;
}

#endif
