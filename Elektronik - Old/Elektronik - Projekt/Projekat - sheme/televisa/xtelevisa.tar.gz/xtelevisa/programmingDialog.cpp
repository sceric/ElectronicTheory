/************************************************************
        Copyright (c) 2001 Karl Backstr�m

        This code is under GPL - see COPYING.
************************************************************/

#include "programmingDialog.h"
#include "programmingDialog.moc"
#include <qlabel.h>
#include <qfile.h>
#include <qlayout.h>

programmingDialog::programmingDialog (int _delay, const char *serialport, QWidget* parent, const char* name) 
  : QProgressDialog ( parent, name,TRUE)
{
  QString filename;
  LastValiedProgramCell=-1;
  LastValiedEEPROMCell=-1;
  delay = _delay;

  setLabelText("Programming Hardware");
  setAutoReset ( false);
  
  openPort(serialport);
  this->show();
  filename = QFileDialog::getOpenFileName("","Hex Files (*.hex)");
  if(!filename.isNull() || !filename.isEmpty())
    {
      ReadHexFiles((const char*)filename);
      startProgramming();
    }

  while (! wasCancelled() )
    {
      qApp->processEvents();
      usleep(10000);
    }
  if (fd >= 0) 
    ::close(fd);
  fd = -1;
}

programmingDialog::~programmingDialog()
{
}

bool programmingDialog::openPort(const char *port)
{
  fd = open(port, O_WRONLY);// | O_NOCTTY | O_SYNC| O_NDELAY);
  if (fd == -1)
    {      
      printf("open_port: Unable to open %s - \n",port);
      return false;
    }
  struct termios options;
  cfmakeraw(&options);
  tcsetattr(fd, TCSANOW, &options);
  
}

void programmingDialog::setProgress(int progress)
{
  QProgressDialog::setProgress(progress);
  qApp->processEvents();
}

bool programmingDialog::startProgramming()
{
  char Byte0, Byte1, Byte2;
  bool bEnteredProgramMode,bReProgram;
  char szTmp[256];
  int nErrorAdress;
  
  bEnteredProgramMode = EnterProgramMode();
  
  while (!bEnteredProgramMode)
    {
      if(0 != QMessageBox::warning(this,"Programming","Failed entering programming mode!\n"
				   "Press and release reset switch.","Ok","Cancel"))
	{
	  return false;
	}
      bEnteredProgramMode = EnterProgramMode();
    }
  
  ReadSignatureBytes(&Byte0, &Byte1, &Byte2);
  
  while ((Byte0 == 0) && (Byte1 == 1) && (Byte2 == 2))
    {
      if(0 != QMessageBox::warning(this,"Programming","Failed entering programming mode!\n"
				   "Press and release reset switch.","Ok","Cancel"))
	{
	  return false;
	}
      bEnteredProgramMode = EnterProgramMode();
      ReadSignatureBytes(&Byte0, &Byte1, &Byte2);
    }
  ChipErase();
  setLabelText("Programming Code Memory");
  setTotalSteps(LastValiedProgramCell);
  setProgress(0);

  if (ProgramCodeMemory())
  {
    if (VerifyCodeMemory())
      ProgramEEPROMMemory();
  }
  this->show();
  setCancelButtonText("Done");
  return TRUE;
}

volatile static int dummy;

void programmingDialog::Delay_50ns()
{
  //  usleep(10);
  for (dummy=delay;dummy>0;dummy--)
    {
      dummy=dummy;
    }
}

bool programmingDialog::GetDataPin()
{
  int lines;

  ioctl (fd, TIOCMGET, &lines);
  return !(lines & TIOCM_CTS);
}

void programmingDialog::SetDataPin(bool Bit)
{
  if (Bit)
    ioctl (fd, TIOCSBRK);
  else
    ioctl (fd, TIOCCBRK);
}

void programmingDialog::SetClockPin(bool Bit)
{
  const int rts = TIOCM_RTS;
  if (Bit)
    ioctl (fd, TIOCMBIS, &rts);
  else
    ioctl (fd, TIOCMBIC, &rts);
}

void programmingDialog::SendByte(unsigned char Data)
{
  unsigned int i;

  for (i=0;i<8;i++)
    {
      SetDataPin(Data&0x80);
      Delay_50ns();
      SetClockPin(1);
      Delay_50ns();
      SetClockPin(0);
      Data=Data<<1;
    }
}

unsigned char programmingDialog::ReadByte()
{
  unsigned int i;
  unsigned char Data = 0;

  SetDataPin(0);
  for (i=0;i<8;i++)
    {
      Data=Data<<1;
      Delay_50ns();
      SetClockPin(1);
      if (GetDataPin())
	Data |= 1;
      Delay_50ns();
      SetClockPin(0);
    }
  return Data;
}

void programmingDialog::ChipErase()
{
  SendByte(0xAC);
  SendByte(0x80);
  SendByte(0);
  SendByte(0);
  usleep(40000);
}

bool programmingDialog::EnterProgramMode()
{
  unsigned char Data;
  unsigned int i;
  
  SetDataPin(0);
  SetClockPin(0);
  for (i=0;i<31;i++)
    {
      Delay_50ns();
      SetClockPin(1);
      Delay_50ns();
      SetClockPin(0);
    }
  for (i=0;i<32;i++)
    {
      SendByte(0xAC);
      SendByte(0x53);
      Data = ReadByte();
      SendByte(0);
      if (Data == 0x53)
        {
          //			ChipErase();
          return TRUE;
        }
      Delay_50ns();
      SetClockPin(1);
      Delay_50ns();
      SetClockPin(0);
    }
  return FALSE;
}

void programmingDialog::ReadSignatureBytes(char *Byte0, 
					   char *Byte1, char *Byte2)
{
  SendByte(0x30);
  SendByte(0);
  SendByte(0);
  *Byte0 = ReadByte();
  
  SendByte(0x30);
  SendByte(0);
  SendByte(1);
  *Byte1 = ReadByte();
  
  SendByte(0x30);
  SendByte(0);
  SendByte(2);
  *Byte2 = ReadByte();
}

bool programmingDialog::ProgramCodeMemory()
{
  unsigned int i = 0;
  int a = 0;
  QString temp;

  setLabelText("Programming Code Memory");
  setProgress(0);
  setTotalSteps(LastValiedProgramCell);

  ChipErase();
  while (i <= LastValiedProgramCell)
    {
      if ((StateBuffer[i]) && (Buffer[i] != 0xff))
	{
	  SendByte(0x40 | ((i&1)<<3));
	  SendByte(i>>9);
	  SendByte(i>>1);
	  SendByte(Buffer[i]);
          usleep(10000);
	}
      if (i % 20 == 0)
        setProgress(i);
      i++;
      if ( wasCancelled() )
        {
          return FALSE;
        }
    }
    return TRUE;
}

bool programmingDialog::VerifyCodeMemory()
{
  unsigned char DataRead;
  unsigned int i = 0;

  setLabelText("Verifying Code Memory");
  setTotalSteps(LastValiedProgramCell);
  setProgress(0);


  while (i <= LastValiedProgramCell)
    {
      if (StateBuffer[i])
	{
	  SendByte(0x20 | ((i&1)<<3));
	  SendByte(i>>9);
	  SendByte(i>>1);
	  DataRead = ReadByte();
	  
	  if (DataRead != Buffer[i])
	    {
              QString Mess;
              Mess.sprintf("Verify Error in Code Memory at adress: 0x%X",i);
              QMessageBox::warning(this,"Verify Error",Mess,"OK");
              return FALSE;
	    }
	}
      if (i % 20 == 0)
        setProgress(i);
      i++;
      if ( wasCancelled() )
        {
          return FALSE;
        }
    }
    return TRUE;
}

bool programmingDialog::ProgramEEPROMMemory()
{
  unsigned char DataRead;
  unsigned int i = 0;
  char szTmp[256];
  
  setLabelText("Programming EEPROM");
  setTotalSteps(LastValiedEEPROMCell);
  setProgress(0);


  while (i <= LastValiedEEPROMCell)
    {
      if (EEStateBuffer[i])
	{
	  SendByte(0xc0);
	  SendByte(0);
	  SendByte(i);
	  SendByte(EEBuffer[i]);
	  usleep(10000);
	  SendByte(0xa0);
	  SendByte(0);
	  SendByte(i);
	  DataRead = ReadByte();
          if (DataRead != EEBuffer[i])
            {
              QString Mess;
              Mess.sprintf("Verify Error in EEPROM Memory at adress: 0x%X",i);
              QMessageBox::warning(this,"Verify Error",Mess,"OK");
              return FALSE;              
            }	  
	}
      setProgress(i);
      i++;
      if ( wasCancelled() )
        {
          return FALSE;
        }
    }
    return TRUE;
}

int programmingDialog::Chars2Hex (char cUpper,char cLower)
{
  int nUpper,nLower;
  
  if ((cUpper>='0') && (cUpper<='9'))
    nUpper=cUpper-'0';
  else if ((cUpper>='a') && (cUpper<='f'))
    nUpper=cUpper-'a'+10;
  else if ((cUpper>='A') && (cUpper<='F'))
    nUpper=cUpper-'A'+10;
  else
    return -1;
  if ((cLower>='0') && (cLower<='9'))
    nLower=cLower-'0';
  else if ((cLower>='a') && (cLower<='f'))
    nLower=cLower-'a'+10;
  else if ((cLower>='A') && (cLower<='F'))
    nLower=cLower-'A'+10;
  else
    return -1;
  return nUpper*16+nLower;
}

void programmingDialog::RowError(int Row)
{
  QString Mess;

  Mess.sprintf("Error in hex file on row %d!",Row);
  QMessageBox::warning(this,"Verify Error",Mess,"OK");
}

BOOL programmingDialog::ExtractRow(char *FileData, DWORD *BufPos, DWORD BytesRead, BOOL *pStateBuffer,UINT *pBuffer)
{
  BYTE CheckSum;
  DWORD BufPos2,NoOfBytes,Address,AddressHigh,identification,Data,i;
  
  if ((*BufPos+1)>=BytesRead)
    {
      return FALSE;
    }
  if ((NoOfBytes=Chars2Hex(FileData[*BufPos],FileData[*BufPos+1]))==-1)
    return FALSE;
  CheckSum=(BYTE)NoOfBytes;
  if ((*BufPos+9+NoOfBytes*2)>=BytesRead)
    return FALSE;
  if ((AddressHigh=Chars2Hex(FileData[*BufPos+2],FileData[*BufPos+3]))==-1)
    return FALSE;
  CheckSum+=(BYTE)AddressHigh;
  if ((Address=Chars2Hex(FileData[*BufPos+4],FileData[*BufPos+5]))==-1)
    return FALSE;
  CheckSum+=(BYTE)Address;
  Address+=AddressHigh*256;
  if ((Address)>=BUFFER_SIZE)
    return FALSE;
  if ((identification=Chars2Hex(FileData[*BufPos+6],FileData[*BufPos+7]))==1)
    {
      CheckSum+=(BYTE)identification;
      if ((Data=Chars2Hex(FileData[*BufPos+8+NoOfBytes*2],FileData[*BufPos+9+NoOfBytes*2]))==-1)
        return FALSE;
      CheckSum+=(BYTE)Data;
      if (CheckSum)
        return FALSE;
      *BufPos=BytesRead;
      return TRUE;
    }
  BufPos2=*BufPos+8;
  for (i=0;i<NoOfBytes;i++)
    {
      if ((Data=Chars2Hex(FileData[BufPos2],FileData[BufPos2+1]))==-1)
        return FALSE;
      BufPos2+=2;
      CheckSum+=(BYTE)Data;
      if ((Address)>=BUFFER_SIZE)
        return FALSE;
      pStateBuffer[Address]=TRUE;
      //  	pBuffer[Address^1]=Data;	
      pBuffer[Address]=Data;	
      Address++;
    }
  if ((Data=Chars2Hex(FileData[BufPos2],FileData[BufPos2+1]))==-1)
    return FALSE;
  CheckSum+=(BYTE)Data;
  if (CheckSum)
    return FALSE;
  *BufPos=*BufPos+10+NoOfBytes*2;
  return TRUE;
}

BOOL programmingDialog::ReadHexFile(const char *fileName,BOOL *pStateBuffer,UINT *pBuffer,int *pLastValiedCell)
{
  QFile *file;
  char *FileData,temp;
  QString Mess;
  int FileSize;
  DWORD dwBytesRead, Row=1,BufPos=0,i;
  BOOL FoundRow=FALSE,Result=TRUE;

  *pLastValiedCell=-1;
  file = new QFile(fileName);
  if (!file->open(IO_ReadOnly | IO_Translate))
    {
      Mess.sprintf("Can't open the file : %s",fileName);
      QMessageBox::warning(this,"Error",Mess,"OK");
      return FALSE;
    }
  
  FileSize = file->size();
  FileData = new char[FileSize];
  dwBytesRead = file->readBlock(FileData, FileSize);
  file->close();
  delete file;
  
  for (i=0;i<BUFFER_SIZE;i++)
    {
      pStateBuffer[i]=FALSE;
      pBuffer[i]=0;
    }
  
  /*--- Scan the HEX-file ---*/
  while (BufPos<dwBytesRead)
    {
      while ((FileData[BufPos]!=':') && (BufPos<dwBytesRead))
        {
          if (FileData[BufPos]=='\n') 
            Row++;
          BufPos++;
        }
      if (BufPos<dwBytesRead)
        {
          BufPos++;
          FoundRow=TRUE;
          if (!ExtractRow(FileData,&BufPos,dwBytesRead,pStateBuffer,pBuffer))
            {
              temp=FileData[BufPos];
              RowError(Row);
              delete FileData;
              return FALSE;
            }
        }
    }
  if (!FoundRow)
    {
      Mess.sprintf("No data in HEX-file : %s",fileName);
      QMessageBox::warning(this,"Error",Mess,"OK");
      delete FileData;
      return FALSE;
    }
  
  delete FileData;
  *pLastValiedCell=-1;
  for (i=0;i<BUFFER_SIZE;i++)
    if (pStateBuffer[i]) *pLastValiedCell=i;
  return TRUE;
}

BOOL programmingDialog::ReadHexFiles(const char *fileName)
{
  char EEFileName[256];
  
  if (ReadHexFile(fileName,StateBuffer,Buffer,&LastValiedProgramCell))
    {
      strcpy(EEFileName,fileName);
      if (strlen(EEFileName) > 3)
        {
          EEFileName[strlen(EEFileName)-1]='p';
          EEFileName[strlen(EEFileName)-2]='e';
          EEFileName[strlen(EEFileName)-3]='e';
          ReadHexFile(EEFileName,EEStateBuffer,EEBuffer,&LastValiedEEPROMCell);
        }
      return TRUE;
    }
  else
    return FALSE;
}
