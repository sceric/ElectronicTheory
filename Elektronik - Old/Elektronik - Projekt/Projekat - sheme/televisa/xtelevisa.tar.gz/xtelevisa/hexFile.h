

class programmingDialog
{
  Q_OBJECT
public:
  int hexFile::Chars2Hex (char cUpper,char cLower)

    void hexFile::RowError(int Row)
    
    BOOL hexFile::ExtractRow(char *FileData, DWORD *BufPos, DWORD BytesRead, BOOL *pStateBuffer,UINT *pBuffer)
    
    BOOL hexFile::ReadHexFile(char *FileName,BOOL *pStateBuffer,UINT *pBuffer,int *pLastValiedCell)
    BOOL hexFile::ReadHexFiles(char *FileName)

    private:    
    unsigned int Buffer[BUFFER_SIZE];
    bool StateBuffer[BUFFER_SIZE];
    unsigned int EEBuffer[BUFFER_SIZE];
    bool EEStateBuffer[BUFFER_SIZE];
