
#ifndef MAIN_H
#define MAIN_H

#ifdef USE_KDE
#include <kapp.h>
#else
#include <qapplication.h>
#endif

#include <stdlib.h>
#include <qwidget.h>
#include <qmenubar.h>
#include <qlabel.h>
#include <qlistview.h>
#include <qlayout.h>
#include <qpopupmenu.h>
#include <qkeycode.h>
#include <qmessagebox.h>
#include <qpixmap.h>
#include <qpainter.h>
#include <qsize.h>
#include <qsocketnotifier.h>
#include <qregexp.h>
#include <qpoint.h> 
#include <qcursor.h> 
#include <qfile.h>
#include <qpixmap.h>
#include <qdir.h>
#include <qtextstream.h>
#include <qlist.h>
#include <qevent.h>

#ifdef USE_KDE
#include <ksystemtray.h>
#include <kaboutkde.h>
#endif

#include "serial.h"
#include "setupDialog.h"
#include "callDialog.h"
#include "changeDialog.h"
#include "teleView.h"
#include "logView.h"

class mainWindow : public QWidget

{
  Q_OBJECT
public:
  mainWindow(QWidget* parent=0, const char* name=0);
  virtual ~mainWindow();
  void readConfig();
  bool startMinimized_b;

public slots:
  void debug();
  void settings();
  void programHW();
  void minimizeWindow();
  void save();
  void about();
  void aboutQt();
  void aboutKDE();
  void serialReceive();
  void serialSend();
  void queueSend(const char*);
  void teleRBPressed(QListViewItem *,const QPoint &, int);
  void call();
  void callInSec();
  void changeName();
  void insertName();
  void removeName();

protected:
  QListViewItem *searchNumber(const char*);
  QString searchNameByNumber(const char*);
  QString addAreaCode(QString);
  QString removeAreaCode(QString);
#ifdef USE_KDE
  void showEvent( QShowEvent *);
  void hideEvent( QHideEvent *);
#endif

private:
  void setCalled();
    QMenuBar *menu;
    logView *LogView;
    teleView *TeleView;
    QListViewItem *stored_object; 
    callDialog *caller;
    setupDialog *set;
    changeDialog *change_dialog;
    SerialComm *serial;
    QSocketNotifier *sn1, *sn2;
    QString LastNumber;
    QString LastStartDate;
    bool LastIncomming;
    QString IDstring;
    QString number_s, filename_s, logname_s, port_s;
    bool removeAreaCode_b, needConfigure_b;
    bool hasChangedList;
    QString sendQueue;
    int delay, fontsize;
    int debugClock;
    QPixmap *nocall_icon, *call_icon;
    static int logMagic[4];

#ifdef USE_KDE
    KSystemTray *tray;
#endif

};


#endif // MAIN_H
