#ifndef __TELEVIEW_H__
#define __TELEVIEW_H__

#include <qfile.h>
#include <qdialog.h>
#include <qpushbutton.h>
#include <qlistbox.h>
#include <qstring.h>
#include <qstrlist.h>
#include <qgroupbox.h>
#include <qcheckbox.h>
#include <qlineedit.h>
#include <qcombobox.h>
#include <qfont.h>
#include <qlabel.h>
#include <qlistview.h>

class teleView : virtual public QListView
{
  Q_OBJECT
public:
  teleView(QWidget *parent);
  virtual ~teleView();
  QListViewItem *searchNumber(const char *searchString);
  QString searchNameByNumber(const char *searchString);
  QString insert(QString Number, QString StartDate, QString StopDate,bool Incomming, bool JustUpdate);
  void readList(const char *fileName);
  void saveList(const char *fileName);
private:
  QString time2time(QString StartDate, QString StopDate, int plus = 0);
  static int listMagic[9];
};


#endif // __TELEVIEW_H__
