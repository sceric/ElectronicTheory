/************************************************************
	Copyright (c) 2000 Karl Backstr�m

	This code is under GPL - see COPYING.
************************************************************/

#ifndef __SETUPDIALOG_H__
#define __SETUPDIALOG_H__

#include <qdialog.h>
class QPushButton;
class QLabel;
class QComboBox;
class QCheckBox;
class QLineEdit;
class QString;
class QFile;

class setupDialog : public QDialog
{
    Q_OBJECT
public:
    setupDialog( QWidget* parent, const char* name);
    virtual ~setupDialog();
protected slots:
    void Ok_Click();
    void Cancel_Click();
    void file_Click();
    void log_Click();
    void font_Click();
private:
    void init();
    void save();
protected:
    QPushButton *Ok_Button, *Cancel_Button;
    QPushButton *file_Button, *log_Button, *font_Button;
    QLabel *label;
    QComboBox *port;
    QLineEdit *number, *filename, *logsize, *logname, *delay, *fontsize;
    QString config_s;
    QFile *config_file;
    QCheckBox *removeAC, *minimized;
    QFont *font;
};

#endif
