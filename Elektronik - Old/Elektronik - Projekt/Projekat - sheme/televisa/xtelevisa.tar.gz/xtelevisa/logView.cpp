#include <qtextstream.h>
#include <qdatetime.h>
#include <stdio.h>
#include "logView.h"
#include "logView.moc"

int logView::logMagic[] = { 1,2,3,0};

logView::logView(QWidget *parent)
  : QListView(parent)
{
  addColumn("Name:",150);
  addColumn("Phone nr:",100);
  addColumn("Start date:",140);
  addColumn("Stop date:",140);
  setMinimumSize(QSize(400,100));
  setSorting(2,false); 
  logsize_i = 100;
}

logView::~logView()
{
}

void logView::setLogSize(int logSize)
{
  logsize_i = logSize;
}
void logView::insertLog(QString Name, QString Number, QString StartDate, QString StopDate, bool JustUpdate)
{
  QListViewItem *object, *flex;
  if(JustUpdate)
    {
      for ( object=firstChild(); object != 0; object=object->nextSibling() )
        {
          
          if(strcmp(Number,(const char*)object->text(1)) == 0)
            {
              break;
            }
        }
      if (object == NULL)
        {
          object = new QListViewItem(this);
        }
    }
  else
    {
      if (logsize_i <= childCount())
        {
          flex = firstChild();
          object = flex;
          for(int i = 0 ; i < childCount() ; i++)
            {
              if (strcmp(flex->text(2), object->text(2)) < 0)
                object = flex;
              flex = flex->nextSibling();
            }
        }
      else
        {
          object = new QListViewItem(this);
        }
    }
  object->setText(0,Name);
  object->setText(1,Number);
  object->setText(2,StartDate);
  object->setText(3,StopDate);
  sort();
}

void logView::readLog(const char *fileName)
{
  clear();
  int i = 0;
  QString tmp;
  QListViewItem *obj;
  QFile *file = new QFile(fileName);
  file->open(IO_ReadOnly | IO_Translate);
  while(file->readLine(tmp,255) >= 0)
    {
      if(tmp.find(QRegExp("[\n]")) >= 0)
	tmp = tmp.remove(tmp.find(QRegExp("[\n]")),1);
      if(tmp.find(QRegExp("[\r]")) >= 0)
	tmp = tmp.remove(tmp.find(QRegExp("[\r]")),1);
      obj = new QListViewItem(this);
      i = 0;
      while(i < 3)
	{
	  obj->setText(logMagic[i],tmp.left(tmp.find(',')).simplifyWhiteSpace());
	  tmp = tmp.right(tmp.length()-tmp.find(',')-1);
	  ++i;
	}
      if(tmp.find(' ') == 0)
	tmp.remove(0,1);
      obj->setText(logMagic[i],tmp);
    }
  file->close();
  delete file;
  sort();
}

void logView::saveLog(const char *fileName)
{
  QListViewItem *saveItem;
  QFile *file = new QFile(fileName);
  if(file->open(IO_WriteOnly))
    {
      QString writeString;
      int count;
      for(int i = 0 ; i < childCount() ; i++)
	{
	  if(i == 0)
	    saveItem = firstChild();
	  else
	    saveItem = saveItem->nextSibling();
	  
	  count = 0;
	  writeString = "";
	  while(count < 3)
	    {
	      writeString.append(saveItem->text(logMagic[count]));
	      writeString.append(',');
	      ++count;
            }
	  writeString.append(saveItem->text(logMagic[count]));
	  writeString.append("\n");
	  file->writeBlock((const char*)writeString,writeString.length());
        }
      file->close();
    }
  else
    ; //Error Message
  delete file;
}
