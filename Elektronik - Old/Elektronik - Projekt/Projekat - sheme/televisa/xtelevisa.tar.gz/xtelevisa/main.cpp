#include "main.h"
#include "main.moc"
#include "programmingDialog.h"

#define VERSION "0.9.6"

mainWindow::mainWindow(QWidget *parent, const char *name)
  : QWidget( parent, name )
{
  //   programming_dialog = new programmingDialog("/dev/ttyS1",this,"p");
  //  programming_dialog->show();

  QMenuBar *menu = new QMenuBar( this );

  QPopupMenu *file = new QPopupMenu( this );
  menu->insertItem( "&File", file );
  //file->setItemEnabled(
  file->insertItem("&Program Hardware", this, SLOT(programHW())); // Detta �r inte snyggt men effektivt.
  
  file->insertItem("&Settings", this, SLOT(settings()));
  file->insertItem("Save &Now", this, SLOT(save()));

#ifdef USE_KDE
  file->insertItem("&Dock", this, SLOT(minimizeWindow()), CTRL+Key_D);
#else
  file->insertItem("&Minimize", this, SLOT(minimizeWindow()), CTRL+Key_D);
#endif

  file->insertItem( "E&xit",  qApp, SLOT(quit()), CTRL+Key_Q );    

  menu->insertSeparator();

  QPopupMenu *help = new QPopupMenu( this );
  menu->insertItem( "&Help", help );
  help->insertItem( "&About xTelevisa", this, SLOT(about()), CTRL+Key_H );
  help->insertItem( "About &Qt", this, SLOT(aboutQt()) );
#ifdef USE_KDE
  help->insertItem( "About &KDE", this, SLOT(aboutKDE()));
#endif

  QBoxLayout *topLayout = new QVBoxLayout(this, 5);

  menu->setFixedHeight(menu->sizeHint().height());
  topLayout->addWidget(menu,10);

  TeleView = new teleView(this);
  topLayout->addWidget(TeleView,5);

  connect(TeleView, SIGNAL(rightButtonPressed ( QListViewItem *, const QPoint &, int )),
			   SLOT(teleRBPressed(QListViewItem *,const QPoint &, int)));

  LogView = new logView(this);
  topLayout->addWidget(LogView,0);


  topLayout->activate();
  setMinimumSize( 400, 300 );
  setCaption("xTelevisa - " VERSION );
  setIcon(QPixmap::QPixmap(DATA "icon.xpm"));

  hasChangedList = false;
  LastNumber = "";
  LastStartDate = "";
  LastIncomming = false;

  readConfig();
  TeleView->readList(filename_s);
  LogView->readLog(logname_s);

  serial = new SerialComm((const char*)port_s);
  sn1 = new QSocketNotifier( serial->getHandle(), QSocketNotifier::Read, this );
  QObject::connect(sn1, SIGNAL(activated(int)),this,SLOT(serialReceive()) );
  sn2 = new QSocketNotifier( serial->getHandle(), QSocketNotifier::Write, this );
  QObject::connect(sn2, SIGNAL(activated(int)),this,SLOT(serialSend()) );

  sn1->setEnabled(true);
  sn2->setEnabled(true);

  queueSend("S");
  queueSend("N");
  queueSend("V");

  caller = new callDialog(this);
  caller->setFontSize( fontsize );

#ifdef USE_KDE
  tray = new KSystemTray(this);
  nocall_icon = new QPixmap(DATA "tray.xpm");
  call_icon = new QPixmap(DATA "redtray.xpm");
  tray->setPixmap(*nocall_icon);
#endif

}

mainWindow::~mainWindow()
{
  int ans = 1;  // Default is to not save
  if(hasChangedList) // Check if it is nessesary to save, if nothing has changed the is no need to save.
    ans = QMessageBox::warning(this,"Save","Do you want to save your phonelist?",
			       "Yes","No");
  if(ans == 0)
    {
      TeleView->saveList(filename_s);
      LogView->saveLog(logname_s);
    }
  delete caller;
  delete LogView;
  delete TeleView;
}

#ifdef USE_KDE
void mainWindow::showEvent( QShowEvent *event)
{
  tray->setPixmap(*nocall_icon);
}

void mainWindow::hideEvent( QHideEvent *event)
{
  if(this->isMinimized())
    this->hide();
  if(!tray->isVisible())
    tray->show();
}

void mainWindow::setCalled()
{
  if(this->isHidden())
    tray->setPixmap(*call_icon);
}

#else

void mainWindow::setCalled()
{
}
#endif

void mainWindow::debug()
{
}

void mainWindow::settings()
{
  set = new setupDialog(this,"s");
  set->show();
  //delete set;
  readConfig();
  caller->setFontSize( fontsize );
  delete serial;
  serial = new SerialComm((const char*)port_s);
}

void mainWindow::programHW()
{
  programmingDialog *programming_dialog;
  
  QObject::disconnect(sn1, SIGNAL(activated(int)),0,0 );
  QObject::disconnect(sn2, SIGNAL(activated(int)),0,0 );
  delete serial;
  programming_dialog = new programmingDialog(delay, (const char*)port_s,this,"p");
  delete  programming_dialog;
  serial = new SerialComm((const char*)port_s);
  QObject::connect(sn1, SIGNAL(activated(int)),this,SLOT(serialReceive()) );
  QObject::connect(sn2, SIGNAL(activated(int)),this,SLOT(serialSend()) );
}

void mainWindow::save()
{
  TeleView->saveList(filename_s);
  LogView->saveLog(logname_s);
  hasChangedList = false;
}

void mainWindow::minimizeWindow()
{
#ifdef USE_KDE
  tray->show();
  hide();
#else
  this->showMinimized();
#endif
}

void mainWindow::teleRBPressed(QListViewItem *listobject, const QPoint &p, int a)
{
  stored_object = listobject;
  QPopupMenu *objectMenu = new QPopupMenu( this );
  if(stored_object != 0) // Clicked on existing
    {
      objectMenu->insertItem("&Call", this, SLOT(call()));
      objectMenu->insertItem("&Call in 5 sec", this, SLOT(callInSec()));
      objectMenu->insertItem("&Insert", this, SLOT(insertName()));
      objectMenu->insertItem("&Edit", this, SLOT(changeName()));
      objectMenu->insertItem("&Remove", this, SLOT(removeName()));
    }
  else // Clicked outside
    objectMenu->insertItem("&Insert", this, SLOT(insertName()));

  objectMenu->exec(QCursor::pos());
}

void mainWindow::call()
{
  if(stored_object != 0)
    {
      if(strcmp((const char*)stored_object->text(1),"") != 0)
	{
	  QString tmp = "D";
	  if(removeAreaCode_b)
	    tmp.append((const char*)removeAreaCode(stored_object->text(1)));
	  else
	    tmp.append((const char*)stored_object->text(1));
	  queueSend((const char*)tmp);
	}
    }
}

void mainWindow::callInSec()
{
  int sec = 5;
  if(stored_object != 0)
    {
      if(strcmp((const char*)stored_object->text(1),"") != 0)
	{
	  usleep(sec*1000000);
	  QString tmp = "D"; 
	  if(removeAreaCode_b)
	    tmp.append((const char*)removeAreaCode(stored_object->text(1)));
	  else
	    tmp.append((const char*)stored_object->text(1));
	  queueSend((const char*)tmp);
	}
    }
}

void mainWindow::changeName()
{
  if(stored_object != 0)
    {
      change_dialog = new changeDialog(stored_object,this,"call");
      change_dialog->show();
      hasChangedList = true;
      TeleView->sort();
    }
}

void mainWindow::insertName()
{
  stored_object = new QListViewItem(TeleView);
  change_dialog = new changeDialog(stored_object,this,"call");
  change_dialog->show();
  QListViewItem *tmp = change_dialog->getItem();
  if(tmp != 0)
    {
      hasChangedList = true;
      tmp->setText(2,"0");
      tmp->setText(3,"0");
      tmp->setText(6,"0");
      tmp->setText(7,"0");
      TeleView->insertItem(tmp);
      TeleView->sort();
    }
  else
    {
      delete stored_object;
    }
}

void mainWindow::removeName()
{
  int i = QMessageBox::warning(this,"Remove","Do you really want to remove this item?",
			       "Yes","No");
  if(i == 0)
    {
      hasChangedList = true;
      TeleView->takeItem(stored_object);
      delete stored_object;
    }
}

void mainWindow::about()
{
  queueSend("I");
  QString om = "xTelevisa by\n"
               "Karl Backstr�m <backstrom@kde.org>.\n"
	       "Based on winTelevisa written by\n"
	       "Tomas Franzon.\n"
               "Hardware version: ";
  om.append(IDstring);
  QMessageBox::about( this, "xTelevisa version " VERSION ,(const char*)om);
}

void mainWindow::aboutQt()
{
    QMessageBox::aboutQt( this, "Qt" );
}

void mainWindow::aboutKDE()
{
#ifdef USE_KDE
  KAboutKDE *aboutK = new KAboutKDE(this,"KDE");
  aboutK->show();
  delete aboutK;
#endif
}

void mainWindow::serialReceive()
{
  QString Name, Number, StartDate, StopDate;
  bool Incomming, JustUpdate;
  QString a = serial->recvCmd();
  a = a.simplifyWhiteSpace();

  while((a.find(QRegExp("[RNKHSPL]", true, false)) == 0 
	|| a.find(QRegExp("[RNKHSPL]", true, false)) == (a.length() - 1))
	&& !a.isNull() && !a.isEmpty())
    { 
      QString q;

      if(a.find(QRegExp("[RNKHSPL]", true, false)) == 0)
	{
	  q = a.left(1);
	  a = a.right(a.length()-1);
	}
      else
	{
	  q = a.right(1);
	  a = a.left(a.length()-1);
	}

      if(strcmp((const char*)q,"N") == 0)
	queueSend("N");
      else if(strcmp((const char*)q,"R") == 0)
	{
          QListViewItem *object;
          object = TeleView->searchNumber((const char*)LastNumber);
	  if( object != 0 )
	      caller->show(object->text(0), object->text(1));
	}
      else if(strcmp((const char*)q,"P") == 0)
	;
      else if(strcmp((const char*)q,"H") == 0)
	  QMessageBox::critical(this,"Pick up the phone!",
				"You have to pick up the phone to be able to call!");
      else if(strcmp((const char*)q,"K") == 0)
	;
      else if(strcmp((const char*)q,"L") == 0)
	;
      else if(strcmp((const char*)q,"S") == 0)
	queueSend("S");
      else if(q.isNull() && q.isEmpty())
      	;
      else
	printf("What? %s\n",(const char*)q);

    }
  if(!a.isNull() && !a.isEmpty() && 
     a.contains(QRegExp("[0-9]",false,false)) > 0)
    {
      if(a.find("Tele") != 0)
	{
          //          fprintf(stderr,"%s\n",(const char *)a);
          a = addAreaCode(a);
          Number = a.left(a.find(' '));
          a = a.remove(0,a.find(' ')+1);
          if (strcmp((const char *)a.left(a.find(' ')), "I")==0)
            Incomming = true;
          else if (strcmp((const char *)a.left(a.find(' ')), "O")==0)
            Incomming = FALSE;
          else
            return;
          a = a.remove(0,a.find(' ')+1);
          if (a.find(" - ") == -1)
            {
              StartDate = a;
              StopDate = "";
            }
          else
            {
              StartDate = a.left(a.find(" - "));
              a = a.remove(0,a.find(" - ")+3);
              StopDate = a;
            }

          JustUpdate = ((strcmp((const char *)Number, (const char *)LastNumber)==0) &&
                        (strcmp((const char *)StartDate, (const char *)LastStartDate)==0) &&
                        (Incomming == LastIncomming));
          hasChangedList = true;
          caller->hide();
          setCalled();
          Name = TeleView->insert(Number, StartDate, StopDate, Incomming, JustUpdate);
	  if (Incomming)
	    {
              LogView->insertLog(Name, Number, StartDate, StopDate, JustUpdate);
            }
          LastNumber = Number;
          LastStartDate = StartDate;
          LastIncomming = Incomming;
        }
      else // Set IDString
	{
	  IDstring = a;
	}
    }
}

void mainWindow::serialSend()
{
  if(!sendQueue.isEmpty() && !sendQueue.isNull())
    {
      QString tmp = sendQueue.left(1); 
      QString tmp2 = sendQueue.mid(1,sendQueue.find(';')-1);
      sendQueue = sendQueue.right(sendQueue.length() - sendQueue.find(';') - 1);
      if(strcmp((const char*)tmp,"V") == 0)	
	serial->queryID();	
      else if(strcmp((const char*)tmp,"S") == 0)	
	serial->setTime();	
      else if(strcmp((const char*)tmp,"N") == 0)
	serial->queryRecord();	   
      else if(strcmp((const char*)tmp,"G") == 0)
	serial->queryDate();
      else if(tmp.find("D") == 0)	
	serial->SendNumber((const char*)tmp2);		
    }

  if(sendQueue.isEmpty() || sendQueue.isNull())
    {
      sn2->setEnabled(false);
    }
}

void mainWindow::queueSend(const char *a)
{
  sendQueue.append(a);
  sendQueue.append(";");
  if(!sn2->isEnabled())
    {
      sn2->setEnabled(true);
    }
}

QString mainWindow::addAreaCode(QString in)
{
  in = in.stripWhiteSpace();

  if(in.find("0") != 0)
    in = in.insert(0, number_s);

  return in;
}

QString mainWindow::removeAreaCode(QString in)
{
  in = in.stripWhiteSpace();

  if(in.find(number_s) == 0)
    in = in.remove(0, number_s.length());

  return in;
}

void mainWindow::readConfig()
{
  int logsize_i;
  QString tmp, tmp2;
  QString s = QDir::homeDirPath() + "/.xtelevisarc";
  QFile *file = new QFile(s);
  removeAreaCode_b = false;
  startMinimized_b = false;

  filename_s = QDir::homeDirPath() + "/.xtelev_telelist";
  logname_s = QDir::homeDirPath() + "/.xtelev_log";
  logsize_i = 50;
  delay = 16000;
  fontsize = 40;
      
#ifndef DEVFS
  port_s = "/dev/ttyS1";
#else
  port_s = "/dev/tts/1";
#endif
  if(file->exists())
    {
      if(file->open(IO_ReadOnly ))
        {
          while(file->readLine(tmp,255) >= 0)
            {
              tmp2 = tmp.right(tmp.length() - tmp.findRev('=') - 1);
              tmp2 = tmp2.stripWhiteSpace();
              if(tmp.find("FileName") >= 0)
                filename_s = tmp2;
              else if(tmp.find("LogName") >= 0)
                logname_s = tmp2;
              else if(tmp.find("LogSize") >= 0)
                logsize_i = tmp2.toInt();
              else if(tmp.find("Delay") >= 0)
                delay = tmp2.toInt();
              else if(tmp.find("AreaCode") >= 0)
                number_s = tmp2;
              else if(tmp.find("Port") >= 0)
                port_s = tmp2;
	      else if(tmp.find("Fontsize") >= 0)
                fontsize = tmp2.toInt();
              else if(tmp.find("MinimizedOnStartup") >= 0)
                if(tmp2.find("yes") >= 0)
                  startMinimized_b = true;
                else if(tmp.find("RemoveAC") >= 0)
                  if(tmp2.find("yes") >= 0)
                    removeAreaCode_b = true;
            }
          file->close();
        }
    }
  LogView->setLogSize(logsize_i);
  
  delete file;
}

int main( int argc, char ** argv )
{
#ifdef USE_KDE
    KApplication a(argc, argv, "XTelevisa");
#else
    QApplication a( argc, argv );
#endif

    mainWindow m;

    a.setMainWidget( &m );
    m.readConfig();

    if(m.startMinimized_b)
      m.minimizeWindow();
    else
      m.show();
    return a.exec();
}
