/************************************************************
        Copyright (c) 1998 Karl Backstr�m

        This code is under GPL - see COPYING.
************************************************************/

#include "setupDialog.h"
#include "setupDialog.moc"
#include <qlabel.h>
#include <qlayout.h>
#include <qpushbutton.h>
#include <qcombobox.h>
#include <qlabel.h>
#include <qfiledialog.h>
#include <qcheckbox.h>
#include <qlineedit.h>
#include <qlistbox.h>
#include <qstring.h>
#include <qstrlist.h>
#include <qgroupbox.h>
#include <qdir.h>

setupDialog::setupDialog (QWidget* parent, const char* name) 
                        : QDialog ( parent, name, TRUE, 634880 )
{

  QBoxLayout *topLayout = new QVBoxLayout(this, 5);
  QGridLayout *settingsLayout = new QGridLayout(11,3);
  QBoxLayout *buttonLayout = new QHBoxLayout();

  topLayout->addLayout(settingsLayout, 10);

  label = new QLabel("Port:", this);
  label->setMinimumSize(label->sizeHint());
  settingsLayout->addWidget(label,0,0);

  port = new QComboBox(TRUE,this);

#ifndef DEVFS
  port->insertItem("/dev/ttyS0");
  port->insertItem("/dev/ttyS1");
  port->insertItem("/dev/ttyS2");
  port->insertItem("/dev/ttyS3");
#else
  port->insertItem("/dev/tts/0");
  port->insertItem("/dev/tts/1");
  port->insertItem("/dev/tts/2");
  port->insertItem("/dev/tts/3");
#endif

  port->setMinimumSize(port->sizeHint());
  settingsLayout->addWidget(port,1,0);

  label = new QLabel("Areacode:", this);
  label->setMinimumSize(QSize(100,20));
  settingsLayout->addWidget(label,0,1);

  number = new QLineEdit(this);
  number->setMinimumSize(QSize(70,20));
  settingsLayout->addWidget(number,1,1);

  label = new QLabel("Logsize:", this);
  label->setMinimumSize(label->sizeHint());
  settingsLayout->addWidget(label,0,2);

  logsize = new QLineEdit(this);
  logsize->setMinimumSize(QSize(60,20));
  settingsLayout->addWidget(logsize,1,2);

  label = new QLabel("Filename:", this);
  label->setMinimumSize(label->sizeHint());
  settingsLayout->addMultiCellWidget(label,2,2,0,2);

  filename = new QLineEdit(this);
  filename->setMinimumSize(QSize(100,20));
  settingsLayout->addMultiCellWidget(filename,3,3,0,1);

  file_Button = new QPushButton("Browse", this);
  file_Button->setMinimumSize(file_Button->sizeHint());
  connect( file_Button, SIGNAL(clicked()), SLOT(file_Click()) );
  settingsLayout->addWidget(file_Button,3,2);

  label = new QLabel("Logfile:", this);
  label->setMinimumSize(label->sizeHint());
  settingsLayout->addMultiCellWidget(label,4,4,0,2);

  logname = new QLineEdit(this);
  logname->setMinimumSize(QSize(100,20));
  settingsLayout->addMultiCellWidget(logname,5,5,0,1);

  log_Button = new QPushButton("Browse", this);
  log_Button->setMinimumSize(log_Button->sizeHint());
  connect( log_Button, SIGNAL(clicked()), SLOT(log_Click()) );
  settingsLayout->addWidget(log_Button,5,2);

  removeAC = new QCheckBox("Remove AreaCode on call",this);
  settingsLayout->addMultiCellWidget(removeAC,6,6,0,2);

  minimized = new QCheckBox("Minimize on startup", this);
  settingsLayout->addMultiCellWidget(minimized,7,7,0,2);

  label = new QLabel("Programming delay:", this);
  label->setMinimumSize(label->sizeHint());
  settingsLayout->addMultiCellWidget(label,8,8,0,2);

  delay = new QLineEdit(this);
  delay->setMinimumSize(QSize(100,20));
  settingsLayout->addMultiCellWidget(delay,9,9,0,2);

  label = new QLabel("Fontsize:", this);
  label->setMinimumSize(label->sizeHint());
  settingsLayout->addWidget(label,10,0);

  fontsize = new QLineEdit(this);
  settingsLayout->addMultiCellWidget(fontsize,10,10,1,2);
  //fontsize->setEnabled( FALSE );

  topLayout->addLayout(buttonLayout, 0);
  buttonLayout->addStretch(10);
	
  Ok_Button = new QPushButton("Ok", this);
  Ok_Button->setMinimumSize(Ok_Button->sizeHint());
  connect( Ok_Button, SIGNAL(clicked()), SLOT(Ok_Click()) );
  buttonLayout->addWidget(Ok_Button);

  Cancel_Button = new QPushButton("Cancel", this);
  Cancel_Button->setMinimumSize(Cancel_Button->sizeHint());
  connect( Cancel_Button, SIGNAL(clicked()), SLOT(Cancel_Click()) );
  buttonLayout->addWidget(Cancel_Button);

  setCaption("Setup");

  init();

  setFixedSize(254,127);
  topLayout->activate();
}

void setupDialog::init()
{
  QString tmp, tmp2;
  config_s = QDir::homeDirPath() + "/.xtelevisarc";
  config_file = new QFile(config_s);
  filename->setText(QDir::homeDirPath() + "/.xtelev_telelist");
  logname->setText(QDir::homeDirPath() + "/.xtelev_log");
  logsize->setText("50");
  fontsize->setText("40");
  delay->setText("16000");
  if(config_file->exists())
  {
    if(config_file->open(IO_ReadOnly ))
    {
      while(config_file->readLine(tmp,255) >= 0)
	{
	  tmp2 = tmp.right(tmp.length() - tmp.findRev('=') - 1);
	  tmp2 = tmp2.stripWhiteSpace();
	  if(tmp.find("FileName") >= 0)
	    filename->setText(tmp2);
	  else if(tmp.find("LogName") >= 0)
	    logname->setText(tmp2);
	  else if(tmp.find("LogSize") >= 0)
	    logsize->setText(tmp2);
	  else if(tmp.find("Delay") >= 0)
	    delay->setText(tmp2);
	  else if(tmp.find("AreaCode") >= 0)
	    number->setText(tmp2);
	  else if(tmp.find("Port") >= 0)
	    port->setEditText(tmp2);
	  else if(tmp.find("Fontsize") >= 0)
	      fontsize->setText(tmp2);
	  else if(tmp.find("MinimizedOnStartup") >= 0)
	    {
	      if(tmp2.find("y") >= 0)
		minimized->setChecked(true);
	      else
		minimized->setChecked(false);
	    }
	  else if(tmp.find("RemoveAC") >= 0)
	    {
	      if(tmp2.find("y") >= 0)
		removeAC->setChecked(true);
	      else
		removeAC->setChecked(false);
	    }
	}
      config_file->close();
    }
  }
}

void setupDialog::save()
{
  QString tmp;
  config_file = new QFile(config_s);
  if(config_file->open(IO_WriteOnly ))
    {
      tmp = "FileName=" + filename->text() + "\n" +
	"LogName=" + logname->text() + "\n" +
	"LogSize=" + logsize->text() + "\n" +
	"Delay=" + delay->text() + "\n" +
	"AreaCode=" + number->text() + "\n" +
	"Port=" + port->currentText() + '\n'+
	"Fontsize=" + fontsize->text() + '\n';
      if(removeAC->isChecked())
	tmp.append("RemoveAC=yes\n");
      else
	tmp.append("RemoveAC=no\n");
      if(minimized->isChecked())
	tmp.append("MinimizedOnStartup=yes\n");
      else
	tmp.append("MinimizedOnStartup=no\n");
      config_file->writeBlock((const char*)tmp,tmp.length());
      config_file->close();
    }
  else
    {
      printf("Nu h�nde n�t dumt\n"); // Error message
    }
}

setupDialog::~setupDialog()
{
}

void setupDialog::Ok_Click()
{
  save();
  close();
}

void setupDialog::Cancel_Click()
{
  close();
}

void setupDialog::file_Click()
{
  QString tmp = QFileDialog::getOpenFileName();
  if(tmp != 0)
    filename->setText(tmp);
}

void setupDialog::log_Click()
{
  QString tmp = QFileDialog::getOpenFileName();
  if(tmp != 0)
    logname->setText(tmp);
}

void setupDialog::font_Click()
{

}
