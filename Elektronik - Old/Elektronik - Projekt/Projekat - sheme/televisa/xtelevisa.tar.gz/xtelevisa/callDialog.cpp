/************************************************************
        Copyright (c) 2000 Karl Backstr�m

        This code is under GPL - see COPYING.
************************************************************/

#include "callDialog.h"
#include "callDialog.moc"
#include <qlabel.h>
#include <qlayout.h>

callDialog::callDialog (QWidget* parent) 
                        : QDialog ( parent, "Incomming Call", TRUE, 634880 )
{
  timerCount = 0;
  timerId = -1;

  QBoxLayout *topLayout = new QVBoxLayout(this, 6);
  QBoxLayout *buttonLayout = new QHBoxLayout();

  nameLabel = new QLabel("CallerName", this);
  topLayout->addWidget(nameLabel);
  
  numberLabel = new QLabel("CallerNumber", this);
  topLayout->addWidget(numberLabel);

  label = new QLabel("is calling!", this);
  label->setFont(QFont("Times",30,QFont::Bold));
  topLayout->addWidget(label);

  topLayout->addLayout(buttonLayout, 0);

  timerString.sprintf("Timer: %d",timerCount);
  timerLabel = new QLabel(timerString, this);
  buttonLayout->addWidget(timerLabel);

  buttonLayout->addStretch(10);

  Close_Button = new QPushButton("Close", this);
  Close_Button->setMinimumSize(Close_Button->sizeHint());
  connect( Close_Button, SIGNAL(clicked()), SLOT(Close_Clicked()) );
  buttonLayout->addWidget(Close_Button);

  setCaption("Incomming Call");

  topLayout->activate();

  font = QFont("Times", 40, QFont::Bold);
}


callDialog::~callDialog()
{
}

void callDialog::show(const char *name, const char *number)
{
    nameLabel->setFont(font);
    nameLabel->setText(name);
    nameLabel->setMinimumSize(nameLabel->sizeHint());
    numberLabel->setFont(font);
    numberLabel->setText(number);
    numberLabel->setMinimumSize(numberLabel->sizeHint());
    if (timerCount == 0) 
	timerId = startTimer(1000);
    timerCount = 10;
    setMinimumSize(sizeHint());
    QDialog::show();
}

void callDialog::setFontSize(int f)
{
    font.setPointSize( f );
}

void callDialog::Close_Clicked()
{
  hide();
}
void callDialog::hide()
{
  if ((timerCount != 0) && (timerId != -1))
    {
      killTimer(timerId);
      timerId = -1;
    }
  timerCount = 0;
  QDialog::hide();
}

void callDialog::timerEvent( QTimerEvent *e )
{
  if(timerCount > 0)
    {
      --timerCount;
      timerLabel->setText(timerString.sprintf("Timer: %d",timerCount));
    }
  else
    {
      if (timerId != -1)
        killTimer(timerId);
      hide();
    }
}
