/************************************************************
	Copyright (c) 2000 Karl Backstr�m

	This code is under GPL - see COPYING.
************************************************************/

#ifndef __CALLDIALOG_H__
#define __CALLDIALOG_H__

#include <qdialog.h>
#include <qpushbutton.h>
#include <qlistbox.h>
#include <qstring.h>
#include <qstrlist.h>
#include <qgroupbox.h>
#include <qcheckbox.h>
#include <qlineedit.h>
#include <qcombobox.h>
#include <qfont.h>
#include <qlabel.h>

class callDialog : public QDialog
{
  Q_OBJECT
public:
  callDialog(QWidget* parent = 0);
  virtual ~callDialog();
  void show(const char *name, const char *number);
  void hide();
  void setFontSize(int);
public slots:
  void Close_Clicked();
protected:
  void timerEvent( QTimerEvent * );
  int timerCount;
  int timerId;
  QPushButton *Close_Button;
  QLabel *nameLabel;
  QLabel *numberLabel;
  QLabel *label;
  QString timerString;
  QLabel *timerLabel;
  QFont font;
};

#endif
