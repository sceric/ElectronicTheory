// ScopeDoc.cpp : implementation of the CScopeDoc class
// You should consider this document class as a container of the global variables


#include "stdafx.h"
#include "LPTScope.h"

#include "ScopeDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScopeDoc

IMPLEMENT_DYNCREATE(CScopeDoc, CDocument)

BEGIN_MESSAGE_MAP(CScopeDoc, CDocument)
	//{{AFX_MSG_MAP(CScopeDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScopeDoc construction/destruction

CScopeDoc::CScopeDoc()
{	// TODO: add one-time construction code here
	m_GuideLine			= 280;
	m_TimeFactor		= 1;
	m_YFactor			= 1;
	m_VoltageCorrection	= 19.53125;
	m_TriggerMode		= TRG_INT;
	m_TriggerValue		= (float)0.4;
	m_isNT				= FALSE;
	m_isSlopeUp			= TRUE;
	m_hEventStartRead	= CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially reset
	m_hEventReadDone	= CreateEvent(NULL, TRUE, TRUE, NULL); // manual reset, initially set
	m_hEventKillThread	= CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially reset
	m_hEventThreadKilled= CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially reset
	m_pReadWorkerThread	= NULL;
}

CScopeDoc::~CScopeDoc()
{
}

BOOL CScopeDoc::OnNewDocument()
{	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CScopeDoc serialization

void CScopeDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CScopeDoc diagnostics

#ifdef _DEBUG
void CScopeDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CScopeDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CScopeDoc commands
