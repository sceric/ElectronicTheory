// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "LPTScope.h"

#include "MainFrm.h"
#include "Mmsystem.h"		// for multimedia timer functions (precise timings)
#include "pt_ioctl.h"		// for LPT port writing/reading on WinNT/2k/XP

#include "conio.h"			// for LPT port writing/reading on Win95/98/ME

#include "math.h"			// sin function
#include "BidirectionalTest.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_START, OnStart)
	ON_WM_SHOWWINDOW()
	ON_COMMAND(ID_TIMEBASELEFT, OnTimeBaseLeft)
	ON_COMMAND(ID_TIMEBASERIGHT, OnTimeBaseRight)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDERTIMEBASE, OnCustomDrawSliderTimeBase)
	ON_COMMAND(ID_TRG_OFF, OnTrgOff)
	ON_COMMAND(ID_TRG_INT, OnTrgInt)
	ON_COMMAND(ID_TRG_EXT, OnTrgExt)
	ON_COMMAND(ID_SLOPE_UP, OnSlopeUp)
	ON_COMMAND(ID_SLOPE_DOWN, OnSlopeDown)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDERY, OnCustomdrawSliderY)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDERVCORR, OnCustomdrawSliderVCorr)
	ON_COMMAND(ID_YBASEUP, OnYbaseUp)
	ON_COMMAND(ID_YBASEDOWN, OnYbaseDown)
	ON_BN_CLICKED(IDC_BUTTONDEFAULT, OnButtonDefault)
	ON_COMMAND(ID_BIDIRECTIONALTEST, OnBidirectionalTest)
	ON_COMMAND(ID_STOP, OnStop)
	ON_WM_TIMER()
	ON_UPDATE_COMMAND_UI(ID_TRG_EXT, OnUpdateTrgExt)
	ON_UPDATE_COMMAND_UI(ID_TRG_INT, OnUpdateTrgInt)
	ON_UPDATE_COMMAND_UI(ID_TRG_OFF, OnUpdateTrgOff)
	ON_UPDATE_COMMAND_UI(ID_SLOPE_UP, OnUpdateSlopeUp)
	ON_UPDATE_COMMAND_UI(ID_SLOPE_DOWN, OnUpdateSlopeDown)
	ON_UPDATE_COMMAND_UI(ID_START, OnUpdateStart)
	ON_UPDATE_COMMAND_UI(ID_STOP, OnUpdateStop)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_USER_READ_DONE, OnReadDone)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_nTimerID  = 1;
	m_isRunning = 999;
}

CMainFrame::~CMainFrame()
{	
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.SetButtonStyle(3, m_wndToolBar.GetButtonStyle(3)|/*TBBS_GROUP|*/TBBS_CHECKGROUP);
	m_wndToolBar.SetButtonStyle(4, m_wndToolBar.GetButtonStyle(4)|TBBS_CHECKGROUP);
	m_wndToolBar.SetButtonStyle(5, m_wndToolBar.GetButtonStyle(5)|TBBS_CHECKGROUP);
	m_wndToolBar.SetButtonStyle(7, m_wndToolBar.GetButtonStyle(7)|/*TBBS_GROUP|*/TBBS_CHECKGROUP);
	m_wndToolBar.SetButtonStyle(8, m_wndToolBar.GetButtonStyle(8)|TBBS_CHECKGROUP);

	// Delete these three lines if you don't want the toolbar to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);


	// Create the bottom ControlDialog
	if (!m_wndDlgBar.Create(this, IDD_DLGBAR,
		CBRS_BOTTOM|CBRS_TOOLTIPS|CBRS_FLYBY, IDD_DLGBAR))
	{
		TRACE0("Failed to create DlgBar\n");
		return -1;      // fail to create
	}

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.style = cs.style & ~(FWS_ADDTOTITLE|FWS_PREFIXTITLE); 

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

//______________________________________________________________________________________________
// Program initialisation
void CMainFrame::OnShowWindow(BOOL bShow, UINT nStatus) 
{	CFrameWnd::OnShowWindow(bShow, nStatus);

	BYTE b = 0;
	if (bShow)
	{	m_pDoc = (CScopeDoc*) GetActiveDocument();

		// Is this a WinNT based OS?
		OSVERSIONINFO osvi;
		osvi.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
		if (GetVersionEx (&osvi)) 
			if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
				m_pDoc->m_isNT = TRUE;

		//_____________________________________________________________________________________
		// find out if this machine do have a bidirectional port
		// Put bit 5 of LPT1's control byte high and then check if bit5 realy turned high or hardware keep it locked low. This method is a partial check! works only on some PCs. 
		if (m_pDoc->m_isNT)
		{	OpenPortTalk();
			outportb(890,255);
			outportb(890,255);
			b = inportb(890);
			ClosePortTalk();
		}
		else	// Win95/98/ME
		{	_outp(890,255);
			_outp(890,255);
			b = _inp(890);
		}
		b = b & 0x10;
		if (b == 0)
			MessageBox("Your LPT1 is NOT a bidirectional port.\nDo not use any input devices on it !\n\n(bit5 of contol port doesn't set to high)", "Warning", MB_ICONWARNING);

		//_____________________________________________________________________________________
		// initialisation of LPT1 if the case of ECP port
		if (m_pDoc->m_isNT)	// if WinNT
		{	OpenPortTalk();
			// switch LPT1 to normal-write mode
			outportb(890,0);
			// if LPT1 is an ECP port then switch to byte mode. ECP is not working with bidirectional mode
			// read the Extended Control Register (ECR) 
			b = inportb(0x378+0x402);
			// set ECR to byte_mode
			b = b & 0x3F;
			b = b | 0x20;
			outportb(0x378+0x402, b);
			ClosePortTalk();
		}
		else	// Win95/98/Me
		{	// switch LPT1 to normal-write mode
			_outp(890,0);
			// if LPT1 is an ECP port then switch to byte mode. ECP is not working with bidirectional mode
			// read the Extended Control Register (ECR) 
			b = _inp(0x378+0x402);
			// set ECR to byte_mode
			b = b & 0x3F;
			b = b | 0x20;
			_outp(0x378+0x402, b);
		}


		//_____________________________________________________________________________________
		// Next block is measuring the speed of this PC
		TIMECAPS tc;
		if (timeGetDevCaps(&tc, sizeof (TIMECAPS)) != TIMERR_NOERROR)
			MessageBox("Error gathering time capabilities of this machine");

		// Set time resolution to the minimum supported by the system
		DWORD resolution = min(max(tc.wPeriodMin, 0), tc.wPeriodMax);
		if (timeBeginPeriod(resolution) != TIMERR_NOERROR)
			MessageBox("Error setting the time resolution for multimedia timer");
		
		DWORD nLoops; // how much loops we can make in measuring period
		
		// Changing the priority helps a bit, but Win's kernel doesn't have a real real-time capabilities. This way we keep the program simple but not so precise. Making precise time measuring within windows is not an impossible task, but is close to be impossible.
		SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
		SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL/*THREAD_PRIORITY_HIGHEST*/);

		//----------------------------------- start of time measure
		DWORD MaxLoops;
		DWORD elapsed = timeGetTime();
   		// time measuring loop. Keep it similar as OnStart loop (in the meaning of timing).
		if (m_pDoc->m_isNT)
		{	MaxLoops = MAX_SAMPLES * 6;
			OpenPortTalk();
			for (nLoops=0; nLoops<MaxLoops; nLoops++) // one loop represents one sample
			{	outportb(890,254);
				m_pDoc->m_data[10] = inportb(888);
				outportb(890,255);
			}
			ClosePortTalk();
		}
		else
		{	MaxLoops = MAX_SAMPLES * 200;
			for (nLoops=0; nLoops<MaxLoops; nLoops++)
			{	_outp(890,254);
				m_pDoc->m_data[10] = _inp(888);
				_outp(890,255);
			}
		}
		//----------------------------------- end of time measure
		// get back to normal
		SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);
		SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);

		// calculation of time per sample. This variable is a base for all time values in the program
		m_pDoc->m_usPerSample = (float)(timeGetTime() - elapsed) * 1000 / MaxLoops;

		// destroy the efect of timeBeginPeriod
		if (timeEndPeriod(resolution) != TIMERR_NOERROR)
			MessageBox("Error reseting MMTimer resolution");


		//_____________________________________________________________________________________
		// some additional initialisation
		CSliderCtrl* pCSlider;
		pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERTIMEBASE);
		pCSlider->SetRange(6, 110);
		pCSlider->SetPos(50);
		pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
		pCSlider->SetRange(1, 100);
		pCSlider->SetPos(10);
		pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERVCORR);
		pCSlider->SetRange(1, 100);
		pCSlider->SetPos(10);
		//	---------------------------------------------------------------	
		//	Value Convert Table	|MIN	|DEFAULT	|MAX
		//	---------------------------------------------------------------
		//	IDC_SLIDERVCORR		|1		|10			|100
		//	m_VoltageCorrection	|0.1	|1			|10
		//	IDC_EDITVCORR		|0.5	|5			|50 maxVolts
		//	---------------------------------------------------------------
		//	IDC_SLIDERY			|1		|10			|100
		//	m_FactorY			|0.1	|1			|10
		//	IDC_EDITY			|195	|19.5		|1.95 mV/pix
		//	---------------------------------------------------------------
		//	IDC_SLIDERTIMEBASE	|6		|50			|110
		//	m_TimeFactor		|~0.12	|1			|~2.20
		//	IDC_EDITTIMEBASE	|~46	|			|~2.5 �s/pix
		//	---------------------------------------------------------------	
		


		// fill in the demo signal
		srand ((unsigned)time(NULL));
		switch(rand()%4)
		{
		case 0:	// triangular
			for (nLoops=0; nLoops<MAX_SAMPLES; nLoops++)
				m_pDoc->m_data[nLoops] = (BYTE)nLoops;
			break;
		case 1:	//sine 1
			for (nLoops=0; nLoops<MAX_SAMPLES; nLoops++)
				m_pDoc->m_data[nLoops] = (BYTE)(127+(float)80 * sin((double)nLoops/58))+(BYTE)((float)20 * sin((double)nLoops/12));
			break;
		case 2:	// sine 2
			for (nLoops=0; nLoops<MAX_SAMPLES; nLoops++)
				m_pDoc->m_data[nLoops] = (BYTE)((float)236 * sin((double)nLoops/50));
			break;
		case 3:	// random
			int i=0;
			for (nLoops=0; nLoops<MAX_SAMPLES; nLoops++)
			{	i += rand()%50;
				i -= rand()%50;
				if (i>255) i=235;
				if (i<0) i=20;
				m_pDoc->m_data[nLoops] = i;
			}
			break;
		}
		
		// run the working thread for LPT1 reading and don't read anything untill "start" event fires
		m_pDoc->m_pReadWorkerThread = AfxBeginThread(ReadThread, (LPVOID)m_pDoc);
		m_pDoc->m_hwndNotifyReadDone = m_hWnd;

		m_pDoc->m_DemoSignal = rand()%8+1;
		SetTimer(m_nTimerID, 20, NULL);
	}  
}

void CMainFrame::OnTrgOff() 
{	m_pDoc->m_TriggerMode = TRG_OFF;
	m_pDoc->UpdateAllViews(NULL);
}

void CMainFrame::OnTrgInt() 
{	m_pDoc->m_TriggerMode = TRG_INT;
	m_pDoc->UpdateAllViews(NULL);
}

void CMainFrame::OnTrgExt() 
{	m_pDoc->m_TriggerMode = TRG_EXT;
	m_pDoc->UpdateAllViews(NULL);
}

void CMainFrame::OnSlopeUp() 
{	m_pDoc->m_isSlopeUp = TRUE;
}

void CMainFrame::OnSlopeDown() 
{	m_pDoc->m_isSlopeUp = FALSE;
}

void CMainFrame::OnCustomDrawSliderTimeBase(NMHDR* pNMHDR, LRESULT* pResult) 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERTIMEBASE);
	CEdit* pCEdit = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_EDITTIMEBASE);
	
	m_pDoc->m_TimeFactor = (float)pCSlider->GetPos()/50;
	CString szTemp;
	szTemp.Format("%.2f �s/pixel", m_pDoc->m_usPerSample / m_pDoc->m_TimeFactor);
	pCEdit->SetWindowText(szTemp);
	m_pDoc->UpdateAllViews(NULL);

	*pResult = 0;
}

void CMainFrame::OnCustomdrawSliderY(NMHDR* pNMHDR, LRESULT* pResult) 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
	CEdit* pCEdit = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_EDITY);
	
	m_pDoc->m_YFactor = (float) pCSlider->GetPos() / 10;
	CString szTemp;
	szTemp.Format("%.2f mV/pixel", (5000*m_pDoc->m_VoltageCorrection)/(m_pDoc->m_YFactor*MAX_ADCBITS));
	pCEdit->SetWindowText(szTemp);
	m_pDoc->UpdateAllViews(NULL);
	
	*pResult = 0;
}

void CMainFrame::OnCustomdrawSliderVCorr(NMHDR* pNMHDR, LRESULT* pResult) 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERVCORR);
	CEdit* pCEdit = (CEdit*)m_wndDlgBar.GetDlgItem(IDC_EDITVCORR);
	
	m_pDoc->m_VoltageCorrection = (float) pCSlider->GetPos() / 10;
	CString szTemp;
	szTemp.Format("max input:%.1fV", m_pDoc->m_VoltageCorrection * 5);
	pCEdit->SetWindowText(szTemp);
	
	// fix the Ybase value by invalidating the Ybase slider
	pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
	pCSlider->Invalidate();
	
	*pResult = 0;
}

void CMainFrame::OnYbaseUp() 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
	UINT i = pCSlider->GetPos();
	pCSlider->SetPos(i+1);
}

void CMainFrame::OnYbaseDown() 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
	UINT i = pCSlider->GetPos();
	pCSlider->SetPos(i-1);
}

void CMainFrame::OnTimeBaseLeft() 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERTIMEBASE);
	UINT i = pCSlider->GetPos();
	pCSlider->SetPos(i-1);
}

void CMainFrame::OnTimeBaseRight() 
{	CSliderCtrl* pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERTIMEBASE);
	UINT i = pCSlider->GetPos();
	pCSlider->SetPos(i+1);
}

void CMainFrame::OnButtonDefault() 
{	CSliderCtrl* pCSlider;
	pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERTIMEBASE);
	pCSlider->SetPos(50);
	pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERY);
	pCSlider->SetPos(10);
	pCSlider = (CSliderCtrl*)m_wndDlgBar.GetDlgItem(IDC_SLIDERVCORR);
	pCSlider->SetPos(10);
}

void CMainFrame::OnUpdateTrgExt(CCmdUI* pCmdUI) 
{	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	pCmdUI->SetRadio(pDoc->m_TriggerMode == TRG_EXT);
}

void CMainFrame::OnUpdateTrgInt(CCmdUI* pCmdUI) 
{	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	pCmdUI->SetRadio(pDoc->m_TriggerMode == TRG_INT);
}

void CMainFrame::OnUpdateTrgOff(CCmdUI* pCmdUI) 
{	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	pCmdUI->SetRadio(pDoc->m_TriggerMode == TRG_OFF);
}

void CMainFrame::OnUpdateSlopeUp(CCmdUI* pCmdUI) 
{	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	if (pDoc->m_TriggerMode == TRG_INT)
		pCmdUI->SetRadio(pDoc->m_isSlopeUp);
	else
	{	pCmdUI->Enable(FALSE);
		pCmdUI->SetRadio(FALSE);
	}
}

void CMainFrame::OnUpdateSlopeDown(CCmdUI* pCmdUI) 
{	CScopeDoc* pDoc = (CScopeDoc*) GetActiveDocument();
	if (pDoc->m_TriggerMode == TRG_INT)
		pCmdUI->SetRadio(!pDoc->m_isSlopeUp);
	else
	{	pCmdUI->Enable(FALSE);
		pCmdUI->SetRadio(FALSE);
	}
}

void CMainFrame::OnUpdateStart(CCmdUI* pCmdUI) 
{	pCmdUI->Enable(m_isRunning != TRUE);
}

void CMainFrame::OnUpdateStop(CCmdUI* pCmdUI) 
{	pCmdUI->Enable(m_isRunning != FALSE);
}

void CMainFrame::OnStart() 
{	m_pDoc->m_DemoSignal = FALSE;
	m_isRunning = TRUE;
	KillTimer(m_nTimerID);
	SetTimer(m_nTimerID, 40, NULL);
}

void CMainFrame::OnStop() 
{	KillTimer(m_nTimerID);
	m_isRunning = FALSE;
}

void CMainFrame::OnClose() 
{/*	// Kill the active worker thread.
	// It's a good idea to wait for the worker thread to notify via a
	// "thread killed" event that it has killed itself. Otherwise, in the case
	// where the app is terminating, is possible (even if unlikely) that it
	// will detect a memory leak of the CWinThread object before the
	// CWinThread object has had a chance to auto-delete itself.
	OnStop();
	// Kill the worker thread by setting the "kill thread" event.
	SetEvent(m_pDoc->m_hEventKillThread);
	SetEvent(m_pDoc->m_hEventStartRead);
	WaitForSingleObject(m_pDoc->m_hEventThreadKilled, INFINITE);
*/	
	CFrameWnd::OnClose();
}

LRESULT CMainFrame::OnReadDone(WPARAM, LPARAM)
{	m_pDoc->UpdateAllViews(NULL);
	return 0;
}

void CMainFrame::OnBidirectionalTest() 
{	CBidirectionalTest dlgBT;
	BOOL bOK = TRUE;
	// Before calling BidirectionalTest, assure that signal reading really stoped.
	// We don't want to BidirectionalTest collide with acctual signal reading.
	if (!m_pDoc->m_DemoSignal)
	{	OnStop();
		if (WaitForSingleObject(m_pDoc->m_hEventReadDone, INFINITE) != WAIT_OBJECT_0)
			bOK = FALSE;
	}
	if (bOK) dlgBT.DoModal();
}

//_____________________________________________________________________________________________
// Standard timer function. Fires the ReadingThread, or alters the demo signal when in demo mode
void CMainFrame::OnTimer(UINT nIDEvent) 
{	DWORD nLoop;
	if (!m_pDoc->m_DemoSignal)	// if real signal (not demo)
	{	// start reading the LPT1
		SetEvent(m_pDoc->m_hEventStartRead);
	}
	else if (m_pDoc->m_DemoSignal == 1)		// if in demo mode do some signal shaking
	{	for (nLoop=0; nLoop<MAX_SAMPLES; nLoop++)
			m_pDoc->m_data[nLoop] += (BYTE)nLoop;
		m_pDoc->UpdateAllViews(NULL);
	}
	else
	{	int offset=rand()%3-1;
		for (nLoop=0; nLoop<MAX_SAMPLES; nLoop++)
			m_pDoc->m_data[nLoop] += offset;
		m_pDoc->UpdateAllViews(NULL);
	}

	CFrameWnd::OnTimer(nIDEvent);
}

//______________________________________________________________________________________________
// working thread for bacground reading data from LPT1
UINT ReadThread(LPVOID pParam)
{	DWORD nLoop;
	CScopeDoc* pDoc = (CScopeDoc*) pParam;
	for(;;)
	{	// Wait for "start" event
		if (WaitForSingleObject(pDoc->m_hEventStartRead, INFINITE) != WAIT_OBJECT_0)
			break;

		// Exit the thread if the main application sets the kill event. 
		// The main application will set the "start" event before setting the "kill" event.
		if (WaitForSingleObject(pDoc->m_hEventKillThread, 0) == WAIT_OBJECT_0)
			break; // Terminate this thread by exiting this funct.

		// Reset event to indicate "not done", that is, reading is in progress.
		ResetEvent(pDoc->m_hEventReadDone);

		// Handle the trigger
		switch (pDoc->m_TriggerMode)
		{	case TRG_INT:
			{	float current, previous;
				previous = pDoc->m_isSlopeUp ? (float)9999999 : 0;
				if (pDoc->m_isNT)
				{	OpenPortTalk();
					outportb(890,255);
					for (nLoop=0; nLoop<MAX_SAMPLES*5; nLoop++)
					{	outportb(890,254);
						current = (float)(inportb(888) * 5 * pDoc->m_VoltageCorrection)/MAX_ADCBITS;
						if (pDoc->m_isSlopeUp)
							if (pDoc->m_TriggerValue >= previous)
								if (pDoc->m_TriggerValue <= current)
									break;
						else
							if (pDoc->m_TriggerValue <= previous)
								if (pDoc->m_TriggerValue >= current)
									break;
						previous = current;
						outportb(890,255);
					}
					ClosePortTalk();
				}
				else
				{	_outp(890,255);
					for (nLoop=0; nLoop<MAX_SAMPLES*20; nLoop++)
					{	_outp(890,254);
						current = (float)(_inp(888) * 5 * pDoc->m_VoltageCorrection)/MAX_ADCBITS;
						if (pDoc->m_isSlopeUp)
							if (pDoc->m_TriggerValue >= previous)
								if (pDoc->m_TriggerValue <= current)
									break;
						else
							if (pDoc->m_TriggerValue <= previous)
								if (pDoc->m_TriggerValue >= current)
									break;
						previous = current;
						_outp(890,255);
					}	
				}
				break;
			}
			case TRG_EXT:		// external trigger fires at rising edge of Ack (pin10 of LPT1) wihich is 6th bit of Status port.
			{	BYTE current, previous = 0xFF;
				if (pDoc->m_isNT)
				{	OpenPortTalk();
					for (nLoop=0; nLoop<MAX_SAMPLES*5; nLoop++)
					{	current = inportb(889);
						current = current & 0x40;
						if (previous == 0)
							if (current)
								break;
						previous = current;
					}
					ClosePortTalk();
				}
				else
				{	for (nLoop=0; nLoop<MAX_SAMPLES*10; nLoop++)
					{	current = _inp(889);
						current = current & 0x40;
						if (previous == 0)
							if (current)
								break;
						previous = current;
					}
				}
				break;
			}
		}
		// end of trigger handling

		// read the data
		if (pDoc->m_isNT)
		{	OpenPortTalk();
			outportb(890,255);	// set control port, bits 5 and 0 are used
								// bit5=bidrectionalON, bit0=pin1(strobe on LPT)=WR/RD on ADC 
			for (nLoop=0; nLoop<MAX_SAMPLES; nLoop++)
			{	outportb(890,254);
				pDoc->m_data[nLoop] = inportb(888);
				outportb(890,255);
			}
			ClosePortTalk();
		}
		else
		{	_outp(890,255);	// set control port, bits 5 and 0 are used
							// bit5=bidrectionalON, bit0=pin1(strobe on LPT)=WR/RD on ADC
			// Changing the priority helps a bit, but Win's kernel doesn't have a real real-time capabilities. This way we keep the program simple but not so precise. Making precise time measuring within windows is not an impossible task, but is close to be impossible.
			SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL/*THREAD_PRIORITY_HIGHEST*/);
			for (nLoop=0; nLoop<MAX_SAMPLES; nLoop++)
			{	_outp(890,254);
				pDoc->m_data[nLoop] = _inp(888);
				_outp(890,255);
			}	
			// get back to normal
			SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);
		}
		// end of reading the data
	
		// display the signal
		::PostMessage(pDoc->m_hwndNotifyReadDone, WM_USER_READ_DONE, 0, 0); // this is same as pDoc->UpdateAllViews(NULL);

		// notify that we finished with the reading
		SetEvent(pDoc->m_hEventReadDone);
	}
	SetEvent(pDoc->m_hEventThreadKilled);
	return 0;
}
	
