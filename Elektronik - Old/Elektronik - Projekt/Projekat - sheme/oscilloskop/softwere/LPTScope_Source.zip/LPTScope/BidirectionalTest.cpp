// BidirectionalTest.cpp : implementation file
//

#include "stdafx.h"
#include "lptscope.h"
#include "BidirectionalTest.h"
#include "conio.h"			// for LPT port writing/reading on Win95/98/ME
#include "pt_ioctl.h"		// for LPT port writing/reading on WinNT/2k/XP
#include "pt_ioctl.c"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBidirectionalTest dialog


CBidirectionalTest::CBidirectionalTest(CWnd* pParent /*=NULL*/)
	: CDialog(CBidirectionalTest::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBidirectionalTest)
	m_nRead = 0;
	//}}AFX_DATA_INIT
	m_nTimerID = 2;
	m_bNT = FALSE;
}


void CBidirectionalTest::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBidirectionalTest)
	DDX_Text(pDX, IDC_EDIT_READ, m_nRead);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBidirectionalTest, CDialog)
	//{{AFX_MSG_MAP(CBidirectionalTest)
	ON_WM_SHOWWINDOW()
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBidirectionalTest message handlers

// Initialisation of Bidirectional Test
void CBidirectionalTest::OnShowWindow(BOOL bShow, UINT nStatus) 
{	CDialog::OnShowWindow(bShow, nStatus);
	
	if (bShow)
	{	// create bigger font. Default font is too small
		m_fontBig.CreateFont(
			48,	                       // nHeight
			0,                         // nWidth
			0,                         // nEscapement
			0,                         // nOrientation
			FW_NORMAL,                 // nWeight
			FALSE,                     // bItalic
			FALSE,                     // bUnderline
			0,                         // cStrikeOut
			ANSI_CHARSET,              // nCharSet
			OUT_DEFAULT_PRECIS,        // nOutPrecision
			CLIP_DEFAULT_PRECIS,       // nClipPrecision
			DEFAULT_QUALITY,           // nQuality
			DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
			"Arial");                 // lpszFacename	
		m_fontSmall.CreateFont(
			24,	                       // nHeight
			0,                         // nWidth
			0,                         // nEscapement
			0,                         // nOrientation
			FW_NORMAL,                 // nWeight
			FALSE,                     // bItalic
			FALSE,                     // bUnderline
			0,                         // cStrikeOut
			ANSI_CHARSET,              // nCharSet
			OUT_DEFAULT_PRECIS,        // nOutPrecision
			CLIP_DEFAULT_PRECIS,       // nClipPrecision
			DEFAULT_QUALITY,           // nQuality
			DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
			"Arial");                 // lpszFacename	

		// initialisation of dialog controls
		CEdit * edit = (CEdit*) GetDlgItem(IDC_EDIT_READ);
		edit->SetFont(&m_fontBig);
		CStatic * edit_prompt = (CStatic*) GetDlgItem(IDC_STATIC_READ);
		edit_prompt->SetFont(&m_fontSmall);
		CStatic * blink = (CStatic*) GetDlgItem(IDC_STATIC_BLINK);
		blink->SetFont(&m_fontBig);

		CStatic * pic     = (CStatic*) GetDlgItem(IDC_CONNECTOR);
		CStatic * message = (CStatic*) GetDlgItem(IDC_STATIC2);

		// which OS version?
		OSVERSIONINFO osvi;
		osvi.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
		if (GetVersionEx (&osvi)) 
			if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
				m_bNT = TRUE;

		if (m_bNT)	// if WinNT
		{	//initialisation of LPT1 if the case of ECP port
			OpenPortTalk();
			// switch LPT1 to normal-write mode
			outportb(890,0);
			// if LPT1 is an ECP port then switch to byte mode. ECP is not working with bidirectional mode
			// read the Extended Control Register (ECR) 
			m_nRead = inportb(0x378+0x402);
			// set ECR to byte_mode
			m_nRead = m_nRead & 0x3F;
			m_nRead = m_nRead | 0x20;
			outportb(0x378+0x402, m_nRead);
			// set LPT1 data to 0xFF
			outportb(888,255);
			// switch LPT1 to read mode
			outportb(890,254);
			// read the actual data
			m_nRead = inportb(888);
			ClosePortTalk();
		}
		else	// Win95/98/Me
		{	// switch LPT1 to normal-write mode
			_outp(890,0);
			// if LPT1 is an ECP port then switch to byte mode. ECP is not working with bidirectional mode
			// read the Extended Control Register (ECR) 
			m_nRead = _inp(0x378+0x402);
			// set ECR to byte_mode
			m_nRead = m_nRead & 0x3F;
			m_nRead = m_nRead | 0x20;
			_outp(0x378+0x402, m_nRead);
			// set LPT1 data to 0xFF
			_outp(888,255);
			// switch LPT1 to read mode
			_outp(890,254);
			m_nRead = _inp(888);
		}
		UpdateData(FALSE);

		
		if (m_nRead & 128)
		{	pic->SetBitmap(::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_CONN9)));
			message->SetWindowText ("Connect a 1kOhm resistor between pin9(DATA7) and pin25(GND) of LPT1 port. Be careful and don't be afraid.");
		}
		else if (m_nRead & 64)
		{	pic->SetBitmap(::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_CONN8)));
			message->SetWindowText ("Connect a 1kOhm resistor between pin8(DATA6) and pin25(GND) of LPT1 port. Be careful and don't be afraid.");
		}
		else if (m_nRead & 32)
		{	pic->SetBitmap(::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_CONN7)));
			message->SetWindowText ("Connect a 1kOhm resistor between pin7(DATA5) and pin24(GND) of LPT1 port. Be careful and don't be afraid.");
		}
		else if (m_nRead & 16)
		{	pic->SetBitmap(::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_CONN6)));
			message->SetWindowText ("Connect a 1kOhm resistor between pin6(DATA4) and pin24(GND) of LPT1 port. Be careful and don't be afraid.");
		}
		else if (m_nRead & 8)
		{	pic->SetBitmap(::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_CONN5)));
			message->SetWindowText ("Connect a 1kOhm resistor between pin5(DATA3) and pin22(GND) of LPT1 port. Be careful and don't be afraid.");
		}
		else if (m_nRead & 4)
		{	pic->SetBitmap(::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_CONN4)));
			message->SetWindowText ("Connect a 1kOhm resistor between pin4(DATA2) and pin21(GND) of LPT1 port. Be careful and don't be afraid.");
		}
		else if (m_nRead & 2)
		{	pic->SetBitmap(::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_CONN3)));
			message->SetWindowText ("Connect a 1kOhm resistor between pin3(DATA1) and pin20(GND) of LPT1 port. Be careful and don't be afraid.");
		}
		else if (m_nRead & 1)
		{	pic->SetBitmap(::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_CONN2)));
			message->SetWindowText ("Connect a 1kOhm resistor between pin2(DATA0) and pin19(GND) of LPT1 port. Be careful and don't be afraid.");
		}
		else
		{	pic->SetBitmap(::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_CONNEXT)));
			message->SetWindowText ("Connect a 1kOhm resistor and a 4.5V-5V battery between pin2(DATA0) and pin24(GND) of LPT1 port. Be careful.");
		}

		m_nPreviousRead = m_nRead;
		SetTimer(m_nTimerID, 500, NULL);
	}
	
}		

HBRUSH CBidirectionalTest::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// Set some of the text color to red
	if (pWnd->GetDlgCtrlID() == IDC_EDIT_READ)
		pDC->SetTextColor(RGB(255, 0, 0));
	if (pWnd->GetDlgCtrlID() == IDC_STATIC_BLINK)
		pDC->SetTextColor(RGB(255, 0, 0));
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CBidirectionalTest::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	// do exit clean from the dialog
	KillTimer(m_nTimerID);
	m_fontBig.DeleteObject();
	m_fontSmall.DeleteObject();
}

void CBidirectionalTest::OnTimer(UINT nIDEvent) 
{	// do the LPT1 reading
	if (m_bNT)
	{	OpenPortTalk();
		outportb(890,254);	
		m_nRead = inportb(888);
	    ClosePortTalk();
	}
	else //Win98
	{	_outp(890,254);	
		m_nRead = _inp(888);
	}
	UpdateData(FALSE);
	
	// check if read value has changed
	if (m_nRead != m_nPreviousRead)
	{	CString szCongratulate;
		szCongratulate.Format("Congratulations. Reading has changed from %d to %d. That means your LPT1 is a bidirectional port.", m_nPreviousRead, m_nRead);
		m_nPreviousRead = m_nRead;
		CStatic * cCongratulate = (CStatic*) GetDlgItem(IDC_STATIC_CONGRATULATE);
		cCongratulate->SetWindowText(szCongratulate);
	}

	// blink the dot
	CStatic * blink = (CStatic*) GetDlgItem(IDC_STATIC_BLINK);
	if (m_bBlink = m_bBlink ? FALSE : TRUE)
		blink->SetWindowText(".");
	else
		blink->SetWindowText("");
	// end of blink

	CDialog::OnTimer(nIDEvent);
}
