// ScopeDoc.h : interface of the CScopeDoc class
// You should consider this document class as a container of the global variables
/////////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCOPEDOC_H__C9151AF2_FD50_46D6_8587_C4FE828F35CD__INCLUDED_)
#define AFX_SCOPEDOC_H__C9151AF2_FD50_46D6_8587_C4FE828F35CD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CScopeDoc : public CDocument
{
protected: // create from serialization only
	CScopeDoc();
	DECLARE_DYNCREATE(CScopeDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScopeDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	BYTE	m_data[MAX_SAMPLES];	// reading data samples
	BOOL	m_isNT;					// is this OS a NT one?
	float	m_TriggerValue;			// trigger level in volts
	INT		m_TriggerMode;			// trigger mode (OFF, INT, EXT)
	BOOL	m_isSlopeUp;			// trigger fires on raising or falling edge
	INT		m_DemoSignal;			// demo mode? If yes, which demo mode.
	INT		m_GuideLine;			// guide line value (Blue dashed line with Volts on the left side). Pixels is the unit.
	float	m_TimeFactor;			// time base
	float	m_usPerSample;			// measured speed of this PC (not very precise, because win background prosesses take some time slices)
	float	m_YFactor;				// Y base
	float	m_VoltageCorrection;	// Input voltage correction. mV/pixel, initial is 5000mV/256pixels. This correction is useful when you have a resistor divider on the input of ADC.
	// Handles for communication to and from ReadThread working thread
	HANDLE	m_hEventStartRead;		// (in) signals the ReadThread that it should read a block of data from LPT1
	HANDLE	m_hEventReadDone;		// (out) reading the block from LPT1 ended (not in process of reading)
	HANDLE	m_hEventKillThread;		// (in) signals the ReadThread that it should not work anymore (destroy itself)
	HANDLE	m_hEventThreadKilled;	// (out) signals that working thread doesn't exist anymore 
	CWinThread* m_pReadWorkerThread;// pointer to our thread which reads the LPT1
	HWND	m_hwndNotifyReadDone;	// Frame (main) window handler

	virtual ~CScopeDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CScopeDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCOPEDOC_H__C9151AF2_FD50_46D6_8587_C4FE828F35CD__INCLUDED_)
