/******************************************************************************/
/*                                                                            */
/*       Interface for PortTalk V2.1                                          */
/*       we need this when running on NT based OS                             */
/*       based on example from Craig Peacock                                  */
/*       Copyright � 2002 Craig Peacock. Craig.Peacock@beyondlogic.org        */
/*       at http://www.beyondlogic.org                                        */
/******************************************************************************/
#include "winioctl.h"
#include "WINSVC.H"
#include "Windows.h"
#include "porttalk_IOCTL.h"

HANDLE PortTalk_Handle;        /* Handle for PortTalk Driver */
char message[255];

void outportb(unsigned short PortAddress, unsigned char byte)
{
    unsigned int error;
    DWORD BytesReturned;        
    unsigned char Buffer[3];
    unsigned short * pBuffer;
    pBuffer = (unsigned short *)&Buffer[0];
    *pBuffer = PortAddress;
    Buffer[2] = byte;

    error = DeviceIoControl(PortTalk_Handle,
                            IOCTL_WRITE_PORT_UCHAR,
                            &Buffer,
                            3,
                            NULL,
                            0,
                            &BytesReturned,
                            NULL);

    if (!error) {
		sprintf(message, "Error occured during outportb while talking to PortTalk driver. error:%d\n",GetLastError());
//	    MessageBox(NULL, message, "PortTalk error", MB_OK);
	}
}

unsigned char inportb(unsigned short PortAddress)
{
    unsigned int error;
    DWORD BytesReturned;
    unsigned char Buffer[3];
    unsigned short * pBuffer;
    pBuffer = (unsigned short *)&Buffer;
    *pBuffer = PortAddress;

    error = DeviceIoControl(PortTalk_Handle,
                            IOCTL_READ_PORT_UCHAR,
                            &Buffer,
                            2,
                            &Buffer,
                            1,
                            &BytesReturned,
                            NULL);

    if (!error) {
		sprintf(message, "Error occured during inportb while talking to PortTalk driver. error:%d\n",GetLastError());
//	    MessageBox(NULL, message, "PortTalk error", MB_OK);
	}
    return(Buffer[0]);
}

unsigned char OpenPortTalk(void)
{   /* Open PortTalk Driver. If we cannot open it, try installing and starting it */
    PortTalk_Handle = CreateFile("\\\\.\\PortTalk", 
                                 GENERIC_READ, 
                                 0, 
                                 NULL,
                                 OPEN_EXISTING, 
                                 FILE_ATTRIBUTE_NORMAL, 
                                 NULL);

    if(PortTalk_Handle == INVALID_HANDLE_VALUE) {
            /* Start or Install PortTalk Driver */
			StartPortTalkDriver();
            /* Then try to open once more, before failing */
            PortTalk_Handle = CreateFile("\\\\.\\PortTalk", 
                                         GENERIC_READ, 
                                         0, 
                                         NULL,
                                         OPEN_EXISTING, 
                                         FILE_ATTRIBUTE_NORMAL, 
                                         NULL);
               
            if(PortTalk_Handle == INVALID_HANDLE_VALUE) {
                    sprintf(message, "Couldn't access PortTalk Driver, Please ensure driver is loaded.\n\n(Read readme.txt for the manual installation)");
					MessageBox(NULL, message, "PortTalk", MB_OK);
					return -1;
            }
    }
	return 0;
}

void ClosePortTalk(void)
{
    CloseHandle(PortTalk_Handle);
}

unsigned char StartPortTalkDriver(void)
{
    SC_HANDLE  SchSCManager;
    SC_HANDLE  schService;
    BOOL       ret;
    DWORD      err;

    /* Open Handle to Service Control Manager */
    SchSCManager = OpenSCManager (NULL,                        /* machine (NULL == local) */
                                  NULL,                        /* database (NULL == default) */
                                  SC_MANAGER_ALL_ACCESS);      /* access required */
                         
    if (SchSCManager == NULL)
      if (GetLastError() == ERROR_ACCESS_DENIED) {
         /* We do not have enough rights to open the SCM, therefore we must */
         /* be a poor user with only user rights. */
         sprintf(message, "You do not have administrative rights to access the Service Control Manager and\nthe PortTalk driver is not installed or started. Please ask\nyour administrator to install the driver on your behalf.");
         MessageBox(NULL, message, "PortTalk driver install", MB_OK);
	     return(0);
         }

    do {
         /* Open a Handle to the PortTalk Service Database */
         schService = OpenService(SchSCManager,         /* handle to service control manager database */
                                  "PortTalk",           /* pointer to name of service to start */
                                  SERVICE_ALL_ACCESS);  /* type of access to service */

         if (schService == NULL)
            switch (GetLastError()){
                case ERROR_ACCESS_DENIED:
                        sprintf(message, "You do not have rights to the PortTalk service database\nTry login as an administrator user");
						MessageBox(NULL, message, "PortTalk driver install", MB_OK);
                        return(0);
                case ERROR_INVALID_NAME:
                        sprintf(message, "The specified service name is invalid.\n");
						MessageBox(NULL, message, "PortTalk driver install", MB_OK);
                        return(0);
                case ERROR_SERVICE_DOES_NOT_EXIST:
                        sprintf(message, "Installing PortTalk driver...This can take up to 30 seconds...\n\n\nPress OK to continue");
						MessageBox(NULL, message, "PortTalk", MB_OK);
                        InstallPortTalkDriver();
                        break;
            }
         } while (schService == NULL);

    /* Start the PortTalk Driver. Errors will occur here if PortTalk.SYS file doesn't exist */
    
    ret = StartService (schService,    /* service identifier */
                        0,             /* number of arguments */
                        NULL);         /* pointer to arguments */
                    
    if (ret) printf("PortTalk: The PortTalk driver has been successfully started.\n");
    else {
        err = GetLastError();
        if (err == ERROR_SERVICE_ALREADY_RUNNING) {
          sprintf(message, "The PortTalk driver is already running.");
		  MessageBox(NULL, message, "PortTalk", MB_OK);
		}
        else {
          sprintf(message, "Unknown error while starting PortTalk driver service.\nDoes PortTalk.SYS exist in your \\System32\\Drivers Directory?");
          MessageBox(NULL, message, "PortTalk", MB_OK);
		  return(0);
        }
    }

    /* Close handle to Service Control Manager */
    CloseServiceHandle (schService);
    return(TRUE);
}

void InstallPortTalkDriver(void)
{
    SC_HANDLE  SchSCManager;
    SC_HANDLE  schService;
    DWORD      err;
    CHAR         DriverFileName[80];

    /* Get Current Directory. Assumes PortTalk.SYS driver is in this directory.    */
    /* Doesn't detect if file exists, nor if file is on removable media - if this  */
    /* is the case then when windows next boots, the driver will fail to load and  */
    /* a error entry is made in the event viewer to reflect this */

    /* Get System Directory. This should be something like c:\windows\system32 or  */
    /* c:\winnt\system32 with a Maximum Character lenght of 20. As we have a       */
    /* buffer of 80 bytes and a string of 24 bytes to append, we can go for a max  */
    /* of 55 bytes */

    if (!GetSystemDirectory(DriverFileName, 55))
        {
         sprintf(message, "Failed to get System Directory. Is System Directory Path > 55 Characters?\nPlease manually copy PortTalk driver to your system32/driver directory.");
         MessageBox(NULL, message, "PortTalk", MB_OK);
        }

    /* Append our Driver Name */
    lstrcat(DriverFileName,"\\Drivers\\PortTalk.sys");
    printf("PortTalk: Copying driver to %s\n",DriverFileName);

    /* Copy Driver to System32/drivers directory. This fails if the file doesn't exist. */

    if (!CopyFile("PortTalk.sys", DriverFileName, FALSE))
        {
         sprintf(message, "Failed to copy PortTalk.sys driver to %s\nPlease manually copy driver to your system32/driver directory.",DriverFileName);
		 MessageBox(NULL, message, "PortTalk install error", MB_OK);
        }

    /* Open Handle to Service Control Manager */
    SchSCManager = OpenSCManager (NULL,                   /* machine (NULL == local) */
                                  NULL,                   /* database (NULL == default) */
                                  SC_MANAGER_ALL_ACCESS); /* access required */

    /* Create Service/Driver - This adds the appropriate registry keys in */
    /* HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services - It doesn't  */
    /* care if the driver exists, or if the path is correct.              */

    schService = CreateService (SchSCManager,                      /* SCManager database */
                                "PortTalk",                        /* name of service */
                                "PortTalk",                        /* name to display */
                                SERVICE_ALL_ACCESS,                /* desired access */
                                SERVICE_KERNEL_DRIVER,             /* service type */
                                SERVICE_DEMAND_START,              /* start type */
                                SERVICE_ERROR_NORMAL,              /* error control type */
                                "System32\\Drivers\\PortTalk.sys", /* service's binary */
                                NULL,                              /* no load ordering group */
                                NULL,                              /* no tag identifier */
                                NULL,                              /* no dependencies */
                                NULL,                              /* LocalSystem account */
                                NULL                               /* no password */
                                );

    if (schService == NULL) {
         err = GetLastError();
         if (err == ERROR_SERVICE_EXISTS) {
               sprintf(message, "PortTalk driver already exists. No action taken.");
		       MessageBox(NULL, message, "PortTalk", MB_OK);
		 }
         else {
			 printf("Unknown error while creating PortTalk service.");    
			 MessageBox(NULL, message, "PortTalk", MB_OK);
		 }
    }
    else printf("PortTalk: Driver successfully installed.\n");

    /* Close Handle to Service Control Manager */
    CloseServiceHandle (schService);
}