#if !defined(AFX_BIDIRECTIONALTEST_H__33A5E735_9C15_4CBE_AF3F_9C528BBB4285__INCLUDED_)
#define AFX_BIDIRECTIONALTEST_H__33A5E735_9C15_4CBE_AF3F_9C528BBB4285__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



// BidirectionalTest.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBidirectionalTest dialog

class CBidirectionalTest : public CDialog
{
// Construction
public:
	CBidirectionalTest(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBidirectionalTest)
	enum { IDD = IDD_DIALOGTEST };
	BYTE	m_nRead;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBidirectionalTest)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL	m_bBlink;
	CFont	m_fontBig;
	CFont	m_fontSmall;
	UINT	m_nTimerID;
	BYTE	m_nPreviousRead;

	// Generated message map functions
	//{{AFX_MSG(CBidirectionalTest)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BIDIRECTIONALTEST_H__33A5E735_9C15_4CBE_AF3F_9C528BBB4285__INCLUDED_)
