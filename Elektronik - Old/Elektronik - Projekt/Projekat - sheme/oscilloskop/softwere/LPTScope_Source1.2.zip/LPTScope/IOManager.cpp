#include "stdafx.h"
#include "winioctl.h"
#include "WINSVC.H"
#include "Windows.h"
#include <windows.h>
#include "atlbase.h"

void LoadIOManager(){
	DWORD			piD;
	HKEY			hKey;
	BOOL			ret;
	DWORD*			ProcessPT;
	BYTE*			ProcessID;
	SC_HANDLE		SchSCManager;
	SC_HANDLE		schService;
	CHAR			DriverFilePath[100];
	WIN32_FIND_DATA	found;
	char			message[255];


    /* Open Handle to Service Control Manager */
    SchSCManager = OpenSCManager (NULL,                   /* machine (NULL == local) */
                                  NULL,                   /* database (NULL == default) */
                                  SC_MANAGER_ALL_ACCESS); /* access required */

    /* Create Service/Driver - This adds the appropriate registry keys in */
    /* HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services - It doesn't  */
    /* care if the driver exists, or if the path is correct.              */

	GetFullPathName	("IOManager.sys", 100, DriverFilePath, NULL);
	if (FindFirstFileA (DriverFilePath, &found) != INVALID_HANDLE_VALUE)
	{
		schService = CreateService (SchSCManager,				/* SCManager database */
									"IOManager",				/* name of service */
									"IOManager",				/* name to display */
									SERVICE_ALL_ACCESS,			/* desired access */
									SERVICE_KERNEL_DRIVER,		/* service type */
									SERVICE_DEMAND_START,		/* start type */
									SERVICE_ERROR_NORMAL,		/* error control type */
									DriverFilePath,				/* service's binary */
									NULL,						/* no load ordering group */
									NULL,						/* no tag identifier */
									NULL,						/* no dependencies */
									NULL,						/* LocalSystem account */
									NULL						/* no password */
									);
		RegOpenKeyEx	(HKEY_LOCAL_MACHINE,
						"SYSTEM\\CurrentControlSet\\Services\\IOManager",
						NULL,
						KEY_CREATE_SUB_KEY + KEY_SET_VALUE,
						&hKey);

		piD=GetCurrentProcessId();
		ProcessPT = &piD;
		__asm
		{
			push eax
			mov  eax,  ProcessPT	// This manipulation must be done because conversion from DWORD* to BYTE*
			mov  ProcessID, eax		// is not allowed, and RegSetValueEx requires pointer to BYTE array
			pop  eax
		};
		RegSetValueEx	(hKey,
						"ProcessId",
						NULL,			   // In this part we save Process Id to registry
						REG_DWORD,		   // Actually, we give parameter to
						ProcessID,		   // IOManager.sys
						4);
		ret = StartService	(schService,	/* service identifier */
							0,				/* number of arguments */
							NULL);
		RegDeleteValueA (hKey, "ProcessId");
		RegCloseKey (hKey);
		DeleteService (schService);
		CloseServiceHandle (schService);
	}
	else 
	{
		sprintf (message, "                   Couldn't find IOManager.sys file !!!\n Make sure that this file is in the same directory as LPTScope.exe\n      Copy driver in same directory and start program again!");
		MessageBox (NULL, message, "IOManager", MB_OK);
		CloseServiceHandle (SchSCManager);
		ExitProcess (0);
	}
    CloseServiceHandle (SchSCManager);
}
