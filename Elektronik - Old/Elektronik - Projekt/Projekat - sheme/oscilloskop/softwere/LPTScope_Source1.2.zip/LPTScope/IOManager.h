/******************************************************************************/
/*                                                                            */
/*                            IOPM Establishing                               */
/*                        Version 1.0, March 2004                             */
/*                                                                            */
/*                                                                            */
/* Copyright � 2004  Zilot div2@panet.co.yu                                   */
/*                                                                            */
/* This function LoadIOManager, should load IOManager.sys. That kernel driver */
/* should  remove  windows NT based OS restrition to access  ports directly   */
/* from ring 3 mode. So after  driver  does his job, you  can  in usual way   */
/* access to any port.Pay attention how you use this feature, sistem can crash*/
/*                                                                            */
/* IOManager.sys takes one parameter. That parameter is process id, and is    */
/* neccessary, because IOManager.sys will ensure access to our ring3 program  */
/* to all ports.                                                              */
/* Parameter is taken via registry. With "void LoadIOManager(void)" we will   */
/* load driver, and it will be active only during loading, so there is no     */
/* communication with it via DeviceIoControl. After loading,driver will query */
/* value from registry we put there before starting driver (it is process id) */
/* and will ensure acces to all IO ports. After that driver will be removed   */
/* from memory by OS, because it is not needed anymore.                       */
/******************************************************************************/



void LoadIOManager(void);

