<?php 
// Andy2005
 echo "<?xml version=\"1.0\"?>";echo "\n";
?>

<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN"
"http://www.wapforum.org/DTD/wml_1.1.xml">
<wml><card id="no1" title="S�kresultat">
<?php
if ($namnet=="") {
?>
<form method="POST" action="<?php echo $PHP_SELF ?>" >S�k lokalt:
			<input style="font-family:verdana;font-size:9" type="Text" name="namnet">
			<input style="font-family:verdana;font-size:9" type="submit" value="OK">
			</form>

<?php
} else {
?>
<?php

$sqlfraga=sprintf("select DISTINCT calls.number, book.name FROM calls,book WHERE book.name LIKE '%s%s%s' and calls.number=book.number order by date desc limit 30","%",$namnet,"%");

	$db = mysql_connect("localhost", "cid","cidpasswd") or die("mysql_connect failed");
	$color=0;
	$add=0;
	mysql_select_db("cid",$db) or die("mysql_select_db failed");
	$result = mysql_query($sqlfraga,$db) or die("mysql_query failed");
	$antkol = mysql_num_fields($result);
	
//$kolnamn = mysql_list_fields($result);
	while ($myrow = mysql_fetch_row($result)) {
		$one=1;	
		echo "<br>";
		for($i=0;$i<$antkol; $i=($i+1)){
		

			printf($myrow[$i]);echo "<br>";

		}
		
	}
	if ($one!=1) { echo "nopp..."; }
		}//else
	

?><br><a href="cidwml.php">Tillbaka</a></card></wml>
