<?php 
// Andy2005
 echo "<?xml version=\"1.0\"?>";echo "\n";
?>

<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN"
"http://www.wapforum.org/DTD/wml_1.1.xml">
<wml><card id="no1" title="<?printf(date("Ymd H:i"));?>"><?php
	$start=1;
	$sqlfraga = "select calls.date, book.name,calls.number FROM calls LEFT OUTER JOIN book 
on calls.number=book.number ORDER BY calls.date DESC LIMIT 7";
	$db = mysql_connect("localhost", "cid","cidpasswd") or die("mysql_connect failed");
	mysql_select_db("cid",$db) or die("mysql_select_db failed");
	$result = mysql_query($sqlfraga,$db) or die("mysql_query failed");
	$antkol = mysql_num_fields($result);
	while ($myrow = mysql_fetch_row($result)) {
		echo "<p>";
		for($i=0;$i<$antkol; $i=($i+1)){
		
		if ($i==1) {
		if (($myrow[1]=="")&&($myrow[2]!="Dolt nummer"))  {
		printf("<a href=cgi/hitta.cgi?number=");
		printf($myrow[2]);
		printf("+>*</a>");
		} else {printf($myrow[$i]); }}
				 else {
			printf($myrow[$i]);
		
		}
	if (($myrow[1]=="")&&($i==1)) ; else echo "<br>";
	
	}
		
	echo "<br></p>";
	}//for
echo "\n<p>";
?><? echo exec('ps -C csid u');
echo "<br>";
 echo exec('lsmod|grep csi');
echo "</p>\n"
?><form method="POST" action="wmlsearch.php">S�k lokalt: <input type="Text" name="namnet"><input type="submit" value="OK"></form></card></wml>

