/* csi.c */
#include "csi.h"


static ssize_t module_output(struct file *filp,	/* see include/linux/fs.h   */
			     char *buffer,	/* buffer to fill with data */
			     size_t length,	/* length of the buffer     */
			     loff_t * offset)
{
	int done_that=0;
	static int finished = 0;
	int i;
	if (DEBUG) printk(KERN_INFO "csi : someone read /proc/csi\n");
	if (finished) {
		finished = 0;
		done_that=0;
		pbuf=csi_num_buff; // reset pointer 
		return 0;
		
	}
	
	for (i = 0; i < BUF_LEN &&csi_num_buff[i]; i++)
		if ((csi_num_buff[i]!='\0')||(csi_num_buff[i]!='\n')) {
		
		if (!done_that)
			{put_user(csi_num_buff[i], buffer + i);}
		else
			{put_user('\0', buffer + i);}
		} else
		{
			if (done_that)
				{put_user('\0', buffer + i);}
			else
				{done_that=1;put_user(' ', buffer + i);}
			
		}

	finished = 1;
	return i;		/* Return the number of bytes "read" */
}
static ssize_t
module_input(struct file *filp, const char *buff, size_t len, loff_t * off){
char proc_input[PROC_INPUT_LEN];
	int i;
	for (i = 0; i < PROC_INPUT_LEN - 1 && i < len; i++)
		get_user(proc_input[i], buff + i); 

	proc_input[i] = '\0';	/* we want a standard, zero terminated string */

	if (DEBUG) printk(KERN_INFO "csi : someone wrote /proc/csi: %s\n",proc_input);
	// did we get a pid of a client?
	if ((proc_input[0]>='0') && (proc_input[0]<='9'))
	{
		pid_of_client=0;
		pid_of_client=own_atoi(proc_input);
		if (DEBUG) printk(KERN_INFO "csi : got pid of client (%i)\n",pid_of_client);
	
		p_user_task = find_task_by_pid(pid_of_client);
		if (p_user_task) {
			get_task_struct(p_user_task);
			}
	} else if (proc_input[0]=='S') {
		// or simulating incomming call?
		pbuf=csi_num_buff; // reset pointer 
		printk(KERN_INFO "csi : simulating incomming call from %s\n",proc_input+1);
		int j;
		j=1;
		while (proc_input[j]!='\0') {
			csi_num_buff[j-1]=proc_input[j];
			//printk(KERN_INFO "csi[%i] : %c\n",j,csi_num_buff[j-1]);
			j++;
		}
		csi_num_buff[j-1]='\0';
	
		//printk(KERN_INFO "csi : at csibuff %s",csi_num_buff);
	}
	
	return i;
}
static int module_permission(struct inode *inode, int op, struct nameidata *foo){
	/*
	 * We allow everybody to read from our module, but
	 * only root (uid 0) may write to it
	 */
	if (op == 4 || (op == 2 && current->euid == 0))
		return 0;

	return -EACCES;
}
int module_open(struct inode *inode, struct file *file){
	try_module_get(THIS_MODULE);
	if (DEBUG) printk(KERN_INFO "csi : someone opened /proc/csi\n");
	return 0;
}
int module_close(struct inode *inode, struct file *file){
	module_put(THIS_MODULE);
	if (DEBUG) printk(KERN_INFO "csi : someone closed our /proc/csi\n");
	return 0;		/* success */
}
static struct file_operations File_Ops_4_Our_Proc_File = {
	.read = module_output,
	.write = module_input,
	.open = module_open,
	.release = module_close,
};
static struct inode_operations Inode_Ops_4_Our_Proc_File = {
	.permission = module_permission,	/* check for permissions */
};

irqreturn_t irq_handler_csi(int irq, void *dev_id, struct pt_regs *regs)
 {
   static unsigned long flags;
   
   save_flags (flags); asm("cli"); // save flags and disable interrupt TODO spinlocks instead
    static int raw_data;
    raw_data=inb(csi_base_addr+1);  // this is the critical part...
    restore_flags (flags);  // restore flags and restore interrupt bit
	
	if (!enable_dtmf_timeout)
	{
		//init_timer(&dtmf_timer);
		dtmf_timer.function = dtmf_timeout_timer;
		enable_dtmf_timeout = 1;
		dtmf_timer.expires = jiffies + TIMER_INT_DELAY;
		add_timer(&dtmf_timer);
	}

 static int data;
	data =  (((raw_data & 0x80) == 0?1:0) * 8) +
      	  (((raw_data & 0x08) == 0?0:1) * 4) +
      	  (((raw_data & 0x20) == 0?0:1) * 2) +
      	  (((raw_data & 0x10) == 0?0:1) * 1);
 if ((pbuf-csi_num_buff)==BUF_LEN) pbuf=csi_num_buff;

   	if(data >= 0x0 && data <= 0xF) *pbuf = chars[data]; else *pbuf = '?';
    if (DEBUG) printk(KERN_INFO "csi : Incomming data: 0x%X character:%c\n",data,*pbuf);

      if ((*pbuf=='D') || (*pbuf=='B') || (*pbuf=='A'))
      { // this will be BOF
	      have_BOT=1;
      	if (DEBUG) printk(KERN_INFO "csi : BOT: %c\n",*pbuf);
      	pbuf=csi_num_buff; // reset pointer
      } else
      {
      	if (*pbuf=='C')
      	{ // this will be EOT
		
      		if (DEBUG) printk(KERN_INFO "csi : EOT\n");
                  
	     		*pbuf='\0';
			if (!have_BOT) { //must have BOT
				
				if (DEBUG) printk(KERN_INFO "csi : EOT without BOT ignore\n");
    
				pbuf=csi_num_buff;
			} else { //ok to send
                        if (DEBUG) printk(KERN_INFO "csi : len of incomming : %i\n",(pbuf-csi_num_buff));
				have_BOT=0;
				del_timer(&dtmf_timer);
				enable_dtmf_timeout = 0;
    if (DEBUG) printk(KERN_INFO "csi : sent signal to daemon with pid %i\n",(pid_of_client));
	     		
				if (p_user_task) {
				force_sig(SIGUSR1, p_user_task);
			} else {
			printk(KERN_INFO "csi : Got call but no pid to daemon process. Can't send signal\n");
			}
				
			} // endif numb<7
			
	} else
	     	{
     			pbuf++;
     		}
     	}
     	while (inb(csi_base_addr+1)&INTERRUPT) {} // wait for int to go low
     	// asm("sti"); would not mess things up! restoring flags instead used longer up
      
	return IRQ_HANDLED;
}

static int __csi_init_module(void) {
	// char csi_version[]=CSI_VERSION;
	sprintf(csi_num_buff,"%c",'\0');
	pid_of_client=0;
	if (DEBUG) printk(KERN_INFO "csi : debug mode. module_init started\n");
	
	if (csi_irq==0) {
		switch(csi_base_addr) {
			case 0x378: csi_irq=7; break;
			case 0x278: csi_irq=2; break;
			case 0x3bc: csi_irq=5; break;
		}
	}
	// Check the region
	if (check_region(csi_base_addr,3)) {
		printk(KERN_ALERT "csi : port 0x%x is already in use!\ncsi : Unload any modules that occupies the port. \ncsi : See /proc/ioports for more info.", csi_base_addr);
		return -1;
	}
	// request the region
	request_region(csi_base_addr, 3, "csi");
	 
	

	
	// Activate power to the circuit and enable interrupt
	outb(POWERPINS, csi_base_addr);
	outb(inb(csi_base_addr+2) | 0x10, csi_base_addr+2);
	
	Our_Proc_File = create_proc_entry("csi", 0644, NULL);
	
	if (Our_Proc_File == NULL){
		printk(KERN_ALERT "Error: Could not initialize /proc/csi\n");
		return -ENOMEM;
	}
	
	Our_Proc_File->owner = THIS_MODULE;
	Our_Proc_File->proc_iops = &Inode_Ops_4_Our_Proc_File;
	Our_Proc_File->proc_fops = &File_Ops_4_Our_Proc_File;
	Our_Proc_File->mode = S_IFREG | S_IRUGO | S_IWUSR;
	Our_Proc_File->uid = 0;
	Our_Proc_File->gid = 0;
	Our_Proc_File->size = 50;

	pbuf=csi_num_buff;
	p_user_task=NULL;

	// Trying to get our interrupt
	if (request_irq(csi_irq, irq_handler_csi, SA_INTERRUPT, "csi", NULL)) {
		printk(KERN_ALERT "csi : failed to get irq %d\n", csi_irq);
		outb(0, csi_base_addr);
		outb(inb(csi_base_addr+2) & ~(0x10), csi_base_addr+2);
		release_region(csi_base_addr, 3);
		remove_proc_entry("csi",NULL);
		printk(KERN_INFO "csi : Module is unloaded\n");
		return -1;
	}
	init_timer(&dtmf_timer);
	printk(KERN_INFO "csi : csi-module version %s is loaded (IRQ: %i PORT_BASE: 0x%x)\n",csi_version,csi_irq, csi_base_addr);
	return 0;
}

static void __csi_cleanup(void) {
	free_irq(csi_irq, NULL);
	outb(0, csi_base_addr);
	outb(inb(csi_base_addr+2) & ~(0x10), csi_base_addr+2);
	release_region(csi_base_addr, 3);
	remove_proc_entry("csi",NULL);
	del_timer(&dtmf_timer);
	printk(KERN_INFO "csi : csi-module version %s is unloaded (IRQ: %i PORT_BASE: 0x%x)\n",csi_version,csi_irq, csi_base_addr);
}
int own_atoi(s)
char s[];
{
	int	n = 0;
	char 	c;
	for (c = *s; c >= '0' && c <= '9'; c = *++s)
	 n = n * 10 + c - '0';
	return n;
}

static void dtmf_timeout_timer(unsigned long ptr)
{
	asm("cli"); 
	if (DEBUG) printk(KERN_INFO "csi : dtmf_timer timeout!\n");
	del_timer(&dtmf_timer);
	enable_dtmf_timeout = 0;
	have_BOT=0;
	pbuf=csi_num_buff; // reset pointer 
	asm("sti");
}

