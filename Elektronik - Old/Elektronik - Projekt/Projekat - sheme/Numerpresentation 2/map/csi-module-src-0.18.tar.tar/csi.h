/* csi.h */

// defines
#define DEBUG 1

#define CSI_VERSION 	"0.18"
// remember to change version on module desc, TODO
#define TIMER_INT_DELAY   3*HZ
#define PROC_INPUT_LEN 	20
#define POWERPINS 	0x03
#define BUF_LEN		50
#define LPT_DEFAULT	0x378
#define INTERRUPT 	0x40
#define DTMF_CHARS 	"D1234567890*#ABC"
#ifndef MODULE
	#define MODULE
#endif
#define MOD_INC_USE_COUNT
#define MOD_DEC_USE_COUNT
#define EXPORT_NO_SYMBOLS

#include <linux/fs.h>
#include <linux/interrupt.h>  /* we want an interrupt */
#include <linux/ioport.h>	/* req. regions etc */
#include <linux/signal.h>
#include <linux/init.h>		/* Needed for the macros */
#include <linux/kernel.h>	/* Needed for KERN_ALERT */
#include <linux/module.h>	/* Needed by all modules */
#include <linux/proc_fs.h>
#include <linux/types.h>
#include <linux/init.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <asm/system.h>
#include <asm/irq.h>
#include <linux/sched.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Andy Sj�holm <asjoholm@kth.se>");
MODULE_DESCRIPTION("A driver for own made caller-id hardware v0.18");
MODULE_SUPPORTED_DEVICE("DTMF decoder on parallel port");

MODULE_PARM(csi_irq, "i");
MODULE_PARM(csi_base_addr, "i");

MODULE_PARM_DESC(csi_irq, "IRQ of the choosen LPT address");
MODULE_PARM_DESC(csi_base_addr, "LPT address the circuit is connected to");

//function prototypes
static irqreturn_t irq_handler_csi(int irq, void *dev_id, struct pt_regs *regs);
static void __csi_cleanup(void);
static void dtmf_timeout_timer(unsigned long ptr);
static int __csi_init_module(void);
module_init(__csi_init_module);
module_exit(__csi_cleanup);
int own_atoi(char[]);
struct timer_list dtmf_timer;


// Globals
static struct proc_dir_entry *Our_Proc_File;
static int  csi_irq = 0;  	 //set later
static int  csi_base_addr = LPT_DEFAULT;
static const char *chars = DTMF_CHARS;
static char csi_num_buff[BUF_LEN];
static char *pbuf;
static int pid_of_client;
static struct task_struct *p_user_task;
static int enable_dtmf_timeout =0;
static int have_BOT=0;
char csi_version[]=CSI_VERSION;

