#include <stdio.h>
#include <asm/io.h>
#include <unistd.h>

#define INTERRUPT 0x40  // StD, the interrupt pin, def pin 10
#define POWERPINS 0x03	// these pins will power the circuit, def D0, D1, D2
#define PORTBASE 0x378  // LPT1
#define DTMF_CHARS "D1234567890*#ABC"

/*
	StD, 10, ACK	 	6 	0x40  INTERRUPT
         q4, 11, BUSY	 	7, 	0x80
         q3, 15, ERROR	 	3, 	0x08
         q2, 12, PAPER_END	5, 	0x20
         q1, 13, SELECT_IN	4, 	0x10

*/
int main() {
	int port_base = PORTBASE;
	char* buf;
	const char *chars = DTMF_CHARS;
	int data, raw_data;

	// open the parallellport
	if (ioperm(port_base,2,1)) printf("Error opening io-port\n"); 

	// reset and power circuit
	outb(0x00,port_base);usleep(500000);outb(POWERPINS,port_base);

	printf("Waiting...\n");

	while (1) {
		// Wait for interrupt
		if ((inb(port_base+1)) & (INTERRUPT)) {
			
			// Read parallellport
			raw_data=inb(port_base+1);
			
			// Convert to our dataformat, see DTMF_CHARS
			data =  (((raw_data & 0x80) == 0?1:0) * 8) +
	      		        (((raw_data & 0x08) == 0?0:1) * 4) +
      			        (((raw_data & 0x20) == 0?0:1) * 2) +
      			        (((raw_data & 0x10) == 0?0:1) * 1);

   			// Did we get a valid char...
			if(data >= 0x0 && data <= 0xF)

				// ...yes: store the char
     				*buf=chars[data];
   			else
				// ..no : return '?'
	      			*buf='?';
			
			// Print the char
     			printf("DATA : %c\n",*buf);

			// wait for INTERRUPT to go to low
     		   	while ((inb(port_base+1))&(INTERRUPT)) {}
		}
	}
}
	


	





