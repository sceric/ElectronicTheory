/* Change this if the SERVER_NAME environment variable does not report
	the true name of your web server. */
#define CGI_HITTA
#if 1
#define SERVER_NAME kongo
#endif
#if 0
#define SERVER_NAME "kongo"
#endif


#include <stdio.h>
#include "cgic.h"
#include <string.h>
#include <stdlib.h>

char nummer[20];
char *incomming_num;
char name[300];
char *callers_name;
void HandleSubmit();
void ShowForm();
int enirohitta();

int cgiMain() {
	cgiHeaderContentType("text/html");
	
	/* Top of the page */
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>Call information</TITLE></HEAD><BODY>\n");
	/* If a submit button has already been clicked, act on the submission of the form. */
	if (cgiFormSubmitClicked("submit") == cgiFormSuccess)
	{
		HandleSubmit();
		fprintf(cgiOut, "go</body></HTML>\n");

		return 0;
	} 

	/* Now show the form  if not submitted*/
	ShowForm();
	/* Finish up the page */
	fprintf(cgiOut, "</BODY></HTML>\n");
	return 0;
}

void HandleSubmit()

{
char skolon = 0x3b;
incomming_num = nummer;
callers_name = name;
char date[50];
	cgiFormStringNoNewlines("number",incomming_num,20);
	cgiFormStringNoNewlines("date",date,50);
	
	//cgiHtmlEscape(incomming_num);
int returnvalue =	enirohitta();

if (returnvalue==-3) callers_name="Ingen adress funnen.";	
if (returnvalue==-1) callers_name="Fel vid uppslagning i telefonkatalog.";	

	fprintf(cgiOut, "<SCRIPT LANGUAGE=\"JavaScript\">window.location=\"../cid/show_info.php?date=%s&incomming_num=%s&caller_name=%s\"%c</SCRIPT>",date,incomming_num,callers_name,skolon);
//</script>URL=\'../cid/show_info.php?date=%s&incomming_num=%s&caller_name=%s\'\">",date,incomming_num, callers_name);
	
}


void ShowForm()
{

	fprintf(cgiOut, "</head><body>Not submitted! Set variable number!");
}


