// Sendmail has to be installed!
<?php
$contents = 
'Du har f�tt ett samtal fr�n '.$alias.' den '.$date.'. F�lj l�nken f�r att se 
detaljer. http://INSERTSERVERHERE/cgi/info.cgi?date='.$date.'&submit=submit&number='.$number.
' Observera att l�nken bara fungerar hemmifr�n.';
$from ="Nummerpresentat�r@sjoholm <numpres@local>";
$subject = 'Inkommet samtal fr�n '.$alias;
$from_header = "From: $from";

$go =  $HTTP_REFERER.'&mail_sent=1';
  mail($to, $subject, $contents, $from_header);
 header("Location: $go");
?>
ERROR. Should have been directed back...

