<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("session.php");
$msg="Please fill the following fields completely:";
$tabform=true;
$tabend=false;
$tabend2=false;
$red="#ff0000";
$black="#000000";
$fontc=$black;
$chmodmsg_error="config.php is not writeable , set config.php to chmod 666 ";
$log="<a href='admin/log_in.php'>login</a>";

$filename="config.php";
if($setup){

if(empty($namedb)){
$msg="Error:DB Name is missing.";
$fontc=$red;
}

if(empty($hostdb)){
$msg=" Error:DB Host is missing.";
$fontc=$red;
}

if(empty($userdb)){
$msg="Error: DB user is missing.";
$fontc=$red;
}

if(empty($passdb)){
$msg="Error: DB password is missing.";
$fontc=$red;
}

if(empty($namesite)){
$msg="Error: Site Name is missing.";
$fontc=$red;
}

if(empty($sitepath)){
$msg="Error: The Path is missing.";
$fontc=$red;
}

if(empty($nameuser)){
$msg="Error: Admin name is missing.";
$fontc=$red;
}
if(empty($passwd)){
$msg="Error: Admin password is missing.";
$fontc=$red;
}

if(empty($aemail)){
$msg="Error: Admin Email s missing.";
$fontc=$red;
}
else if(($userdb) AND ($namedb) AND ($passdb) AND($hostdb) AND($sitepath) AND($namesite) AND($passwd) AND($aemail) AND($nameuser)){
$t_user="\$dbuser = \"$userdb\";";
 $t_name= "\$dbname = \"$namedb\";";
   $t_pass="\$dbpass = \"$passdb\";";
     $t_host="\$dbhost = \"$hostdb\";"; 
       $s_host="\$host = \"$sitepath\";";
         $a_site="\$mysite = \"$namesite\";";
          $a_email="\$adminmail = \"$aemail\";";
    $a_name=$nameuser;
	$a_pass=$passwd;
    $begin="<?php";
    $end="?>";

if(!(is_writeable($filename))){

$msg=$chmodmsg_error;
$fontc=$red;
}else{
$datei=fopen($filename,"w");
 }
}
if($datei){
$save=fputs($datei,"$begin\n$t_user\n$t_name\n$t_pass\n$t_host\n$s_host\n$a_site\n$a_email\n$end\n");
}

if($save){
fclose($datei);
$tabform=false;
$tabend=true;
$SuccMsg=" the variables were saved to the File config.php , now click". " Create tables "."to install the tables";
  }
}



if($create){
include("connect.php");
$create_table_admin="CREATE TABLE ecardswa_admin("
  ."adminid int(32) NOT NULL auto_increment,"
  ."adminname varchar(40) NOT NULL,"
  ."adminpass varchar(20) NOT NULL,"
  ."PRIMARY KEY  (adminid))";

$admin_result=mysql_query($create_table_admin);

$create_table_usr="CREATE TABLE ecardswa_user("
  ."userid int(32) NOT NULL auto_increment,"
  ."username varchar(20) NOT NULL,"
  ."passwd varchar(20) NOT NULL ,"
  ."uemail varchar(150) NOT NULL,"
  ."fcode varchar(60) NOT NULL,"
  ."ustatus int(6) default NULL,"
  ."adddate date NOT NULL,"
  ."PRIMARY KEY  (userid))";

$usr_result=mysql_query($create_table_usr);

$create_table_postcard="CREATE TABLE ecardswa_post("
  ."postid int(32) NOT NULL auto_increment,"
  ."postcode int(32) NOT NULL,"
  ."userid int(32) NOT NULL,"
  ."cardid  int(32) NOT NULL,"
  ."posttitle varchar(80) NOT NULL,"
  ."toname varchar(40) NOT NULL,"
  ."toemail varchar(150) NOT NULL,"
  ."postmsg text,"
  ."postdate date NOT NULL,"
  ."stampname varchar(50),"
  ."cardbg varchar(20),"
  ."fontcolor varchar(40),"
  ."fontface varchar(40),"
  ."pstatus int(10) NOT NULL,"
  ."PRIMARY KEY (postid))";

$postcard_result=mysql_query($create_table_postcard);

$create_table_card="CREATE TABLE ecardswa_card("
  ."cardid int(32) NOT NULL auto_increment,"
  ."catid  int(32) NOT NULL,"
  ."cardname varchar(60) NOT NULL,"
  ."PRIMARY KEY  (cardid))";
  
$card_result=mysql_query($create_table_card);

$create_table_cardscat="CREATE TABLE ecardswa_cat("
  ."catid int(32) NOT NULL auto_increment,"
  ."catname varchar(60) NOT NULL,"
  ."cattitle varchar(150) NOT NULL,"
  ."PRIMARY KEY  (catid))";

$cardscat_result=mysql_query($create_table_cardscat);

$create_table_fav="CREATE TABLE ecardswa_fav("
  ."userid int(32) NOT NULL,"
  ."cardid int(32) NOT NULL )";
$fav_result=mysql_query($create_table_fav);

$create_table_rate="CREATE TABLE ecardswa_rate("
  ."cardid int(32) NOT NULL,"
  ."cardip varchar(150) NOT NULL,"
  ."cardpoints int(32) NOT NULL,"
  ."ratedate  date NOT NULL)";
$rate_result=mysql_query($create_table_rate);


if( ($admin_result) && ($usr_result) && ($postcard_result) && ($card_result) && ($cardscat_result) && ($rate_result) && ($fav_result)){
   $sql_admin=mysql_query("INSERT INTO ecardswa_admin(adminname,adminpass) VALUES('$name_admin', password('$passwd_admin'))");
      
$tabform=false;
$tabend2=true;
$SuccMsg=" Congratulation ecardswa_v1.5 has been installd on Your Server successfuly\nNow you can"."$log"." into Admin-area.";
  }
 else
 {
 $tabform=false;
 $tabend=false;
 $tabend2=true;
 $SuccMsg="Error :: The commando could not be sent to the database server. Please connect the developer.";
  }
}


?>
<html>
<head>
<title>Ecardswa_v1.5 installation </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil1 {color: #FF0000}
.Stil2 {font-size: x-small}
.Stil6 {font-size: xx-small}
-->
</style>
</head>

<body>
<table width="500" cellspacing="5" cellpadding="0" align="center">
  <tr>
    <th width="600" height="90" align="center" valign="top"  scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th scope="col">
	<?php if($tabform){ ?>
	<table width="500" border="1" cellpadding="0" cellspacing="0" bordercolor="#0072BC">
      <tr>
        <th scope="col">
		<form action="<?php echo"$PHP_SELF"; ?>" method="post"> <table width="500">
          <tr bgcolor="#0072BC">
            <th colspan="2" scope="col"><font color="<?php echo"$fontc" ?>"><?php echo"$msg"; ?></font></th>
          </tr>
          <tr bgcolor="#0072BC">
            <th colspan="2" scope="col"><span class="Stil2">Data Base setting </span></th>
          </tr>
          <tr>
            <td width="150" align="right" valign="top"><strong><span class="Stil2"><span class="Stil6">DB Name</span><span class="Stil1">*</span></span> : </strong></td>
            <td width="350" align="left" valign="top"><input name="namedb" type="text" size="32" value="<?php echo"$namedb";?>" ></td>
          </tr>
          <tr>
            <td width="150" align="right" valign="top"><strong><span class="Stil6">DB Host</span><span class="Stil1">*</span>:</strong></td>
            <td width="350" align="left" valign="top"><input name="hostdb" type="text" value="localhost" size="32"></td>
          </tr>
          <tr>
            <td width="150" align="right" valign="top"><strong><span class="Stil6">DB User</span><span class="Stil1">*</span> :</strong></td>
            <td width="350" align="left" valign="top"><input name="userdb" type="text" size="32" value="<?php echo"$userdb";?>"></td>
          </tr>
          <tr>
            <td width="150" align="right" valign="top"><strong><span class="Stil6">DB Password</span><span class="Stil1">*</span> :</strong></td>
            <td width="350" align="left" valign="top"><input name="passdb" type="text" size="32" value="<?php echo"$passdb";?>" ></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr align="center" bgcolor="#0072BC">
            <td colspan="2"><span class="Stil2"><strong> Site setting </strong></span></td>
          </tr>
          <tr>
            <td width="150" align="right" valign="top"><strong><span class="Stil2"><span class="Stil6">Site Name</span><span class="Stil1">*</span></span> :</strong></td>
            <td width="350" align="left" valign="top"><input name="namesite" type="text" value="mysite.com" size="32"></td>
          </tr>
          <tr>
            <td width="150" align="right" valign="top"><strong><span class="Stil6">Path to ecardswa_v1.5</span><span class="Stil1">*</span> :</strong></td>
            <td width="350" align="left" valign="top"><input name="sitepath" type="text" value="http://www.mysite.com/ecardswa_v1.5" size="32">            </td>
          </tr>
          <tr>
            <td colspan="2"></td>
          </tr>
          <tr align="center" bgcolor="#0072BC">
            <td colspan="2"><span class="Stil2"><strong>Admin setting </strong></span></td>
          </tr>
          <tr>
            <td width="150" align="right" valign="top"><strong><span class="Stil6">Userame</span><span class="Stil1">*</span> :</strong></td>
            <td width="350" align="left" valign="top"><input name="nameuser" type="text" size="32" value="<?php echo"$nameuser"?>"></td>
          </tr>
          <tr>
            <td width="150" align="right" valign="top"><span class="Stil6"><strong>Password</strong></span><strong><span class="Stil1">*</span></strong>:</td>
            <td width="350" align="left" valign="top"><input name="passwd" type="text" size="32" value="<?php echo"$passwd"?>"></td>
          </tr>
          <tr>
            <td width="150" align="right" valign="top"><strong><span class="Stil6">Email</span><span class="Stil1">*</span>:</strong></td>
            <td width="350" align="left" valign="top"><input name="aemail" type="text" value="admin@maysite.com" size="32"></td>
          </tr>
          <tr align="center">
            <td colspan="2"><input name="setup" type="submit" value="install">
            </td>
          </tr>
        </table>
		</form>
		</th>
      </tr>
    </table>   
  <?php } ?></th>
  </tr>
  <tr>
    <th scope="col">
	<?php if($tabend){ ?>
	<table width="500" border="1" cellpadding="0" cellspacing="0" bordercolor="#0072BC">
      <tr>
        <th scope="col">
		<form action="<?php echo"$PHP_SELF"; ?>" method="post">
		<input name="passwd_admin" type="hidden" value="<?php  echo"$a_pass "; ?>">
		<input name="name_admin" type="hidden" value="<?php  echo"$a_name"; ?>">
		<table width="500">
          <tr>
            <th align="center" scope="col"><?php echo"$SuccMsg"; ?></th>
          </tr>
           <tr>
            <td align="center"><input name="create"  type="submit" value="Create Tables">
              </td>
          </tr>
		   </table>
		</form></th>
      </tr>
    </table>
	 <?php } ?>
	</th>
  </tr>
  <tr>
    <th scope="col">
      <?php if($tabend2){ ?>	
      <table width="500" border="1" cellpadding="0" cellspacing="0" bordercolor="#0072BC">
      <tr>
        <th scope="col"> <?php echo"$SuccMsg"; ?></th>
      </tr>
    </table>
	<?php } ?>
	</th>
  </tr>
</table>
</body>
</html>
