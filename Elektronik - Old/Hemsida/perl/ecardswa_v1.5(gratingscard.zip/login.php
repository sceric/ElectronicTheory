<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
session_start();

if (!isset ($_SESSION["ecardswa_userid"]))

{ 

header ("Location:log_in.php?login=missing");
}

include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass) or die("Error:: can't connect to database");
@mysql_select_db( "$dbname") or die( " Error:: there is no database like $dbname");


if($log){

$sqllog=mysql_query(" SELECT  * FROM  ecardswa_user WHERE  username='$loginname' AND   passwd=password('$pass') AND  ustatus='1'  ");

if($sqllog){
$row=mysql_fetch_array($sqllog);
} 
$num=mysql_num_rows($sqllog);
 
if($num == 1){

$_SESSION["ecardswa_userid"]=$row["userid"];
 header ("Location: index.php");
 }
 else
 {
  header ("Location: log_in.php?login=wrong");
 }
 
 }
?>
