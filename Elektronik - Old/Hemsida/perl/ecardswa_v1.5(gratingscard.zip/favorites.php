<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("ecardswa.php");
$ceil=3;
$tabcard=true;
$tabdelete=false;

if($delete){
$tabcard=false;
$tabdelete=true;
$msg2=false;
$msg=false;
$msg3=$Fav_Delete_EC;
}

if($delcard){
$sel_delete=mysql_query("delete from ecardswa_fav where cardid='$id_card' ");
$msg2=$Fav_Delete_ECsucc;
}




if($id){
$sqlcheck_card=mysql_query("select * from ecardswa_fav where userid='$ecardswa_userid' and cardid='$id'");
if(!empty($sqlcheck_card)){
$numcard=mysql_num_rows($sqlcheck_card);
}


if($numcard==1){
$msg2=$Fav_Add_EC_Exist;
}else if ($numcard==0){
$sql_add=mysql_query("INSERT INTO `ecardswa_fav` ( `userid` , `cardid` ) VALUES ('$ecardswa_userid', '$id')");
$msg2=$Fav_Add_EC;
}

}

$sqlfav=mysql_query("select * from ecardswa_fav where userid='$ecardswa_userid'");

if(!empty($sqlfav)){
$numfav=mysql_num_rows($sqlfav);
}

if($numfav >= 1 ){
$msg=$Fav_MSG;
}else if($numfav ==0 ){
$msg=$Fav_Empty_MSG;
}




?>

<html>
<head>
<title>Ecardswa v1.5</title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="500" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="150" align="left" valign="top" scope="col"><table width="149" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th align="center" scope="col"> <?php include("tablogin.php") ?></th>
          </tr>
          <tr>
            <td align="center"><?php include("tabcat.php") ?></td>
          </tr>
        </table></th>
        <th width="550" align="center" valign="top" scope="col"><table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="500" align="center"><?php echo"$msg2"; ?></td>
          </tr>
          <tr>
            <td width="500" align="center"><?php echo"$msg"; ?></td>
          </tr>
          <tr>
            <td width="500" align="center"><table width="500" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="center"><?php if($tabcard){ ?>
                      <table width="100" border="0" align="center" cellpadding="0" cellspacing="10" >
                        <?php 
	                         if ($numfav >= 1){ 
						     $sql_out=mysql_query("select * from ecardswa_fav cf,  ecardswa_user u,  ecardswa_card c  where u.userid='$ecardswa_userid' AND  u.userid=cf.userid  AND cf.cardid=c.cardid ");
	                         $i = 1;
							 echo"<tr>";
	                         if(!empty($sql_out)){
	                         while($rowecard=mysql_fetch_array($sql_out)){
	                         $card_id=$rowecard["cardid"];
	                         $card_name=$rowecard["cardname"];	 
	                         $card="<a href='card.php?cardid=$card_id'><img src='$ecardsdir$card_name' width='90' height='100'border='0'></a>";
							 $del="<a href='$PHP_SELF?delete=$card_id'>$Fav_Delete</a>";
							 ?>
              <th align="center" valign="top" scope="col"><p><?php echo "$card<br>$del";?></p></th>
                  <?php if (is_int($i / $ceil))
	                         echo  "</tr>";
							 $i++;
                                }
							  }
							 }
							 ?>
                      </table>
                      <?php } 
						   ?></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td width="500" align="center"><?php if($tabdelete){ ?>
                <table  width="400" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" >
                  <tr>
                    <th width="400" align="center" valign="middle" bgcolor="#FFCC99" scope="col"> <div align="center"><font color="<?php echo"$fontc";?>"><?php echo"$msg3"; ?></font></div></th>
                  </tr>
                  <tr>
                    <th width="400" align="center" valign="top" scope="col"><table width="200">
                        <tr>
                          <td width="100" align="center"><form action="<?php echo"$PHP_SELF";?>" method="post">
                              <input name="id_card" type="hidden" value="<?php echo"$delete";?>">
                              <table width="50">
                                <tr>
                                  <td><input name="delcard" type="submit" value="<?php echo"$yes";?>"></td>
                                </tr>
                              </table>
                          </form></td>
                          <td width="100" align="center"><form action="<?php echo"$PHP_SELF";?>" method="post">
                              <table width="50">
                                <tr>
                                  <td><input name="no" type="submit" value="<?php echo"$no";?>"></td>
                                </tr>
                              </table>
                          </form></td>
                        </tr>
                    </table></th>
                  </tr>
                </table>
                <?php }  ?></td>
          </tr>
        </table>        
      </table>          
    </th>    
  </tr>
      <tr>
        <td colspan="2" align="center" valign="bottom"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
