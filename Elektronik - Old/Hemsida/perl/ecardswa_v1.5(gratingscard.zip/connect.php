<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass) or die("Error:: can't connect to database");
@mysql_select_db( "$dbname") or die( "there is no database like $dbname");
?>