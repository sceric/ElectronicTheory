<table width="700" height="145" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="left" valign="top" scope="col"><table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="145" height="130" align="center" valign="top" background="imgs/head_bc1.jpg"><table width="135" border="0" cellpadding="0">
          <tr>
            <td align="center"><?php echo "$Welcome";?></td>
          </tr>
          <tr>
            <td align="center"><a href="<?php echo "$host";?>"><?php echo "$mysite";?></a></td>
          </tr>
        </table></td>
        <td width="145" background="imgs/head_bc2.jpg">&nbsp;</td>
        <td width="145" background="imgs/head_bc3.jpg">&nbsp;</td>
        <td width="145" background="imgs/head_bc4.jpg">&nbsp;</td>
        <td width="121" background="imgs/head_bc5.jpg">&nbsp;</td>
      </tr>
      <tr bgcolor="#AFFF00">
        <td width="700" height="18" colspan="5"><table width="700" height="18" cellpadding="0" cellspacing="0">
          <tr align="center" valign="middle">
            <th width="116" height="18" scope="col"><table width="100" height="18">
                <tr>
                  <td width="100" height="18" align="center" valign="middle" background="imgs/button_hc.gif"><strong><a href="index.php" target="_self"><?php echo"$Home_Button";?></a></strong></td>
                </tr>
            </table></th>
            <th width="116" height="18" background="if" scope="col"><table width="100" height="18">
                <tr>
                  <td width="100" height="18" align="center" valign="middle" background="imgs/button_hc.gif"><strong><a href="account.php" target="_self"><?php echo"$Account_Button";?></a></strong></td>
                </tr>
            </table></th>
            <th width="116" height="18" scope="col"><table width="100" height="18">
                <tr>
                  <td width="100" height="18" align="center" valign="middle" background="imgs/button_hc.gif"><strong><a href="history.php" target="_self"><?php echo"$History_Button";?></strong></a></td>
                </tr>
            </table></th>
            <th width="116" height="18" scope="col"><table width="100" height="18">
                <tr>
                  <td width="100" height="18" align="center" valign="middle" background="imgs/button_hc.gif"><strong><a href="favorites.php" target="_self"><?php echo"$Favorites_Button";?></strong></a></td>
                </tr>
            </table></th>
            <th width="116" height="18" scope="col"><table width="100" height="18">
                <tr>
                  <td width="100" height="18" align="center" valign="middle" background="imgs/button_hc.gif"><strong><a href="topecards.php" target="_self"><?php echo"$Top_EC_Button";?></strong></a></td>
                </tr>
            </table></th>
            <th width="116" height="18" scope="col"><table width="100" height="18">
                <tr>
                  <td width="100" height="18" align="center" valign="middle" background="imgs/button_hc.gif"><strong><a href="newecards.php" target="_self"><?php echo"$New_EC_Button";?></strong></a></td>
                </tr>
            </table></th>
          </tr>
        </table></td>
      </tr>
    </table></th>
  </tr>
</table>

