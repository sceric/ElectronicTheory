<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("ecardswa.php");
include("connect.php");
include("session.php");
$tabsubmit=true;
$oktab=false;
$msg=$New_Register;
$Errorc="#FF0000";

function new_code() 
{ 
$id = (integer) md5(microtime()); 
mt_srand($id); 
$code = mt_rand(1,99999999); 
$code = substr(md5($code ), mt_rand(0, 15), mt_rand(5, 9)); 
return $code; 
} 


$checkname=(strlen($nameu));
$invalidname2=($checkname < 6);


if($sub){


$sqlcheckemail=mysql_query("select  uemail from ecardswa_user where  uemail='$emailu'");
if(!empty($sqlcheckemail)){
$numemail=mysql_num_rows($sqlcheckemail);
}

$sqlcheckuser=mysql_query("select  username from ecardswa_user where  username='$nameu'");
if(!empty($sqlcheckuser)){
$numname=mysql_num_rows($sqlcheckuser);
}


if(empty($nameu)){
$msg=$Reg_Name_Error;
$fontc=$Errorc;

}


if(empty($passwdu)){
$msg=$Reg_Pass_Error;
$fontc=$Errorc;
}

if(empty($passwda)){
$msg=$Reg_Pass_Error;
$fontc=$Errorc;
}

if(empty($emailu)){
$msg=$Reg_Email_Error;
$fontc=$Errorc;
}

if($invalidname2){
$msg=$Reg_Smalname_Error;
$fontc=$Errorc;
}

if($numname==1){
$msg=$Reg_Name_Exists;
$fontc=$Errorc;
} 

if($numemail==1){
$msg=$Reg_Email_Exists;
$fontc=$Errorc;
} 
if($passwdu!=$passwda){
$msg=$Reg_Pass_Repeat_Error;
$fontc=$Errorc;
}

if(preg_match("/ /",$nameu)){
$msg=$Reg_Blank_Error;
$fontc=$Errorc;
}

if(!preg_match("/@/",$emailu)){
$msg=$Reg_Email_Error;
$fontc=$Errorc;
}

else if(($nameu) && ($passwdu=$passwda) && ($emailu) && ($numname ==0) && ($numemail==0) && (preg_match("/@/",$emailu) && (!$invalidname2)) ){
$id_code= new_code();
$sqlsub=mysql_query("insert into ecardswa_user(username,passwd,uemail,fcode,adddate,ustatus) values('$nameu',password('$passwdu'),'$emailu','$id_code', NOW(),'$statusu')");
$id_user=mysql_insert_id();
$msg=$Reg_Succ_MSG;
$tabsubmit=false;
$oktab=true;
$link="$host/getaccount.php?id=$id_user&email=$emailu";
$mailmsg="$hello $nameu,\n$Reg_Mail_MSG\n$Reg_Code $id_code\n$link\n\n$Reg_Your_Access_Data:\n$Reg_Name $nameu\n$Reg_Pass $passwdu\n$Reg_Email $emailu\n\n\n$Reg_Signatur_MSG\n$host";
$send_mail= mail ($emailu,$Reg_Mail_supject,$mailmsg, "From: $adminmail");
  }
}
?>
<html>
<head>
<title><?php echo"$new_reg"; ?></title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil2 {
	font-size: 12px;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="3" cellpadding="0">
      <tr>
        <th width="150" align="left" valign="top" scope="col"><table width="149" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <th align="center" scope="col"> <?php include("tablogin.php") ?></th>
            </tr>
            <tr>
              <td align="center"><?php include("tabcat.php") ?></td>
            </tr>
        </table></th>
        <th width="550" height="400" rowspan="2" align="center" valign="top" scope="col"><table width="400" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
          <tr>
            <th bgcolor="#FFCC99" scope="col"><font color="<?php print "$fontc" ?>"><?php print "$msg" ?></font></th>
          </tr>
          <tr>
            <th scope="col"><table width="400">
                <?php if($tabsubmit){ ?>
                <tr>
                  <td><table width="405" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <th scope="col">
						  <form action="<?php print "$PHP_SELF" ?>" method="post">
                            <input name="statusu" type="hidden" value="0">
                            <table width="400">
                              <tr>
                                <td width="150"><?php print"$Reg_Name"; ?></td>
                                <td width="250"  colspan="2" align="left" valign="top" ><input name="nameu" type="text" value="<?php print"$nameu" ?>" maxlength="19"></td>
                              </tr>
                              <tr>
                                <td width="150"><?php print"$Reg_Pass"; ?></td>
                                <td width="250" colspan="2" align="left" valign="top" ><input name="passwdu" type="password" value="<?php print"$passwdu" ?>" maxlength="19" ></td>
                              </tr>
                              <tr >
                                <td width="150"><?php print"$Reg_Pass_Repeat"; ?></td>
                                <td width="250" colspan="2" align="left" valign="top" ><input name="passwda" type="password" value="<?php print"$passwda" ?>" maxlength="19" ></td>
                              </tr>
                              <tr >
                                <td width="150"><?php print"$Reg_Email"; ?></td>
                                <td width="250" colspan="2" align="left" valign="top"><input name="emailu" type="text" value="<?php print"$emailu" ?>" ></td>
                              </tr>
                              <tr >
                                <td width="150">&nbsp;</td>
                                <td width="250" colspan="2" align="left" valign="top"><input name="sub" type="submit" value="<?php print"$Reg_Register_Submit";?>"></td>
                              </tr>
                            </table>
                        </form></th>
                      </tr>
                  </table></td>
                </tr>
                <tr>
                  <td width="400" height="20"><?php print "$Reg_MSG"; ?></td>
                </tr>
                <tr>
                  <td><?php }  if($oktab){ ?>
                      <table width="400">
                        <tr>
                          <th scope="col"><?php print "$Reg_Thanks_MSG"; ?></th>
                        </tr>
                      </table>
                      <?php } ?></td>
                </tr>
            </table></th>
          </tr>
        </table>        
      <tr>
        <th align="left" valign="top" scope="col"><p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p></th>
    </table>  
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </tr>
      <tr>
        <td colspan="2" align="center"><?php include("foot.php");?></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
