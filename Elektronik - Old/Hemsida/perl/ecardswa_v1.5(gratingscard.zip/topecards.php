<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

include("ecardswa.php");
include("connect.php");
include("session.php");
$ceil=3;



?>

<html>
<head>
<title>Ecardswa_v1.5 </title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="500" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="150" align="left" valign="top" scope="col"><table width="149" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th align="center" scope="col"> <?php include("tablogin.php") ?></th>
          </tr>
          <tr>
            <td align="center"><?php include("tabcat.php") ?></td>
          </tr>
        </table></th>
        <th width="550" align="center" valign="top" scope="col"><table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th width="500" scope="col"><p>&nbsp;</p>
              <?php echo"$Top_EC_MSG"; ?></th>
          </tr>
          <tr>
            <td width="500" align="center"><table width="100" border="0" align="center" cellpadding="0" cellspacing="10">
             <?php 
	           $sqltop=mysql_query("SELECT   c.cardid, c.cardname, sum( cr.cardpoints ) AS sum 
	           FROM ecardswa_card c, ecardswa_rate cr
               WHERE c.cardid = cr.cardid
               GROUP  BY c.cardid
               ORDER  BY sum DESC  LIMIT 0 , $maxtop ");
	           $i = 1;
               echo"<tr>";
	        
	          if(!empty($sqltop)){
	          while($row=mysql_fetch_array($sqltop)){
	          $card_name=$row["cardname"];
		      $card_id=$row["cardid"];
			  ?>
              <th align="center" valign="top" scope="col"><a href="<?php echo"card.php?cardid=$card_id";?>"><img src="<?php echo"$ecardsdir$card_name";?>" width="90" height="100" border="0"></a></th>
              <?php if (is_int($i / $ceil))
	          echo  "</tr>";
              $i++;
               }
              } 
              ?>
              </table>
			 </td>
          </tr>
        </table>        
      
        </table>          
    <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p></th>    
  </tr>
      <tr>
        <td colspan="2" align="center" valign="bottom"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
