<?php // The copyright of the author must not in any case changed or removed // ?> 
<table width="400" align="center">
  <tr>
    <td align="center"><font size="2">Ecardswa v1.5 Powered by <a href="http://www.demof.com">demof.com</a> | <a href="http://www.ecards.it">ecards.it</a></font> </td>
  </tr>
</table>

