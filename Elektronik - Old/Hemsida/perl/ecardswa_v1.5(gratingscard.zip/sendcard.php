<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("ecardswa.php");

$tabsend=false;
$tabempty=true;
$msg=$Send_EC_MSGEmpty;

session_start();
if($cardid){
$msg=$Send_EC_MSG;
$tabsend=true;
$sqlcard=mysql_query("SELECT *FROM  ecardswa_card WHERE cardid = '$cardid'");
if(!empty($sqlcard)){
$rowcard=mysql_fetch_array($sqlcard);
$card_id=$rowcard["cardid"];
$card_name=$rowcard["cardname"];
   }
}
else
{
$msg=$Send_EC_MSGEmpty;
$tabsend=false;
}



$sqlusr=mysql_query("select * from ecardswa_user where userid='$ecardswa_userid'");
if(!empty($sqlusr)){
$usrrow=mysql_fetch_array($sqlusr);
$sendername=$usrrow["username"];
$senderemail=$usrrow["uemail"];
}



?>

<html>
<head>
<title>Ecardswa v1.5 </title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
<bgsound src="<?php echo"$music_file";?>" loop="-1">
</head>

<body>

<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="747" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="150" align="left" valign="top" scope="col"><table width="149" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th align="center" scope="col"> <?php include("tablogin.php") ?></th>
          </tr>
          <tr>
            <td align="center"><?php include("tabcat.php") ?></td>
          </tr>
        </table></th>
        <th width="550" align="center" valign="top" scope="col"><p>&nbsp;</p>
        <table width="530" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
          <tr>
            <td width="540">
			<?php if($tabsend){ ?>
			<form name="post" action="previewcard.php" method="post">
			<table width="530" border="0" align="center" cellpadding="0" cellspacing="0">
     	 <tr>
	     <th align="left" valign="top" scope="col">
		
		  <input name="cardid" type="hidden" value="<?php echo"$cardid" ?>">
		 <input name="card_name" type="hidden" value="<?php echo"$card_name" ?>">
		 <table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <th scope="col"><p>&nbsp;</p>
              <p><img src="<?php echo"$ecardsdir$card_name" ?>"></p></th>
          </tr>
          <tr>
            <td><table width="505" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <th width="500" align="center" scope="col"><?php echo"$msg";?></th>
              </tr>
              <tr>
                <td align="center"><table width="500" border="0" align="center" cellpadding="0" cellspacing="2">
                    <tr align="left" valign="top">
                      <td width="147" scope="col"><?php echo"$Send_To_Name";?></td>
                      <th colspan="2" scope="col"><input name="toname" type="text" size="18"></th>
                    </tr>
                    <tr align="left" valign="top">
                      <td width="147" scope="col"><?php echo"$Send_To_Mail";?></td>
                      <th colspan="2" scope="col"><input name="toemail" type="text"value=" " size="18"></th>
                    </tr>
                    <tr align="left" valign="top">
                      <td width="147"><?php echo"$Send_Sender_Name";?></td>
                      <td colspan="2"><input name="sendername" type="text"value="<?php echo"$sendername"; ?>" size="18"></td>
                    </tr>
                    <tr align="left" valign="top">
                      <td width="147"><?php echo"$Send_Sender_Mail";?></td>
                      <td colspan="2"><input name="senderemail" type="text"value="<?php echo"$senderemail"; ?>" size="18"></td>
                    </tr>
                    <tr align="left" valign="top">
                      <td><?php echo "$Send_EC_Subject" ?></td>
                      <td colspan="2"><input name="postsubject"  type="text" value="<?php echo"$postsubject"?>"  size="38" maxlength="80"></td>
                    </tr>
                    <tr align="left" valign="top">
                      <td>&nbsp;</td>
                      <td colspan="2"><?php include("smileys.php") ; ?></td>
                    </tr>
                    <tr align="left" valign="top">
                      <td><?php echo"$Send_EC_MSGtext";?></td>
                      <td colspan="2"><textarea name="postmsg" cols="45" rows="10"></textarea></td>
                    </tr>
                    <tr align="left" valign="top">
                      <td><?php echo"$Send_EC_FontFace";?></td>
                      <td colspan="2"><select name="fontface">
                       <?php include("font.php") ?> 
                      </select></td>
                    </tr>
                    <tr align="left" valign="top">
                      <td><?php echo"$Send_EC_FontColor";?></td>
                      <td colspan="2"><select name="fontcolor">
                      <?php include("color.php") ?>
                      </select></td>
                    </tr>
                    <tr align="left" valign="top">
                      <td><?php echo"$Send_EC_BackgroundColor";?></td>
                      <td colspan="2"><select name="hccolor">
                      <?php include("color.php") ?>
                      </select></td>
                    </tr>
                    <tr align="left" valign="top">
                     
                </table></td>
              </tr>
              <tr>
                <td><?php echo"$Send_EC_Stamp";?></td>
              </tr>
              <tr>
                <td><table width="500" border="0" cellspacing="2" cellpadding="0">
                    <tr align="center" valign="bottom" class="2">
                      <th width="165" scope="col"><img src="imgs/stamp1.gif" width="70" height="60"> </th>
                      <th width="165" scope="col"><img src="imgs/stamp2.gif" width="70" height="60"> </th>
                      <th width="165" scope="col"><img src="imgs/stamp3.gif" width="70" height="60"> </th>
                    </tr>
                    <tr align="center">
                      <td width="165"><input name="stamp" type="radio"   id="tb" style=" background-color : #ffffff; border-width : 0;" onmouseover="this.style.backgroundColor='#eeeeee'"onmouseout="this.style.backgroundColor='#ffffff'" value="stamp1.gif" checked >
                      </td>
                      <td width="165"><input name="stamp" type="radio" value="stamp2.gif" style=" background-color : #ffffff; border-width : 0;"onmouseover="this.style.backgroundColor='#eeeeee'"onmouseout="this.style.backgroundColor='#ffffff'"   id="tb" ></td>
                      <td width="165"><input name="stamp" type="radio" value="stamp3.gif" style=" background-color : #ffffff; border-width : 0;" onmouseover="this.style.backgroundColor='#eeeeee'"onmouseout="this.style.backgroundColor='#ffffff'"   id="tb" ></td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td align="center"><input name="show" type="submit" value="<?php echo"$Send_EC_Show"; ?>"></td>
              </tr>
            </table></td>
          </tr>
        </table> 
		</th>
          
	  
</tr>

            </table>
			</form>
			<?php } ?></td>
          </tr>
        </table>        
      
        </table>          
    <p></p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          </th>    
  </tr>
      <tr>
        <td colspan="2" align="center"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
