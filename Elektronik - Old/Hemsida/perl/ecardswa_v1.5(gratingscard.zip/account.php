<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

include("login.php");
include("ecardswa.php");
$tabnew=true;
$tabthanks=false;
$Errorc="#FF0000";
$msg=$Acc_Update_log;

$sql_usr=mysql_query("select * from ecardswa_user where userid='$ecardswa_userid'");
if(!empty($sql_usr)){
$numuser=mysql_num_rows($sql_usr);
if($numuser==1){
$usr_row=mysql_fetch_array($sql_usr);
$u_name=$usr_row["username"];
$u_email=$usr_row["uemail"];
  }
}


if($sub){

           
if(empty($passwdu)){
$msg=$Reg_Pass_Error;
$fontc=$Errorc;
}
if(empty($passwda)){
$msg=$Reg_Pass_Error;
$fontc=$Errorc;

}
if(empty($emailu)){
$msg=$Reg_Email_Error;
$fontc=$Errorc;
}

else if($passwdu!=$passwda){
$msg=$Reg_Pass_Repeat_Error;
$fontc=$Errorc;
}
else if(($passwdu=$passwda) && ($emailu)){
$sqlsub=mysql_query("update ecardswa_user set passwd=password('$passwdu') , uemail='$emailu' where userid='$ecardswa_userid' ");
$tabnew=false;
$tabthanks=true;
  }
}


?>

<html>
<head>
<title>Ecardswa </title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="500" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" height="500" border="0" cellpadding="0" cellspacing="3">
      <tr>
        <th width="150" align="left" valign="top" scope="col"><table width="149" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th align="center" scope="col"> <?php include("tablogin.php") ?></th>
          </tr>
          <tr>
            <td align="center"><?php include("tabcat.php") ?></td>
          </tr>
        </table></th>
        <th width="550" align="center" valign="top" scope="col"><table  width="400" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
          <tr>
            <th width="400" align="center" valign="middle" bgcolor="#FFCC99" scope="col"> <div align="center"><font color="<?php print"$fontc";?>"><?php echo"$msg"; ?></font></div></th>
          </tr>
          <tr>
            <th height="125" align="center" valign="top" scope="col"><table width="400" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <th scope="col"> <?php if($tabnew){ ?>
                      <form action="<?php echo"$PHP_SELF"; ?>" method="post">
                        <table width="400">
                          <tr>
                            <td width="150"><?php echo"$Reg_Pass"; ?></td>
                            <td colspan="2" align="left" valign="top" ><input name="passwdu" type="password"></td>
                          </tr>
                          <tr >
                            <td width="150"><?php echo"$Reg_Pass_Repeat"; ?></td>
                            <td colspan="2" align="left" valign="top" ><input name="passwda" type="password">
                            </td>
                          </tr>
                          <tr >
                            <td width="150"><?php echo"$Reg_Email"; ?></td>
                            <td colspan="2" align="left" valign="top"><input name="emailu" type="text" value="<?php echo"$u_email"; ?>">
                            </td>
                          </tr>
                          <tr>
                            <td width="150">&nbsp;</td>
                            <td width="150" align="center"><input name="sub" type="submit" value="<?php echo"$Acc_Submit_Updatelog"; ?>"></td>
                            <td width="100" align="left">&nbsp;</td>
                          </tr>
                        </table>
                      </form>
                      <?php } ?></th>
                </tr>
                <tr>
                  <td><?php if($tabthanks){ ?>
                      <table width="400" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <th scope="col"><?php echo"$Acc_Updatelog_succ";  ?></th>
                        </tr>
                      </table>
                      <?php } ?></td>
                </tr>
            </table></th>
          </tr>
        </table>        
      </table>          
    <p>&nbsp;</p>
          <p>&nbsp;</p>
    <p>&nbsp;</p>
    </th>  </tr>
      <tr>
        <td colspan="2" align="center"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table></td>
  </tr>
</table>
</body>
</html>
