<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
?>

<style type="text/css">
<!--
.Stil2 {font-size: 12px;
	font-weight: bold;
}
-->
</style>
<table width="145" border="0" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" id="tb">
  <tr>
    <th width="400" height="21" scope="col"><?php echo "$Categories" ?> </th>
  </tr>
  <tr>
    <td width="145" align="center"><table width="140" border="0" align="left" cellpadding="0" cellspacing="5">
      <?php 
			  $sql_cats=mysql_query("select * from ecardswa_cat order by  catname ");
			  if(!empty($sql_cats)){
	          while($row=mysql_fetch_array($sql_cats)){
	          $category=$row["catname"];
	          $categoryid=$row["catid"];
		      $sql_card=mysql_query("select*from ecardswa_card where catid='$categoryid'");
		    
	              if (!empty($sql_card)){
	              $numcard=mysql_num_rows($sql_card);
	              $num="($numcard)";
	              }
			 
			  ?>
      <tr>
        <th align="left" valign="top" scope="col"><?php echo"<a href='ecards.php?catid=$categoryid' target='_self'>$category$num</a>" ;?></th>
      </tr>
      <?php
    }
   }
  ?>
    </table></td>
  </tr>
</table>
