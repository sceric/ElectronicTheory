<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("ecardswa.php");
$tabsend=true;
$tabshow=false;
$tabsent=false;
$error_fontc="#FFCC00";
$fcolor="#CCCCCC";

if($edit){
$postmsg=strip_tags($postmsg); 
$tabsend=true;
$tabshow=false;
}

if($show){
if(empty($postsubject)){
$msg=$Send_EC_Subject_Error;
$fcolor=$error_fontc;
}
if(empty($toname)){
$msg=$Send_To_Name_Error;
$fcolor=$error_fontc;
}
if(empty($toemail)){
$msg=$Send_To_Mail_Error;
$fcolor=$error_fontc;
}

if(empty($sendername)){
$msg=$Send_Sender_Name_Error;
$fcolor=$error_fontc;
}

if(empty($senderemail)){
$msg=$Send_Sender_Mail_Error;
$fcolor=$$error_fontc;
}
if(empty($postmsg)){
$msg=$Send_EC_MSGtext_Error;
$fcolor=$error_fontc;
}
else if (($postsubject)&&($toname)&& ($toemail) && ($sendername) && ($senderemail) && ($postmsg)){
$tabsend=false;
$tabshow=true;
 
                $postmsg = str_replace("s1:-)", "<img src='smileys/2.gif'>", $postmsg);
                $postmsg = str_replace("s2:-)", "<img src='smileys/2.gif'>", $postmsg);
                $postmsg = str_replace("s3:-)", "<img src='smileys/3.gif'>", $postmsg);
				$postmsg = str_replace("s4:-)", "<img src='smileys/4.gif'>", $postmsg);
				$postmsg = str_replace("s5:-)", "<img src='smileys/5.gif'>", $postmsg);
				$postmsg = str_replace("s6:-)", "<img src='smileys/6.gif'>", $postmsg);
				$postmsg = str_replace("s7:-)", "<img src='smileys/7.gif'>", $postmsg);
				$postmsg = str_replace("s8:-)", "<img src='smileys/8.gif'>", $postmsg);
				$postmsg = str_replace("s9:-)", "<img src='smileys/9.gif'>", $postmsg);
				$postmsg = str_replace("s10:-)", "<img src='smileys/10.gif'>", $postmsg);
				$postmsg = str_replace("s11:-)", "<img src='smileys/11.gif'>", $postmsg);
				$postmsg = str_replace("s12:-)", "<img src='smileys/12.gif'>", $postmsg);
				$postmsg = str_replace("s13:-)", "<img src='smileys/13.gif'>", $postmsg);
				$postmsg = str_replace("s14:-)", "<img src='smileys/14.gif'>", $postmsg);
				$postmsg = str_replace("s15:-)", "<img src='smileys/15.gif'>", $postmsg);
				$postmsg = nl2br($postmsg);
	  
     }   	
}


if($send){
$date=date("his");
$s=date("s");
$m=date("m");
$postcode=$date+3*$s;
$Sqlpost=mysql_query("INSERT INTO `ecardswa_post` ( `postid` , `postcode` , `userid` , `cardid` , `posttitle` , `toname` , `toemail` , `postmsg` , `postdate` , `stampname` , `cardbg` , `fontcolor` , `fontface` , `pstatus` )
VALUES ('', '$postcode', '$ecardswa_userid', '$cardid', '$postsubject', '$toname', '$toemail', '$postmsg',NOW(), '$stamp', '$hccolor', '$fontcolor', '$fontface', '0')");
$id=mysql_insert_id();
   $link="$host/view.php?id=$id&code=$postcode";
     $mailmsg="$hello $toname\n$Send_EC_MailMSG\n$link\n\n\n$Reg_Signatur_MSG\n$host\n";
       $send_mail= mail ($toemail,$Send_EC_MailSubjekt,$mailmsg, "From: $senderemail ");
         $tabsent=true;
          $tabsend=false;
           $tabshow=false;
}

?>

<html><head>
<title> Ecardswa v1.5  </title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil3 {font-size: 12px}
-->
</style>
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="700" height="0" align="left" valign="top"><p>
      <?php if($tabsend){ ?>
    </p>
      <table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <th width="150" align="center" valign="top" background="imgs/main_bc.jpg" scope="col">        
        <th width="530" align="center" valign="top" background="imgs/main_bc.jpg" scope="col"><table width="530" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
          <tr>
            <td width="540">
              <?php if($tabsend){ ?>
              <form name="post" action="previewcard.php" method="post">
                <table width="530" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <th align="left" valign="top" scope="col"> 
                        <input name="cardid" type="hidden" value="<?php echo"$cardid" ?>">
		                 <input name="card_name" type="hidden" value="<?php echo"$card_name" ?>">
                        <table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <th scope="col"><p>&nbsp;</p>
                            <p><img src="<?php echo"$ecardsdir$card_name" ?>"></p></th>
                          </tr>
                          <tr>
                            <td><table width="505" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                  <th width="500" align="center" scope="col"><?php echo"$msg";?></th>
                                </tr>
                                <tr>
                                  <td align="center"><table width="500" border="0" align="center" cellpadding="0" cellspacing="2">
                                      <tr align="left" valign="top">
                                        <td width="147" scope="col"><?php echo"$Send_To_Name";?></td>
                                        <th colspan="2" scope="col"><input name="toname" type="text"value="<?php echo"$toname"; ?>" size="18"></th>
                                      </tr>
                                      <tr align="left" valign="top">
                                        <td width="147" scope="col"><?php echo"$Send_To_Mail";?></td>
                                        <th colspan="2" scope="col"><input name="toemail" type="text"value="<?php echo"$toemail"; ?>" size="18"></th>
                                      </tr>
                                      <tr align="left" valign="top">
                                        <td width="147"><?php echo"$Send_Sender_Name";?></td>
                                        <td colspan="2"><input name="sendername" type="text"value="<?php echo"$sendername"; ?>" size="18"></td>
                                      </tr>
                                      <tr align="left" valign="top">
                                        <td width="147"><?php echo"$Send_Sender_Mail";?></td>
                                        <td colspan="2"><input name="senderemail" type="text"value="<?php echo"$senderemail"; ?>" size="18"></td>
                                      </tr>
                                      <tr align="left" valign="top">
                                        <td><?php echo "$Send_EC_Subject" ?></td>
                                        <td colspan="2"><input name="postsubject"  type="text" value="<?php echo"$postsubject"?>"  size="38" maxlength="80"></td>
                                      </tr>
                                      <tr align="left" valign="top">
                                        <td>&nbsp;</td>
                                        <td colspan="2"><?php include("smileys.php") ; ?></td>
                                      </tr>
                                      <tr align="left" valign="top">
                                        <td><?php echo"$Send_EC_MSGtext";?></td>
                                        <td colspan="2"><textarea name="postmsg" cols="45" rows="10"><?php echo"$postmsg";?></textarea></td>
                                      </tr>
                                      <tr align="left" valign="top">
                                        <td><?php echo"$Send_EC_FontFace";?></td>
                                        <td colspan="2"><select name="fontface">
										 <option value="<?php echo"$fontface"; ?>"><?php echo"$fontface"; ?></option>
                                            <?php include("font.php") ?>
                                        </select></td>
                                      </tr>
                                      <tr align="left" valign="top">
                                        <td><?php echo"$Send_EC_FontColor";?></td>
                                        <td colspan="2"><select name="fontcolor">
										<?php echo " <option  value='$fontcolor' style=' width:auto color:$fontcolor ; background-color : $fontcolor; '>"; ?>
										
                                            <?php include("color.php") ?>
                                        </select></td>
                                      </tr>
                                      <tr align="left" valign="top">
                                        <td><?php echo"$Send_EC_BackgroundColor";?></td>
                                        <td colspan="2"><select name="hccolor">
										<?php echo " <option  value='$hccolor' style=' width:auto color:$hccolor ; background-color : $hccolor; '>"; ?>
										
                                          <?php include("color.php") ?>
                                        </select></td>
                                      </tr>
                                      <tr align="left" valign="top">
                                                  </table></td>
                                </tr>
                                <tr>
                                  <td><?php echo"$Send_EC_Stamp";?></td>
                                </tr>
                                <tr>
                                  <td><table width="500" border="0" cellspacing="2" cellpadding="0">
                                      <tr align="center" valign="bottom" class="2">
                                        <th width="165" scope="col"><img src="imgs/stamp1.gif" width="70" height="60"> </th>
                                        <th width="165" scope="col"><img src="imgs/stamp2.gif" width="70" height="60"> </th>
                                        <th width="165" scope="col"><img src="imgs/stamp3.gif" width="70" height="60"> </th>
                                      </tr>
                                      <tr align="center">
                                        <td width="165"><input name="stamp" type="radio"   id="tb" style=" background-color : #ffffff; border-width : 0;" onmouseover="this.style.backgroundColor='#eeeeee'"onmouseout="this.style.backgroundColor='#ffffff'" value="stamp1.gif" checked >
                                        </td>
                                        <td width="165"><input name="stamp" type="radio" value="stamp2.gif" style=" background-color : #ffffff; border-width : 0;"onmouseover="this.style.backgroundColor='#eeeeee'"onmouseout="this.style.backgroundColor='#ffffff'"   id="tb" ></td>
                                        <td width="165"><input name="stamp" type="radio" value="stamp3.gif" style=" background-color : #ffffff; border-width : 0;" onmouseover="this.style.backgroundColor='#eeeeee'"onmouseout="this.style.backgroundColor='#ffffff'"   id="tb" ></td>
                                      </tr>
                                  </table></td>
                                </tr>
                                <tr>
                                  <td align="center"><input name="show" type="submit" value="<?php echo"$Send_EC_Show"; ?>"></td>
                                </tr>
                            </table></td>
                          </tr>
                      </table></th>
                  </tr>
                </table>
              </form>              
              <p>
                <?php } ?>
              </p>
              </td>
          </tr>
        </table>        
          <p>&nbsp;</p>
      </table>          
      <p>
        <?php } ?>
        <?php if($tabshow){ ?>
        </th> 
      </p>
	  <form action="<?php echo"$PHP_SELF"; ?>" method="post">  
	  <input name="card_name" type="hidden" value="<?php echo"$card_name"; ?>">
       <input name="cardid" type="hidden" value="<?php echo"$cardid" ?>">
       <input name="sendername" type="hidden" value="<?php echo"$sendername"; ?>">
	  <input name="senderemail" type="hidden" value="<?php echo"$senderemail"; ?>">
	  <input name="toname" type="hidden" value="<?php echo"$toname"; ?>">
	  <input name="toemail" type="hidden" value="<?php echo"$toemail"; ?>">
	  <input name="postsubject" type="hidden" value="<?php echo"$postsubject"; ?>">
      <input name="hccolor" type="hidden" value="<?php echo"$hccolor"; ?>">
	  <input name="fontcolor" type="hidden" value="<?php echo"$fontcolor"; ?>">
      <input name="fontface" type="hidden" value="<?php echo"$fontface"; ?>">
      <input name="stamp" type="hidden" value="<?php echo"$stamp"; ?>"> 
      <input name="postmsg" type="hidden" value="<?php echo"$postmsg"; ?>">  
	  <table width="680" border="0" cellspacing="0" cellpadding="0" bgcolor="<?php echo"$hccolor"; ?>">
        <tr>
          <th width="678" colspan="2" align="left" scope="col"><table width="700" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
            <tr> </tr>
            <tr>
              <td colspan="2" align="center"><table width="700">
                <tr>
                  <td width="550"><table width="550">
                    <tr>
                      <td width="100"><span class="Stil3"><?php echo"$Send_Sender_Name";?></span></td>
                      <td width="450"><span class="Stil3"><?php echo"$sendername";?></span></td>
                    </tr>
                    <tr>
                      <td width="100"><span class="Stil3"><?php echo"$Send_Sender_Mail";?></span></td>
                      <td width="450"><span class="Stil3"><?php echo"$senderemail";?></span></td>
                    </tr>
                  </table></td>
                  <td width="150" align="right"><img src="<?php echo"imgs/$stamp"?>" width="70" height="60"></td>
                </tr>
              </table>                
                <p><font color="<?php echo"$fontcolor";?>" ><?php echo"$postsubject"?></font></p>
              </td>
            </tr>
            <tr>
              <td width="350" align="center" valign="top"><table width="350" cellspacing="10">
                <tr>
                  <td width="390" align="center"><img src="<?php echo"$ecardsdir$card_name"; ?>"></td>
                </tr>
              </table></td>
              <td width="348" align="left" valign="top"><table width="340">
                <tr>
                  <td width="340"><font color="<?php echo"$fontcolor";?>"><?php echo"$postmsg"?></font></td>
                </tr>
              </table>                <p>&nbsp;</p>
                  <p>&nbsp;</p></td>
            </tr>
            <tr align="center">
              <td colspan="2"><table width="300" border="0" cellspacing="5" cellpadding="0">
                  <tr>
                    <th scope="col"><input name="send" type="submit" value="<?php echo"$Send_EC_Send";  ?>"></th>
                    <th scope="col"><input name="edit" type="submit" value="<?php echo"$Send_EC_Edit";  ?>"></th>
                  </tr>
              </table></td>
            </tr>
          </table></th>
        </tr>
      </table>
	  </form>      <p>
      <?php } ?>  
    </p>    </tr>
  <tr>
    <td align="center" valign="top">  
  </tr>
      <tr>
        <td colspan="2">
		<?php if($tabsent){?>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<table width="700" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th scope="col"><?php echo"$Send_EC_succ";?></th>
          </tr>
          <tr>
            <th scope="col"><a href="index.php" target="_self"><?php echo"$Send_EC_Next";?></a></th>
          </tr>
        </table>
		<?php } ?></td>
      </tr>
    </table>
</td>
  </tr>
</table>
</body>
</html>
