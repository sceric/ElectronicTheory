<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("ecardswa.php");
include("connect.php");
include("session.php");
$msg=$Get_Pass_MSG;

function new_pw() 
{ 
$id = (integer) md5(microtime()); 
mt_srand($id); 
$pw = mt_rand(1,99999999); 
$pw = substr(md5($pw ), mt_rand(0, 15), mt_rand(5, 9)); 
return $pw; 
} 


if($send){
$sqlcheckmail=mysql_query("select*from ecardswa_user where  uemail='$emailu'");
if(!empty($sqlcheckmail)){
$nummail=mysql_num_rows($sqlcheckmail);
}
if($nummail==1){
$rowmail=mysql_fetch_array($sqlcheckmail);
$uname=$rowmail["username"];
$user_id=$rowmail["userid"];
 
$new_password = new_pw();
$sql_update=mysql_query("update ecardswa_user set passwd=password('$new_password')  where userid='$user_id'");
if($sql_update){
$mailmsg="$hello"." "."$uname\n$Get_Pass_MailMSG\n$Get_Pass_MailSubject: $new_password\n\n$Reg_Signatur_MSG\n$host";
$send_mail=mail($emailu,$Get_Pass_MailSubject,$mailmsg, "From: $adminmail");
$msg=$Get_Pass_Send;
  } 
 }
else if($nummail==0){
$msg=$Get_Pass_Error;
 }
}

?>

<html>
<head>
<title><?php echo"$get_pass"; ?></title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil2 {	font-size: 12px;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="600" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="3" cellpadding="0">
      <tr>
        <th width="150" align="left" valign="top" scope="col"><table width="149" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th align="center" scope="col"> <?php include("tablogin.php") ?></th>
          </tr>
          <tr>
            <td align="center"><?php include("tabcat.php") ?></td>
          </tr>
        </table></th>
        <th width="550" rowspan="2" align="center" valign="top" scope="col"><table width="400" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
          <tr>
            <th bgcolor="#FFCC99" scope="col"><?php  print "$msg" ; ?></th>
          </tr>
          <tr>
            <th scope="col">              <table width="400">
              <tr>
                <td align="center"><table width="400">
                  <tr>
                    <td width="400">                        <form action="<?php print "$PHP_SELF"; ?>" method="post">
                          <table width="400" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <th width="250" align="left" scope="col"><input name="emailu" type="text" value="<?php print "$emailu"; ?>" size="40">
                              </th>
                              <th width="150" align="left" scope="col"><input name="send" type="submit" value="<?php print "$Get_Pass_Submit"; ?>" size="40"></th>
                            </tr>
                          </table>
                        </form>
                        </td>
                  </tr>
                </table>
                  </td>
              </tr>
            </table></th>
          </tr>
        </table>        
      <tr>
            <th align="left" valign="top" scope="col"><p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p></th>
        </table>          
    <p>&nbsp;</p>
          <p>&nbsp;</p>
    <p>&nbsp;</p></th>    
  </tr>
      <tr>
        <td width="700" colspan="2" align="center" valign="bottom"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
