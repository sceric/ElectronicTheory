<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("ecardswa.php");
include("connect.php");
$tabshow=true;
$tabempty=false;

if(($id)&&($code)){
$sqlcard=mysql_query("SELECT *FROM ecardswa_post p, ecardswa_card c, ecardswa_user u WHERE p.cardid = c.cardid AND p.userid = u.userid AND p.postcode = '$code' AND p.postid = '$id'");

if(!empty($sqlcard)){
$num=mysql_num_rows($sqlcard);
$rowcard=mysql_fetch_array($sqlcard);
$post_id=$rowcard["postid"];  
$card_id=$rowcard["cardid"]; 
$post_code=$rowcard["postcode"]; 
$toname=$rowcard["toname"]; 
$toemail=$rowcard["toemail"];
$sendername=$rowcard["username"];
$senderemail=$rowcard["uemail"]; 
$postsubject=$rowcard["posttitle"]; 
$p_status=$rowcard["pstatus"]; 
$postmsg=$rowcard["postmsg"];
$card_name=$rowcard["cardname"];
$post_date=$rowcard["postdate"];
$fontface=$rowcard["fontface"];
$hccolor=$rowcard["cardbg"];
$fontcolor=$rowcard["fontcolor"];
$stamp=$rowcard["stampname"];

                $postmsg = str_replace("s1:-)", "<img src='smileys/2.gif'>", $postmsg);
                $postmsg = str_replace("s2:-)", "<img src='smileys/2.gif'>", $postmsg);
                $postmsg = str_replace("s3:-)", "<img src='smileys/3.gif'>", $postmsg);
				$postmsg = str_replace("s4:-)", "<img src='smileys/4.gif'>", $postmsg);
				$postmsg = str_replace("s5:-)", "<img src='smileys/5.gif'>", $postmsg);
				$postmsg = str_replace("s6:-)", "<img src='smileys/6.gif'>", $postmsg);
				$postmsg = str_replace("s7:-)", "<img src='smileys/7.gif'>", $postmsg);
				$postmsg = str_replace("s8:-)", "<img src='smileys/8.gif'>", $postmsg);
				$postmsg = str_replace("s9:-)", "<img src='smileys/9.gif'>", $postmsg);
				$postmsg = str_replace("s10:-)", "<img src='smileys/10.gif'>", $postmsg);
				$postmsg = str_replace("s11:-)", "<img src='smileys/11.gif'>", $postmsg);
				$postmsg = str_replace("s12:-)", "<img src='smileys/12.gif'>", $postmsg);
				$postmsg = str_replace("s13:-)", "<img src='smileys/13.gif'>", $postmsg);
				$postmsg = str_replace("s14:-)", "<img src='smileys/14.gif'>", $postmsg);
				$postmsg = str_replace("s15:-)", "<img src='smileys/15.gif'>", $postmsg);
				$postmsg = nl2br($postmsg);

}if($num==0){
$tabshow=false;
$tabempty=true;
}
$link="$host/view.php?id=$id&code=$code";
$mailmsg="$hello $sendername\n$View_EC_PickupMSG\n$link\n\n\n$Reg_Signatur_MSG\n$host\n";

if($p_status==0){
$pickup_mail=mail($senderemail,$View_EC_PickupSubject,$mailmsg, "From: $adminmail ");

if($pickup_mail=true){
$sqlpickup=mysql_query("update  ecardswa_post set pstatus='1' where postid ='$id'");
}
}
}else{
$tabshow=false;
$tabempty=true;

}



?>

<html>
<head>
<title> Ecardswa v1.5 </title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil3 {font-size: 12px}
-->
</style>
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="700" height="0" align="center" valign="top"><p>
        <?php if($tabshow){ ?>
        </th> 
      </p>
	   <table width="680" border="0" cellspacing="0" cellpadding="0" bgcolor="<?php echo"$hccolor"; ?>">
        <tr>
          <th width="678" colspan="2" align="left" scope="col"><table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr> </tr>
            <tr>
              <td colspan="2" align="center"><table width="700">
                <tr>
                  <td width="550"><table width="550">
                      <tr>
                        <td width="100"><span class="Stil3"><?php echo"$Send_Sender_Name";?></span></td>
                        <td width="450"><span class="Stil3"><?php echo"$sendername";?></span></td>
                      </tr>
                      <tr>
                        <td width="100"><span class="Stil3"><?php echo"$Send_Sender_Mail";?></span></td>
                        <td width="450"><span class="Stil3"><?php echo"$senderemail";?></span></td>
                      </tr>
                  </table></td>
                  <td width="150" align="right"><img src="<?php echo"imgs/$stamp"?>" width="70" height="60"></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td width="700" colspan="2" align="center"><font color="<?php echo"$fontcolor";?>" face="<?php echo"$fontface"; ?>"><?php echo"$postsubject"?></font></td>
            </tr>
            <tr>
              <td width="360" align="left" valign="top"><table width="350" cellspacing="10">
                <tr>
                  <td width="390" align="center"><img src="<?php echo"$ecardsdir$card_name"; ?>"></td>
                </tr>
              </table></td>
              <td width="340" align="left" valign="top"><table width="340">
                <tr>
                  <td width="340"><font color="<?php echo"$fontcolor";?>" face="<?php echo"$fontface"; ?>"><?php echo"$postmsg"?></font></td>
                </tr>
              </table>
              <p>&nbsp;</p></td>
            </tr>
            <tr align="center">
              <td colspan="2"><a href="<?php echo"$host" ?>"><?php echo"$View_EC_Answer" ?></a></td>
            </tr>
          </table></th>
        </tr>
      </table>
	    <p>
      <?php } ?>  
        </p>    </tr>
  <tr>
    <td align="center" valign="top">  
  </tr>
      <tr>
        <td colspan="2">
		<?php if($tabempty){?>
		<table width="700" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th scope="col"><a href="index.php" target="_self"><?php echo"$View_EC_Error";?></a></th>
          </tr>
        </table>
		<?php } ?></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
