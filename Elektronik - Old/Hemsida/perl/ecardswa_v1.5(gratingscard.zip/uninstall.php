<?php
include("config.php");
include("connect.php"); 
$tab1=true;
$tab2=false;
$msg="do you want really to remove Ecardswa_v1.5  from your server?";

if($uninstall){
$SqlDrop=mysql_query("DROP TABLE `ecardswa_admin`, `ecardswa_card`, `ecardswa_cat`, `ecardswa_fav`, `ecardswa_post`, `ecardswa_rate`, `ecardswa_user`");
if(!empty($SqlDrop)){
$msg="Ecardswa_v1.5 has been removed.";
$tab2=true;
$tab1=false;
}else {
$tab2=true;
$tab1=false;
$msg="Ecardswa_v1.5 could not be removed.";
 }
}


?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="style.css" rel="stylesheet" type="text/css">

<title> Ecardswa_v.15 uninstall </title>
</head>

<body>
<p>&nbsp;</p>
<table width="400" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFCC00">
  <tr>
    <td>
	<?php if($tab1){ ?>
	<form action="<?php echo"$PHP_SELF"?>" method="post"> 
	<table width="390" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
      <tr>
        <td align="center"><?php echo"$msg";?></td>
      </tr>
      <tr>
        <td align="center"><input name="uninstall" type="submit" value="yes"></td>
      </tr>
    </table>
	</form>
	<?php }  ?></td>
  </tr>
  <tr>
    <td>
	<?php if($tab2){ ?>
	<table width="390" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
      <tr>
        <td align="center"><?php echo"$msg";?></td>
      </tr>
    </table>
	<?php }  ?></td>
  </tr>
</table>
</body>
</html>
