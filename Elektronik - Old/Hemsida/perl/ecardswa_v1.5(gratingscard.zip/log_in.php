<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("ecardswa.php");
$msg=$log_MSG;
$red="#ff0000";
$black="#000000";
$fontc=$black;

if($login=="wrong"){
$msg=$log_Error_MSG;
$fontc=$red;
}
else if($login=="missing"){
$msg=$log_Notlog_MSG;
$fontc=$red;
}
?>

<html>
<head>
<title><?php echo "$msg"; ?></title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil1 {
	font-size: 12px;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="500" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="3" cellpadding="0">
      <tr>
        <th width="150" align="left" valign="top" scope="col">&nbsp;</th>
        <th width="550" height="400" valign="top" scope="col"><table width="400" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" id="tb">
          <tr>
            <th width="400" height="21" bgcolor="#FFCC99" scope="col"><font color="<?php echo"$fontc" ?>"><?php if($msg){ echo"$msg"; } ?></font></th>
          </tr>
          <tr>
            <td><table width="400">
              <tr>
                <td><form action="login.php" method="post">
                  <table width="188" align="center">
                    <tr>
                      <th width="60" align="left" scope="col"><span class="Stil1"><font size="2"><?php print"$Reg_Name"; ?></font></span></th>
                      <th width="130" align="left" scope="col"><input name="loginname" size="14" typ="text"></th>
                    </tr>
                    <tr>
                      <td width="60" align="left"><span class="Stil1"><font size="2"><?php print"$Reg_Pass"; ?></font></span></td>
                      <td width="130" align="left"><input name="pass" type="password" size="14" ></td>
                    </tr>
                    <tr align="right">
                      <td width="60">&nbsp;</td>
                      <td width="130" align="left"><input name="log" type="submit"  value="<?php echo"$log_MSG";?>"   ></td>
                    </tr>
                  </table>
                </form></td>
              </tr>
              <tr>
                <td><a href="newuser.php"><?php echo"$new_reg"; ?></a></td>
              </tr>
              <tr>
                <td><a href="getpass.php"><?php echo"$get_pass"; ?></a></td>
              </tr>
            </table></td>
          </tr>
        </table>        
        </table>          
    <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          </th>
  </tr>
      <tr>
        <td colspan="2" align="center" valign="bottom"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
