<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("ecardswa.php");
include("connect.php");

$tabsubmit=true;
$tabsignin=false;

if($id){

$sqlget=mysql_query("select * from ecardswa_user where  userid='$id' AND  uemail='$email'");
if(!empty($sqlget)){
$getnum=mysql_num_rows($sqlget);
if($getnum==1){
$msg=$Get_Account_MSG;
}else if($getnum==0){
$msg=$Get_id_Error;
 }
}

if($getfree){
$sqlfree=mysql_query("select fcode, userid from ecardswa_user where  userid='$diusr' AND   fcode='$code'");
$freenum=mysql_num_rows($sqlfree);
if($freenum==1){
$sqlgetfree=mysql_query("UPDATE `ecardswa_user` SET `ustatus` = '1' WHERE `userid` = '$diusr'");
$msg=$Get_Account_Succ;
$tabsubmit=false;
$tabsignin=true;
}else if($freenum==0){
$msg=$Get_Code_Error;
           }
        }
    }
else
   {
 
    $msg=$Get_id_Error;
}

?>


<html>
<head>
<title> Ecardswa v1.5   </title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil2 {	font-size: 12px;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="600" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="3" cellpadding="0">
      <tr>
            <th width="150" align="left" valign="top" scope="col"></th>
          <th width="550" align="center" valign="top" scope="col"><table width="450" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
            <tr>
              <th bgcolor="#FFCC99" scope="col"><?php if($msg){ print "$msg"; } ?></th>
            </tr>
            <tr>
              <th scope="col"><table width="400">
                  <?php if($tabsubmit){ ?>
                  <tr>
                    <td width="400"><form action="<?php echo"$PHP_SELF?id=$id";?>" method="post">
                        <input name="diusr" type="hidden" value="<?php print "$id"; ?>">
                        <table width="400">
                          <tr>
                            <th width="150" scope="col"><?php print "$Reg_Code"; ?></th>
                            <th colspan="2" align="left" scope="col"><input name="code" type="text" size="20" ></th>
                          </tr>
                          <tr>
                            <td width="150">&nbsp;</td>
                            <td>&nbsp;</td>
                            <td><input name="getfree" type="submit" value="<?php print "$Get_Submit_MSG"; ?>">
                            </td>
                          </tr>
                        </table>
                    </form></td>
                    <?php  }  ?>
                  </tr>
                  <tr>
                    <td align="center">
				      <?php
			        if($tabsignin){ ?>
                      <form action="login.php" method="post" >
                        <table width="140" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <th width="50" align="center" valign="top" class="Stil2" scope="col"><?php print"$Reg_Name"; ?></th>
                            <th width="60" align="left" scope="col"><input name="loginname" type="text" size="14"></th>
                          </tr>
                          <tr>
                            <td width="50" align="center" valign="top"><span class="Stil2"> <?php print"$Reg_Pass"; ?></span></td>
                            <td width="60" align="left"><input name="pass" type="password" size="14"></td>
                          </tr>
                          <tr align="right">
                            <td width="50">&nbsp;</td>
                            <td align="left"><input name="log" type="submit" value="login"></td>
                          </tr>
                        </table>
                      </form>
                      <?php } ?></td>
                  </tr>
              </table></th>
            </tr>
          </table>
            <p>&nbsp;</p>
        </table>          
  </th>    
  </tr>
      <tr>
        <td  width="700" colspan="2" align="center" valign="bottom"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
