Copyright.
license.
Features.
Installation.
-------------------------------------------------------------------------------------------------
                                 Ecardswa Version 1.5
                                Released January , 2005
                             Copyright Ecardswa Version 1.5 
                                     Powered by:   
                                   www.demof.com                                               
                                   www.ecards.it                                                                    
                                 Autor: Walid Awad
                                                                           
-------------------------------------------------------------------------------------------------
                                       license

-> Alle Lizenzbestimmungen gelten, sobald Sie dieses Programm auf Ihrem Server installiert 
   und ver�ffentlicht haben.
-> "Ecardswa v.1.5" ist ein free programm und darf - unter der ausdr�cklichen Bedingung dass das 
   Copyright des Autors auf keinen Fall entfernt oder ge�ndert wird - 
   sowohl privat als auch kommerziell verwendet werden.
   Bei n�heren Fragen zum Copyright bzw. zur Lizenz, wenden Sie sich bitte an license@demof.com. 
-> Dieses programm darf ohne ausdr�ckliche Erlaubnis des Autors weder weitergegeben noch
   weiterentwickelt werden. Sollten Sie Interesse an der Weiterentwicklung dieses Programmes haben,
   dann schreiben Sie eine Email an development@demof.com
-> "Ecardswa_v.1.5" wurde auf jegliche Fehler getestet. Sollten dennoch irgendwelche Sch�den durch die 
   verwendung dieser Programme auftreten, entsteht keinerlei Haftungsanspruch.
-> Das Layout dieses Testprogrammes darf ver�ndert werden.
-> Es besteht keinerlei Support-Verpflichtung seitens des Autors. Fragen k�nnen an das Forum.
-------------------------------------------------------------------------------------------------
                                        Features

-> Benutzer registrieren
-> Benutzer freischalten: Jeder Benutzer bekommt nach der Anmeldung per angebener Email-Adresse einen
   Freischaltungscode. Benutzer wird automatisch aktiviert, nachdem er/sie den richtigen Freischaltungscode 
   eingibt.
-> Benutzer-Account
-> Verlauf: Jeder Benutzer hat den �berblick auf alle verschickten Gru�karten.
-> Favoriten: jeder Benutzer kann besonderes interessante Grusskarten zur Favoriten-Liste hinzuf�gen. 

-> Gru�kartenkategorien:
-> Die Anzahl der Kategorien ist unbegrenzt.
-> Die Anzahl der Gru�karten/Kategorie ist auch unbegrenzt.
-> Attraktive Gestaltungsm�glichkeiten: Schriftfart, Schriftfarbe, Hintergrundfarbe,smilies,  Stempel etc.
-> Pick-up-Benachrichtigung.
-> Top-ecards: Gru�karten k�nnen von den Benutzern  bewertet werden.
-> Neue Gru�karten: Das Programm zeigt eine �bersicht �ber die aktuellsten Gru�karten.

-> Adminstration.
-> Der Admin-Bereicht ist mit Zugangsdaten gesch�tzt.
-> Eine unbegrenzte Anzahl von Gru�karten-Kategorien einf�gen.
-> Grusskarten-Kategorien �ndern, l�schen.
-> Grusskarten nur in den Formaten .gif, .jpg und .png per Browser auf dem FTP-Server hochladen.
-> �berblick �ber alle Nutzer.
-> Nutzer-Suchfunktion.


-------------------------------------------------------------------------------------------------
                                      Installation


-> Entpacken Sie alle files aus dem "ecardswa_v1.5zip" und laden Sie sie auf Ihren FTP-Server;
-> �ndern Sie die Schreibrechte f�r das file "config.php" auf "chmode 666" und das Verzeichnis,
   "ecards" auf "chmode 777"
-> Rufen Sie das file "install.php" auf und geben Sie Ihre Zugangsdaten zu Ihrem MySQL-Server;
   DB Name: Datenbank Name.
   DB User: Der Benutzername f�r den Zugriff auf Ihre MySQL Datenbank.
   DB Password: Das Kennwort f�r den Zugriff auf Ihre MySQL Datenbank.
   DB Host: MySQL Hostname.
-> Site setting
   Site Name: Name Ihrer Webseite.
   The Path to Ecardswa_v1.5: Geben Sie hier den Hostnamen zu den ecardswa_v1.5 files ein, zB wie
   "http://www.mysite.com/ecardswa_v1.5 ohne "/" am Ende.
-> Admin setting
   Username: Geben Sie hier einen Admin-Nutzername f�r den Zugriff auf den Admin-Bereich ein.
   Password: Geben Sie hier das Admin-Kennwort f�r den Zugriff auf den Admin-Bereich ein.
   Email: Geben Sie hier die Admin Email-Adresse ein.
-> Nachdem Sie die Software erfolgreich istalliert haben, l�schen Sie die files "install.php" und "uninstall.ph" von Ihrem Server;
-> Loggen Sie sich im Admin-Bereich ein; 
-> Spracheinstellungen: �ffnen Sie die Datei "ecardswa.php"; f�r die gew�nschte Sprache, �ndern Sie den
   Filenamen, zB include("en.php") "en" f�r Englisch, include("de.php") "de" f�r Deutsch;
   f�r Anpassungen �ffnen Sie die Datei "language/de.php" und passen Sie den Text zwischen " " entsprechend an;
   zB $das_darf_ich_nicht_�ndern="das_darf_ich_�ndern";
-> Wollen Sie eine neue Sprache einf�gen, �ffnen Sie die Datei "en.php" und �bersetzen Sie entsprechend;
-> Weitere Programmeinstellungen: �ffnen Sie die Datei "ecardswa.php", dort finden Sie Kommentare zu jeder Variable.
-> Sollten Probleme bei der Installation auftreten, dann schreiben Sie es im Forum.

