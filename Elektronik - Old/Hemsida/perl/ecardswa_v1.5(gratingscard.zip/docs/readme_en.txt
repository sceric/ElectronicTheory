Copyright.
license.
Features.
Installation.
-------------------------------------------------------------------------------------------------
                                 Ecardswa Version 1.5
                                Released January , 2005
                            Copyright Ecardswa Version 1.5 
                                     Powered by:   
                                   www.demof.com                                               
                                   www.ecards.it                                                                    
                                 Autor: Walid Awad
                                                                           
-------------------------------------------------------------------------------------------------
                                       license

-> All license terms & conditions are valid as soon as you have installed this programm on 
   to your server and published it.
-> "Ecardswa v.1.5" is a free programm and may be used both for private and business purposes 
   under the explicit condition that the copyright of the author must not in any case 
   whatsoever changed or removed.
-> Further questions relating to the copyright and the license be directed to license@demof.com 
-> This test programm must not be further distributed and developed without explicit 
   consent of the author.
-> If you are interested in a further devevlopment of this programm, write email to development@demof.com
-> "Ecardswa_v.1.5" has been tested for any errors. Notwithstanding this fact, 
   if some damage may occur due to the use of this programm, there no damages of any nature.
-> You are not allowed to use this free programm for any PORN sites
-> You may change the layout of this free programm.
-> There is no support obligation by the author. Questions may be directed to the forum.
-------------------------------------------------------------------------------------------------

                                        Features
-> User registration. 

-> User activation: 
   Each user receives upon registration an email with the activation code to the provided email-address.
   Each user will be automatically activated after having typed in the correct activation-code. 

-> User Account administration:
-> History:
-> Each user has the overview over all greeting cards sent.
-> Favorite :users can add interesting cards to their Favorites.
-> Greeting card categories.
-> The number of categories is unlimited.
-> The number of greeting cards/category is unlimited. 
-> Attractive design options: Font type, font colour, smileys,  background colour, stamp etc. 
-> Pick-up-notification.
-> Top-ecards: greeting-card  can be rated by the users. 
-> New greeting cards: The programm provides an overview over the latest greeting cards. 

   Adminstration.
-> The admin-area is protected by access-data.
-> Add an unlimited number of greeting-card-categories.
-> Edit/delete greeting-card-categories.
-> Greeting cards in the formats .gif, .jpg and .png only.
-> to be uploaded via browser to the FTP-server.
-> Delete greeting cards via browser.
-> Overview over all users.
-> User search/sort function.

-------------------------------------------------------------------------------------------------
                                    Installation

-> Un-packall files from "ecardswa_v1.5.zip" and load them to your FTP-Server.
-> Change the writing rights for the file "config.php" to "chmode 666"
   and for the directory, "ecards" to "chmode 777".
-> Open the file "install.php" and enter your access-date to your MySQL-Server.
   DB Name: Database name.
   DB User: User name for the access to your MySQL database.
   DB Password: Password for the access to your MySQL database.
   DB Host: MySQL Hostname.
-> Site setting
   Site Name: Name of your page.
   The Path to ecardswa_v1.5: Enter here the host-name to the
   ecardswa_v1 files, for example like "http://www.mysite.com/ecardswa_v1.5 without "/" at the end.
-> Admin setting
   Username: Enter here an admin-user name for the access to the admin-area.
   Password: Enter here the admin password for the access to the admin-area. 
   Email: Enter here the admin email-address.
-> After having successfully installed the programm, delete the files
   "install.php" and "uninstall.php" from your server.
-> Log-in to the admin-area. 
-> Language settings: Open the file "ecardswa.php"; change the file-name
   for the requested language, for example include("de.php") "de" for 
   German, include("en.php") "en" for English.
   Regarding modifications open the file "language/en.php" and modify 
   the text between " " accordingly, for example
   $I_must_not_change_this="I_may_change_this";
-> do you wish to enter a further language, open the file "en.php"
   and translate accordingly.
-> Further settings: Open the file "ecardswa.php";
   here you find comments for each variable.
-> Further questions to the installation be directed to the forum. 

