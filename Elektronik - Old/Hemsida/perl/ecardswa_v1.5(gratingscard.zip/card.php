<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("ecardswa.php");
include("connect.php");
include("session.php");
$tabcard=true;
$tabnav=true;
$tabnav1=true;
if($cardid){
$sqlcard=mysql_query("SELECT *FROM  ecardswa_card WHERE cardid = '$cardid'");
if(!empty($sqlcard)){
$rowcard=mysql_fetch_array($sqlcard);
$card_id=$rowcard["cardid"];
$card_name=$rowcard["cardname"];
  }
 }
 else
 {
 $msg=$Send_EC_MSGEmpty;
 $tabnav=false;
 $tabnav1=false;
 $tabcard=false;
 }
?>

<html>
<head>
<title> Ecardswa v1.6  </title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil2 {	font-size: 12px;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="500" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="150" align="left" valign="top" scope="col"><table width="149" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th align="center" scope="col"> <?php include("tablogin.php") ?></th>
          </tr>
          <tr>
            <td align="center"><?php include("tabcat.php") ?></td>
          </tr>
        </table></th>
        <th width="550" align="center" valign="top" scope="col"><table width="530" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="center"><table  width="530" border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <th width="530" height="125" align="center" valign="top" scope="col"><table width="500" border="0" cellspacing="5" cellpadding="0">
                  <tr>
                    <td width="500" align="center"><?php echo"$msg"; ?></td>
                  </tr>
                  <tr>
                    <td width="500" align="center"><?php if($tabnav1){?>
                      <table width="400" border="0" cellspacing="0" cellpadding="0">
                        <tr align="center" valign="bottom">
                          <td><table width="130" height="18">
                            <tr>
                              <td align="center" valign="middle" background="imgs/button_hc2.gif"><a href="<?php echo "sendcard.php?cardid=$card_id"?>"><?php echo"$Card_Send_MSG";?></a></td>
                            </tr>
                          </table></td>
                          <td><table width="130" height="18">
                            <tr>
                              <td align="center" valign="middle" background="imgs/button_hc2.gif"><a href="<?php echo"rate.php?id=$card_id";?>"><?php echo"$Card_RateIt_MSG ";?></a></td>
                            </tr>
                          </table></td>
                          <td><table width="130" height="18">
                            <tr>
                              <td align="right" valign="middle" background="imgs/button_hc2.gif"><a href="<?php echo"favorites.php?id=$card_id";?>"><?php echo"$Card_AddToFavorites_MSG";?></a></td>
                            </tr>
                          </table></td>
                        </tr>
                      </table>                                            <?php } ?>                      </td>
                  </tr>
                  <tr>
                    <td width="500" align="center"><?php if($tabcard){?>
                      <table width="500" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td width="500" align="center"><a href="<?php echo "sendcard.php?cardid=$card_id"?>"><img src="<?php echo"$ecardsdir$card_name" ?>" border="0"></a></td>
                        </tr>
                      </table>
                      <?php } ?></td>
                  </tr>
                  <tr>
                    <td width="500" align="center">
					<?php if($tabnav){?>
					<table width="400" border="0" cellspacing="0" cellpadding="0">
                      <tr align="center" valign="bottom">
                        <td><table width="130" height="18">
                            <tr>
                              <td align="center" valign="middle" background="imgs/button_hc2.gif"><a href="<?php echo "sendcard.php?cardid=$card_id"?>"><?php echo"$Card_Send_MSG";?></a></td>
                            </tr>
                        </table></td>
                        <td><table width="130" height="18">
                            <tr>
                              <td align="center" valign="middle" background="imgs/button_hc2.gif"><a href="<?php echo"rate.php?id=$card_id";?>"><?php echo"$Card_RateIt_MSG ";?></a></td>
                            </tr>
                        </table></td>
                        <td><table width="130" height="18">
                            <tr>
                              <td align="right" valign="middle" background="imgs/button_hc2.gif"><a href="<?php echo"favorites.php?id=$card_id";?>"><?php echo"$Card_AddToFavorites_MSG";?></a></td>
                            </tr>
                        </table></td>
                      </tr>
                    </table>
					<?php } ?> </td>
                  </tr>
                </table></th>
              </tr>
            </table></td>
          </tr>
        </table>        
      </table>          
    </th>    
  </tr>
      <tr>
        <td colspan="2" align="center" valign="bottom"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
