<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("ecardswa.php");
$tabhistory=true;
$tabempty=false;
$tabdelte=false;
$start=0;
$end=$history_result;

if($deletepost){
$tabhistory=false;
$tabdelete=true;
$msg2=$history_Delete_MSG;
$result=false;
$numhistory=false;
}

if($delpost){
$sqldelete=mysql_query("DELETE FROM ecardswa_post where postid='$pid' ");
$msg=$history_Delete_ECsucc;
$tabhistory=true;
}





if(isset($result)){
				  if($result==1){
				  $end=$history_result;
                  $start=0;
				  
				  }else if($result >=2){
				  $m=$result-1;
			      $end=+$history_result;
                  $start=$m*$end;
				  } 
                  }

$sqlhistory=mysql_query("select*from ecardswa_post where userid='$ecardswa_userid' order by postdate DESC limit $start, $end ");
$sqlhistorytotal=mysql_query("select*from ecardswa_post where userid='$ecardswa_userid'");

if(!empty($sqlhistorytotal)){
$totalnum=mysql_num_rows($sqlhistorytotal);
}

if(!empty($sqlhistory)){
$numhistory=mysql_num_rows($sqlhistory);
if($numhistory >=1){
 $sqlhistory2=mysql_query("select*from ecardswa_post where userid='$ecardswa_userid'");
  $numhistory2=mysql_num_rows($sqlhistory2);
 $msg=$numhistory2 ." ".$history_Sent_Ecards;
}else if($numhistory==0){
$tabhistory=false;
$tabempty=true;
  }
}


?>

<html>
<head>
<title>Ecardswa v1.5 </title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="500" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="150" align="left" valign="top" scope="col"><table width="149" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th align="center" scope="col"> <?php include("tablogin.php") ?></th>
          </tr>
          <tr>
            <td align="center"><?php include("tabcat.php") ?></td>
          </tr>
        </table></th>
        <th width="550" align="center" valign="top" scope="col"><table width="530" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th width="540" scope="col"><p><?php echo"$msg";?></p>
              </th>
          </tr>
          <tr>
            <th align="right" scope="col"><table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <th scope="col">&nbsp;</th>
              </tr>
            </table></th>
          </tr>
          <tr>
            <td width="540"><?php if($tabhistory){ ?>
              <table width="530" border="0" align="center" cellpadding="0" cellspacing="0" >
                <tr>
                  <th align="center" valign="top" scope="col">
				  <?php if($numhistory >=1){  
				  
				  while ($rowhis=mysql_fetch_array($sqlhistory)){
				  $post_id=$rowhis["postid"]; 
                  $post_code=$rowhis["postcode"]; 
                  $postsubject=$rowhis["posttitle"];
				  $post_date=$rowhis["postdate"];
				  
				  ?>
				  
				  <table width="530" border="0" align="center" cellpadding="0" cellspacing="5">
                      <tr valign="top">
                        <td width="400" height="19" align="left"><font size="2" ><a href="<?php echo"view.php?id=$post_id&code=$post_code" ?> "><?php echo"$postsubject"?></a></font></td>
                        <td width="80" align="center"><font size="2" ><?php echo"$post_date";?></font></td>
                        <td width="50" align="center"><a href="<?php echo"$PHP_SELF?deletepost=$post_id"?>"><?php echo"$history_Delete"?></a></td>
                      </tr>
                  </table>
				  <?php } }  ?>
				  <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="50" align="center"><?php if ($totalnum >$history_result ){ print "$Site" ; } ?></td>
                      <td><table width="10" border="0" cellspacing="5" cellpadding="0">
                          <tr>
                            <?php  
		     if ($totalnum > $history_result){
						 $div=$totalnum/$history_result;
						 if(!is_int($div)){
						 $div=ceil($div);
						 }
						 $arr=range(1,$div);
						 foreach($arr as $elem) { ?>
                            <th scope="col"><a href="<?php echo "$PHP_SELF?result=$elem";  ?>" ><?php print "$elem"; ?></a></th>
                            <?php } } ?>
                      </table></td>
                    </tr>
                  </table></th>
                </tr>
              </table>
              <?php } ?></td>
          </tr>
          <tr>
            <td width="530" align="center"><?php if($tabdelete){ ?>
              <table  width="400" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" >
                <tr>
                  <th width="400" align="center" valign="middle" bgcolor="#FFCC66" scope="col"> <div align="center"><?php echo"$msg2";?></div></th>
                </tr>
                <tr>
                  <th width="400" align="center" valign="top" scope="col"><table width="400">
                      <tr bordercolor="#CCFFFF">
                        <th width="208" align="right" valign="top" bordercolor="#CCFFFF" scope="col"> <form action="<?php echo"$PHP_SELF"?>" method="post">
                            <input name="pid" type="hidden" value="<?php echo"$deletepost"; ?>">
                            <table width="100" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <th align="right" scope="col"><input name="delpost" type="submit" value="<?php echo"$yes"; ?>" >
                                </th>
                              </tr>
                            </table>
                        </form></th>
                        <th width="180" align="left" valign="top" bordercolor="#CCFFFF" scope="col"> <form action="<?php echo"$PHP_SELF" ?>" method="post">
                            <table width="100" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <th scope="col"><input name="notdelmsg" type="submit" value="<?php echo"$no"; ?>" ></th>
                              </tr>
                            </table>
                        </form></th>
                      </tr>
                  </table></th>
                </tr>
              </table>              <?php } ?>
			  <p>&nbsp;</p></td>
          </tr>
          <tr>
            <td>
			<?php if($tabempty){ ?>
			<table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <th scope="col"><?php echo"$history_Empty_MSG";?></th>
              </tr>
            </table>
			<?php } ?></td>
          </tr>
        </table>        
      
        </table>          
    </th>    
  </tr>
      <tr>
        <td colspan="2" align="center" valign="bottom"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
