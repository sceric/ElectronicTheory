<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("../ecardswa.php");


$tabuser=true;
$tabdelete=false;
$start=0;
$end=$AdminUser_result;

if($searchu){

  if(isset($result)){
				  if($result==1){
				  $end=$AdminUser_result;
                  $start=0;
				  
				  }else if($result >=2){
				  $m=$result-1;
			      $end=+$AdminUser_result;
                  $start=$m*$end;
				  } 
                  }
		  
   $sqluser=mysql_query("select* from ecardswa_user where username like '%$userkey%' order by adddate limit $start,$end ");
   $sqlusertotal=mysql_query("select* from ecardswa_user where username like '%$userkey%'");
   if(!empty($sqlusertotal)){
   $totalnum=mysql_num_rows($sqlusertotal);
   }
   
 }
if(!empty($sqluser)){
$numuser=mysql_num_rows($sqluser);
if($numuser==0){
$msg2=$Admin_SearchUser_Error;
  }
}


?>
<html>
<head>
<title>users</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="790" align="center">
  <tr>
    <th align="left" valign="top" scope="col"><table width="790">
      <tr>
        <th width="790" height="100" colspan="2" scope="col"><?php include("head.php"); ?></th>
      </tr>
      <tr>
        <td width="150" rowspan="4" align="left" valign="top"><?php include("navtab.php"); ?></td>
        <td width="640" align="left" valign="top">
		<form action="<?php echo"$PHP_SELF"; ?>" method="post"> 
		<table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <th colspan="2" scope="col"><?php echo"$Admin_SearchUser_MSG"; ?></th>
            </tr>
          <tr>
            <td width="350" align="right"><input name="userkey" type="text" ></td>
            <td width="250"><input name="searchu" type="submit" value="search"></td>
          </tr>
        </table>
		</form></td>
      </tr>
      <tr>
        <td width="640" align="center" valign="top"><?php echo"$msg2"; ?></td>
      </tr>
      <tr>
        <td width="640" align="left" valign="top"><table width="640" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th scope="col"><?php if($tabuser){ ?>
              <?php 
			   if($numuser >=1){			  					
			    while($rowuser=mysql_fetch_array($sqluser)){
			    $user_id=$rowuser["userid"];
			    $user_name=$rowuser["username"];
			    $add_date=$rowuser["adddate"];
			    $user_email=$rowuser["uemail"];
			    
			   
				
			  ?>
              <table width="640" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <th scope="col"><table width="640" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                      <tr align="center">
                        <th width="100" align="left" scope="col"><?php echo"$user_name"; ?></th>
                        <th width="340" align="left" scope="col"><?php echo"$user_email"; ?></th>
                        <th width="100" scope="col"><?php echo"$add_date"; ?></th>
                        <th width="100" scope="col"><a href="<?php echo"user.php?deleteuser=$user_id" ?>"><img src="imgs/delete.gif" alt="delete" width="11" height="17" border="0"></a></th>
                      </tr>
                  </table></th>
                </tr>
                <tr>
                  <td width="640" bgcolor="#FFCC99">&nbsp;</td>
                </tr>
              </table>
              <?php } } }  ?></th>
          </tr>
          <tr>
            <td><div align="center">
              <table border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="50" align="center"><?php if ($totalnum > $AdminUser_result ){ print "$Site" ; } ?></td>
                  <td><table width="10" border="0" cellspacing="5" cellpadding="0">
                      <tr>
                        <?php  
		     if ($totalnum > $AdminUser_result){
						 $div=$totalnum/$AdminUser_result;
						 if(!is_int($div)){
						 $div=ceil($div);
						 }
						 $arr=range(1,$div);
						 foreach($arr as $elem) { ?>
                        <th scope="col"><a href="<?php echo "$PHP_SELF?userkey=$userkey&result=$elem&searchu=ok";  ?>" ><?php print "$elem"; ?></a></th>
                        <?php } } ?>
                            </table></td>
                </tr>
              </table>
            </div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="640" align="left" valign="top">&nbsp;          </td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th width="790" align="center" valign="top" scope="col"><?php include("../foot.php"); ?></th>
  </tr>
</table>
</body>
</html>
