<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("../ecardswa.php");;
$addcattab=true;
$showcattab=true;
$edittab=false;
$deletetab=false;


$msg=$Admin_Add_ECCat;
$sqlcheckcat=mysql_query("select catname from ecardswa_cat where catname='$catname'");
if(!empty($sqlcheckcat)){
$checkrow=mysql_fetch_array($sqlcheckcat);
$existscat = $checkrow["catname"];
}

if($addcat){

if(empty($catname)){
$msg=$Cat_Name_Error;
}
if(empty($cattitle)){
$msg=$Cat_Title_Error;
}
if($existscat){
$msg=$Cat_Name_Exists;
}
else if(($catname) && ($cattitle)){
$SqlAdd=mysql_query("insert into ecardswa_cat(catid,catname,cattitle) values('','$catname','$cattitle') ");
$msg=$Cat_Add_succ;
}
}

if($edit){
$msg=$Cat_Edit;
$addcattab=false;
$showcattab=false;
$edittab=true;
$Sqleditcat=mysql_query("select* from ecardswa_cat where catid='$edit'");
$row=mysql_fetch_array($Sqleditcat);
			  $edit_name=$row["catname"];
			  $edit_title=$row["cattitle"];
			  $edit_id=$row["catid"];


if($editcat){
if(empty($catname)){
$msg=$Cat_Name_Error;
}
if(empty($cattitle)){
$msg=$Cat_Title_Error;
}
else if(($catname) && ($cattitle)){
$Sqlupdate=mysql_query("UPDATE ecardswa_cat SET  catname= '$catname', cattitle= '$cattitle' WHERE catid='$catid'");
$msg=$Cat_Edit_succ;
$addcattab=true;
$showcattab=true;
$edittab=false;
     }
   }
}

if($delete){
$msg=$Cat_delete;
$addcattab=false;
$showcattab=false;
$deletetab=true;
  if($delcat){
   $sqldelete=mysql_query("DELETE FROM ecardswa_cat WHERE  catid='$catid'");
   $msg=$Cat_Delete_succ;
   $addcattab=true;
   $showcattab=true;
   $deletetab=false;
}
}


?>
<html>
<head>
<title>Admin Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="790" align="center">
  <tr>
    <th align="left" valign="top" scope="col"><table width="790" height="731">
      <tr>
        <th width="790" height="100" colspan="2" scope="col"><?php include("head.php"); ?></th>
      </tr>
      <tr>
        <td width="150" height="610" align="left" valign="top"><?php include("navtab.php"); ?></td>
        <td width="640" align="left" valign="top"><table width="600">
          <tr>
            <th width="600" align="center" valign="top" scope="col">			<?php if($addcattab){ ?>              <table width="500" border="1" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
              <tr>
                <th bgcolor="#FFCC99" scope="col"><?php echo"$msg" ?></th>
              </tr>
              <tr>
                <th scope="col"><form action="<?php echo"$PHP_SELF" ?>" method="post">
                  <table width="500">
                    <tr>
                      <th width="146" align="right" valign="top" scope="col"><?php echo"$Cat_name" ?></th>
                      <th width="242" align="left" scope="col"><input name="catname" type="text" size="40">
                      </th>
                    </tr>
                    <tr>
                      <th width="146" align="right" valign="top" scope="col"><?php echo"$Cat_Title" ?></th>
                      <th align="left" scope="col"><input name="cattitle" type="text" value="" size="40" maxlength="100"></th>
                    </tr>
                    <tr>
                      <th scope="col">&nbsp;</th>
                      <th align="left" scope="col"><input name="addcat" type="submit" value="<?php echo"$Cat_Submit_Add" ?>"></th>
                    </tr>
                  </table>
                </form></th>
              </tr>
            </table>
              <?php }  ?></th>
          </tr>
          <tr>
            <th width="600" align="left" valign="top" scope="col">
			
			<?php if($showcattab){ ?><table width="600">
              <tr align="left">
                <th width="440" scope="col"><?php echo"$Ecards_Categories"; ?></th>
                <th width="100" align="center" scope="col"><?php echo"$Admin_Edit"; ?></th>
                <th width="100" align="center" scope="col"><?php echo"$Admin_Delete"; ?></th>
              </tr>
              <?php $Sqlcat=mysql_query("select* from ecardswa_cat");
			  while($row=mysql_fetch_array($Sqlcat)){
			  $cat_name=$row["catname"];
			  $cat_id=$row["catid"];
			   
			   ?>
			  <tr>
                <td width="440" align="left"><a href="<?php echo"$PHP_SELF?edit=$cat_id"; ?>"><?php echo"$cat_name"; ?></a></td>
                <td width="100" align="center"><a href="<?php echo"$PHP_SELF?edit=$cat_id"; ?>"><img src="imgs/edit.gif" width="20" height="20" border="0"></a></td>
                <td width="100" align="center"><a href="<?php echo"$PHP_SELF?delete=$cat_id"; ?>"><img src="imgs/delete.gif" width="11" height="17" border="0"></a></td>
              </tr>
			  <?php 
			   } 
			   ?>
            </table>
			<?php
			 }
			 ?></th>
          </tr>
          <tr>
            <th width="600" align="left" valign="top" scope="col"><?php if($edittab){ ?> <table width="500" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
              <tr>
                <th bgcolor="#FFCC99" scope="col"><?php echo"$msg" ?> </th>
              </tr>
              <tr>
                <th scope="col">
				<form action="<?php echo"$PHP_SELF?edit=true" ?>" method="post">
				<input name="catid" type="hidden" value="<?php echo"$edit" ?> ">
				<table width="500">
                  <tr>
                    <th width="146" align="right" valign="top" scope="col"><?php echo"$Cat_name" ?></th>
                    <th width="242" align="left" scope="col"><input name="catname" type="text" value="<?php echo"$edit_name"; ?>" size="40">
                    </th>
                  </tr>
                  <tr>
                    <th width="146" align="right" valign="top" scope="col"><?php echo"$Cat_Title" ?></th>
                    <th align="left" scope="col"><input name="cattitle" type="text" value="<?php echo"$edit_title"; ?>" size="40" maxlength="60"></th>
                  </tr>
                  <tr>
                    <th scope="col">&nbsp;</th>
                    <th align="left" scope="col"><input name="editcat" type="submit" value="<?php echo"$Cat_Submit_Edit" ?>"></th>
                  </tr>
                </table>
				</form> </th>
              </tr>
            </table>
              <?php }  ?></th>
          </tr>
          <tr>
            <th width="600" align="left" valign="top" scope="col">
			<?php if($deletetab){ ?>
			<table width="400" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
              <tr>
                <th bgcolor="#FFCC99" scope="col"><?php echo"$msg" ?> </th>
              </tr>
              <tr>
                <th scope="col"><table width="400">
                  <tr bordercolor="#CCFFFF">
                    <th width="208" align="right" valign="top" bordercolor="#CCFFFF" scope="col"> <form action="<?php echo"$PHP_SELF?delete=true" ?>" method="post">
                        <input name="catid" type="hidden" value="<?php echo"$delete" ?> ">
                        <table width="100" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <th align="center" scope="col"><input name="delcat" type="submit" value="<?php echo"$Submit_yes"; ?>" >
                            </th>
                          </tr>
                        </table>
                    </form></th>
                    <th width="180" align="left" valign="top" bordercolor="#CCFFFF" scope="col"> <form action="<?php echo"$PHP_SELF?notdel=true" ?>" method="post">
                        <table width="100" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <th scope="col"><input name="notdelcat" type="submit" value="<?php echo"$Submit_no"; ?>" ></th>
                          </tr>
                        </table>
                    </form></th>
                  </tr>
                </table></th>
              </tr>
            </table>
			<?php }  ?></th>
          </tr>
        </table></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th width="790" align="center" valign="top" scope="col"><?php include("../foot.php"); ?></th>
  </tr>
</table>
</body>
</html>
