<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("../ecardswa.php");
$showcattab=true;
$showcardtab=false;
$deletetab=false;
$msg=$Admin_Ecards_Delete;

if($catid){
$msg=$Admin_Ecards;
$showcardtab=true;
$showcattab=false;
}

if($delete){
$msg=$Delete_Card_MSG;
$deletetab=true;
$showcattab=false;
}

if($delcard){
$Sqldelcard=mysql_query("select* from ecardswa_card  where cardid='$card_id'");
			 if(!empty($Sqldelcard)){
			 $rowc=mysql_fetch_array($Sqldelcard);
		     $img=$rowc["cardname"];
			 }
$file="../$ecardsdir$img";
unlink($file);
if(!file_exists($file)){
$sqldelete=mysql_query("DELETE FROM ecardswa_card WHERE  cardid='$card_id'");
  $sqldelete_topecards=mysql_query("DELETE FROM ecardswa_rate WHERE  cardid='$card_id'");
$msg=$Delete_Card_succ;
$deletetab=false;
$showcattab=true;
  }
}

?>
<html>
<head>
<title>Admin Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="790" align="center">
  <tr>
    <th align="left" valign="top" scope="col"><table width="790" height="731">
      <tr>
        <th width="790" height="100" colspan="2" scope="col"><?php include("head.php"); ?></th>
      </tr>
      <tr>
        <td width="150" height="610" align="left" valign="top"><?php include("navtab.php"); ?></td>
        <td width="640" align="left" valign="top"><table width="640">
          <tr>
            <th align="left" valign="top" scope="col">
			<?php if($showcattab){ ?>
			<table width="450" align="center">
              <tr align="left">
                <th width="440" scope="col"><?php echo"$msg";?></th>
                </tr>
                <?php $Sqlcat=mysql_query("select* from ecardswa_cat");
			    if(!empty($Sqlcat)){
			    while($row=mysql_fetch_array($Sqlcat)){
			    $cat_name=$row["catname"];
			    $cat_id=$row["catid"];
			    $Sqlcard=mysql_query("select* from ecardswa_card  where catid='$cat_id'  ");
			    if(!empty($Sqlcard)){
			    $numcard=mysql_num_rows($Sqlcard);
			    }  
			    ?>
			   <tr>
                <td width="440" align="left"><a href="<?php echo"$PHP_SELF?catid=$cat_id"; ?>"><?php echo"$cat_name($numcard)"; ?></a></td>
                </tr>
			   <?php 
			     }
			   } 
			  ?>
             </table>
			<?php
			   }
			?>
		  </th>
          </tr>
          <tr>
            <th align="left" valign="top" scope="col">
              <?php if($showcardtab){ ?>
              <table width="300" align="center">
                <tr align="left">
                  <th width="440" align="center" scope="col"><?php echo"$msg";?></th>
                  <th width="100" align="center" scope="col"><?php echo"$Admin_Delete"; ?></th>
                </tr>
                <?php 
				$sqlcard=mysql_query("select*from ecardswa_card where  catid='$catid' ");
			    if(!empty($sqlcard)){
			    while($rowcard=mysql_fetch_array($sqlcard)){
			    $card_id=$rowcard["cardid"];
			    $cat_id=$rowcard["catid"];
			    $card_name=$rowcard["cardname"];
				
			  ?>
                <tr>
                  <td width="440" align="center" valign="middle"><img src="<?php echo "$host/$ecardsdir$card_name";?>" width="150" height="100" border="0"></td>
                  <td width="100" align="center" valign="middle"><a href="<?php echo"$PHP_SELF?delete=$card_id"; ?>"><img src="imgs/delete.gif" width="11" height="17" border="0"></a></td>
                </tr>
                <?php } } ?>
              </table>
              <?php }  ?>
            </th>
          </tr>
          <tr>
            <th align="center" valign="top" scope="col">
              <?php if($deletetab){ ?>
              <table width="400" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
                <tr>
                  <th bgcolor="#FFCC99" scope="col"><?php echo"$msg" ?> </th>
                </tr>
                <tr>
                  <th scope="col"><table width="400">
                    <tr bordercolor="#CCFFFF">
                      <th width="208" align="right" valign="top" bordercolor="#CCFFFF" scope="col"> <form action="<?php echo"$PHP_SELF" ?>" method="post">
                          <input name="card_id" type="hidden" value="<?php echo"$delete" ?> ">
                          <input name="image" type="hidden" value="<?php echo"$img" ?> ">
                          <table width="100" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <th align="center" scope="col"><input name="delcard" type="submit" value="<?php echo"$Submit_yes"; ?>" >
                              </th>
                            </tr>
                          </table>
                      </form></th>
                      <th width="180" align="left" valign="top" bordercolor="#CCFFFF" scope="col"> <form action="<?php echo"$PHP_SELF?notdel=true" ?>" method="post">
                          <table width="100" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <th scope="col"><input name="notdelcat" type="submit" value="<?php echo"$Submit_no"; ?>" ></th>
                            </tr>
                          </table>
                      </form></th>
                    </tr>
                  </table></th>
                </tr>
              </table>
              <?php }  ?>
            </th>
          </tr>
        </table></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th width="790" align="center" valign="top" scope="col"><div align="center">
      <p>&nbsp;</p>
      <?php include("../foot.php"); ?></div></th>
  </tr>
</table>
</body>
</html>
