<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("../ecardswa.php");

$msg=$Admin_Add_Ecards;

if($load){
if(is_uploaded_file($HTTP_POST_FILES['filename']['tmp_name'])==1){

$arr=getimagesize($filename);
$image=date("dmyhis");
if($arr[2]==1){
$imagename="$image.gif";
}     
if($arr[2]==2){
$imagename="$image.jpg";

}
if($arr[2]==3){
$imagename="$image.png";
}
if($arr[0] > $cardwidth){
$msg=$Ecards_Width_Error.$cardwidth."px";
}

if($arr[1] > $cardheight){
$msg=$Ecards_Height_Error.$cardheight."px";
}

if(($arr[0] <= $cardwidth) && ($arr[1] <= $cardheight) ){
   if(($arr[2]==1) or ($arr[2]==2) or ($arr[2]==3) ){ 
     if($HTTP_POST_FILES['filename']['size'] > $maxsize){

			$msg=$Ecard_Size_Error;

	 }
	 else
     {

      if(move_uploaded_file($HTTP_POST_FILES['filename']['tmp_name'], "../$ecardsdir$imagename")){
      $sqlAddimage=mysql_query("INSERT INTO ecardswa_card (cardid,catid,cardname) values('','$cards_cat','$imagename')");
      $msg=$imagename." ".$Ecard_Add_Succ;
         }
	   }
    }
 else
{
  $msg=$Ecard_Type_Error;
     }
    }
   }
 }

?>
<html>
<head>
<title>Admin Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="790" align="center">
  <tr>
    <th align="left" valign="top" scope="col"><table width="790" height="731">
      <tr>
        <th width="790" height="100" colspan="2" scope="col"><?php include("head.php"); ?></th>
      </tr>
      <tr>
        <td width="150" height="610" align="left" valign="top"><?php include("navtab.php"); ?></td>
        <td width="640" align="left" valign="top"><table width="640">
          <tr>
            <th align="center" valign="top" scope="col"><table width="500" border="1" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
              <tr>
                <th align="center" bgcolor="#FFCC99" scope="col"><?php echo"$msg"; ?></th>
              </tr>
              <tr>
                <td align="center" valign="top" bordercolor="#FFCC00">
                  <form action="<?php echo"$PHP_SELF" ?>" method="post" enctype="multipart/form-data">
                    <table width="400">
                      <tr>
                        <th width="100" scope="col"><?php echo"$Ecard_file" ?></th>
                        <th align="left" scope="col"><input name="filename" type="file" size="32"></th>
                      </tr>
                      <tr>
                        <th scope="col"><?php echo"$Cat_name" ?></th>
                        <th align="left" valign="top" scope="col"><select name="cards_cat">
                            <?php 
			                $Sqlcat=mysql_query("select* from ecardswa_cat order by catname");
			                if(!empty($Sqlcat)){
			  
			                while($row=mysql_fetch_array($Sqlcat)){
			                $cat_name=$row["catname"];
			                $cat_id=$row["catid"];
			                ?>
                          <option value="<?php print "$cat_id" ?>"><?php print "$cat_name";?></option>
                          <?php
						     }
						   }
						  ?>
                         </select></th>
                        </tr>
                      <tr>
                        <th width="100" scope="col">&nbsp;</th>
                        <th width="262" align="center" valign="top" scope="col"><input name="load" type="submit" value="<?php echo "$Ecard_Submit" ?>"></th>
                        </tr>
                    </table>
                </form></td>
              </tr>
            </table></th>
          </tr>
        </table></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th width="790" align="center" valign="top" scope="col"><?php include("foot.php"); ?></th>
  </tr>
</table>
</body>
</html>
