<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("../ecardswa.php");
$tabsent=true;
$start=0;
$end=$sent_result;

$sqlsent=mysql_query("select* from  ecardswa_post");
if(!empty($sqlsent)){
$numsent=mysql_num_rows($sqlsent);
$msg=$numsent." ".$Admin_Ecards_Sent;
}

if($deletepost){
$msg=$Cat_delete;
$tabsent=false;
$tabdelete=true;
}

if($delpost){
$sqldelete=mysql_query("DELETE FROM ecardswa_post where postid='$idpost'");
$msg=$Sent_Ecards_Deletesucc;
$tabsent=true;
$tabdelete=false;

}

?>
<html>
<head>
<title>Admin Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="790" align="center">
  <tr>
    <th align="left" valign="top" scope="col"><table width="790">
      <tr>
        <th width="790" height="100" colspan="2" scope="col"><?php include("head.php"); ?></th>
      </tr>
      <tr>
        <td width="150" rowspan="2" align="left" valign="top"><?php include("navtab.php"); ?></td>
        <td width="640" align="left" valign="top"><table width="640" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th scope="col"><?php echo"$msg" ?></th>
          </tr>
          <tr>
            <td align="center">
			<?php if($tabsent){ 
			 if(isset($result)){
				  if($result==1){
				  $end=$sent_result;
                  $start=0;
				  
				  }else if($sent_result >=2){
				  $m=$result-1;
			      $end=+$sent_result;
                  $start=$m*$end;
				  } 
                  }

           
            $sqlsent2=mysql_query("select* from ecardswa_post p, ecardswa_user u where p.userid=u.userid order by  postdate DESC LIMIT $start,$end ");
			if(!empty($sqlsent2)){
			$numuser2=mysql_num_rows($sqlsent2);
			while($rowsent=mysql_fetch_array($sqlsent2)){
			$post_id=$rowsent["postid"];
			$post_code=$rowsent["postcode"];
			$to_name=$rowsent["toname"];
			$to_email=$rowsent["toemail"];
			$sender_name=$rowsent["username"];
			$sender_email=$rowsent["uemail"];
			$post_date=$rowsent["postdate"];
			$p_status=$rowsent["pstatus"];
			
			if($p_status==1){
			$pikup=$Pickup_yes;
			}else{
			$pikup=$Pickup_no;
			}
			
			?>
			<table width="640" border="0" cellspacing="0" cellpadding="0">
              <tr bgcolor="#FFFFFF">
                <td width="100" align="left" valign="top"><strong><?php echo"$Sent_To_Name" ?></strong></td>
                <td width="240" align="left" valign="top"><?php echo"$to_name" ?></td>
                <td width="100" align="right" valign="top"><strong><?php echo"$Sent_Ecards_Date" ?></strong></td>
                <td width="100" align="left" valign="top"><?php echo"$post_date" ?></td>
                <td width="60" align="center"><a href="<?php echo"$PHP_SELF?deletepost=$post_id";?>"><?php echo"$Admin_Delete" ?></a></td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="100" align="left" valign="top"><strong><?php echo"$Sent_To_Mail" ?></strong></td>
                <td width="240" align="left" valign="top"><?php echo"$to_name" ?></td>
                <td width="100" align="right" valign="top"><strong><?php echo"$Sent_Ecards_Pickup" ?></strong></td>
                <td width="100" align="left" valign="top"><?php echo"$pikup" ?></td>
                <td width="60">&nbsp;</td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="100" align="left" valign="top"><strong><?php echo"$Sent_Sender_Name" ?></strong></td>
                <td width="240" align="left" valign="top"><?php echo"$sender_name" ?></td>
                <td width="100" align="right" valign="top"><strong><?php echo"$Sent_Ecards_PostId" ?></strong></td>
                <td width="100" align="left" valign="top"><?php echo"$post_id" ?></td>
                <td width="60">&nbsp;</td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="100" align="left" valign="top"><strong><?php echo"$Sent_Sender_Mail" ?></strong></td>
                <td width="240" align="left" valign="top"><?php echo"$sender_email" ?></td>
                <td width="100" align="right" valign="top"><strong><?php echo"$Sent_Ecards_PostCode" ?></strong></td>
                <td width="100" align="left" valign="top"><?php echo"$post_code" ?></td>
                <td width="60">&nbsp;</td>
              </tr>
              
			  <tr>
                <td colspan="5" bgcolor="#3366CC">&nbsp;</td>
              </tr>
            </table>
			<table width="10" border="0" align="center" cellpadding="0" cellspacing="5" >
              <tr>
                <?php 
				} 
				}
		       if ($numsent > $sent_result){
						 $div=$numsent/$sent_result;
						 if(!is_int($div)){
						 $div=ceil($div);
						 }
						 $arr=range(1,$div);
						 foreach($arr as $elem) { ?>
                <th scope="col"><a href="<?php echo "$PHP_SELF?result=$elem"; ?>" ><?php echo "$elem"; ?></a></th>
                <?php } } ?>
              </tr>
            </table>
			<table border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="50" align="center"><?php if ($totalnum >$sent_result ){ print "$Site" ; } ?></td>
                <td><table width="10" border="0" cellspacing="5" cellpadding="0">
                    <tr>
                      <?php  
		     if ($totalnum > $history_result){
						 $div=$totalnum/$sent_result;
						 if(!is_int($div)){
						 $div=ceil($div);
						 }
						 $arr=range(1,$div);
						 foreach($arr as $elem) { ?>
                      <th scope="col"><a href="<?php echo "$PHP_SELF?result=$elem";  ?>" ><?php print "$elem"; ?></a></th>
                      <?php } } ?>
                            </table></td>
              </tr>
            </table>
			<?php  }?></td>
          </tr>
          <tr>
            <td align="center">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td align="left" valign="top">
		<?php if($tabdelete){ ?>
		<table width="400" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFCC00">
          <tr>
            <th scope="col">
              <table width="400">
                <tr bordercolor="#CCFFFF">
                  <th width="208" align="right" valign="top" bordercolor="#CCFFFF" scope="col">
                    <form action="<?php echo"$PHP_SELF?deleteuser=true" ?>" method="post">
                      <input name="idpost" type="hidden" value="<?php echo"$deletepost" ?> ">
                      <table width="100" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <th align="center" scope="col"><input name="delpost" type="submit" value="<?php echo"$Submit_yes"; ?>" >
                          </th>
                        </tr>
                      </table>
                  </form></th>
                  <th width="180" align="left" valign="top" bordercolor="#CCFFFF" scope="col">
                    <form action="<?php echo"$PHP_SELF" ?>" method="post">
                      <table width="100" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <th scope="col"><input name="notdelcat" type="submit" value="<?php echo"$Submit_no"; ?>" ></th>
                        </tr>
                      </table>
                  </form></th>
                </tr>
            </table></th>
          </tr>
        </table>
		<?php }  ?></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th width="790" align="center" valign="top" scope="col"><?php include("../foot.php"); ?></th>
  </tr>
</table>
</body>
</html>
