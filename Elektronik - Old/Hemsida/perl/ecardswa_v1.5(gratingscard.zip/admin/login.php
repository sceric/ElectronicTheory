<?php
session_start();

if (!isset ($_SESSION["admin_id"]))

{
  header ("Location:log_in.php?login=missing");
}

include("../config.php");
mysql_connect($dbhost,$dbuser,$dbpass) or die("Error:: can't connect to database");
@mysql_select_db( "$dbname") or die( "Error:: there is no database like $dbname");


if($log){
$sqllog=mysql_query(" SELECT  * FROM  ecardswa_admin WHERE adminname='$loginname' AND adminpass=password('$passwd') ");
if($sqllog){

$row=mysql_fetch_array($sqllog);
$rowid=$row["adminid"];
} 

$num=mysql_num_rows($sqllog);
if($num > 0){

$_SESSION["admin_id"]=$row["adminid"];
   header ("Location: index.php");
 }
 else
 {
  header ("Location: log_in.php?login=wrong");
 }
 
 }
?>
