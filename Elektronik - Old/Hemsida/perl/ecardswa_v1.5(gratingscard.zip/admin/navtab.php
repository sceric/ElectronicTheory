<table width="150" border="1" cellpadding="0" cellspacing="0" bordercolor="#FF9900" bgcolor="#FFCC99">
  <tr>
    <th scope="col"><a href="index.php"><?php echo"$Admin_Home"; ?></a></th>
  </tr>
  <tr>
    <td><a href="user.php"><?php echo"$Admin_User"; ?> </a> </td>
  </tr>
  <tr>
    <td><a href="cardscat.php"><?php echo"$Admin_Category"; ?></a></td>
  </tr>
  <tr>
    <td></a><a href="addcards.php"><?php echo"$Admin_Add_Ecards"; ?></a></td>
  </tr>
  <tr>
    <td><a href="deletecards.php"><?php echo"$Admin_Ecards_Delete"; ?></a></td>
  </tr>
  <tr>
    <td><a href="sent.php"><?php echo "$Admin_Ecards_Sent" ?></a></td>
  </tr>
</table>

