<?php 
include("../ecardswa.php");


$msg=$Admin_log_MSG;
if($login=="wrong"){
$msg=$Admin_logError_MSG;
}
else if($login=="missing"){
$msg=$Admin_Notlog_MSG;
}
?>


<html>
<head>
<title>Login Aray</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body> 
<table width="790" height="400" align="center">
  <tr>
    <th align="center" valign="middle" scope="col"><table width="300" height="50" border="1" align="center" cellspacing="0" bordercolor="#FF6600">
      <tr>
        <th height="50" scope="col">
		<form action="login.php" methode="post">
		 <table width="300" height="50" bordercolor="#FF9900">
          <tr bgcolor="#33CCFF">
            <th colspan="2" scope="col"><?php echo"$msg" ?></th>
          </tr>
          <tr>
            <td width="100" align="right" valign="top" bgcolor="#33CCFF"><strong>Login:</strong></td>
            <td width="200" bgcolor="#33CCFF"><input name="loginname" type="text"></td>
          </tr>
          <tr>
            <td align="right" valign="top" bgcolor="#33CCFF"><strong>Password:</strong></td>
            <td bgcolor="#33CCFF"><input name="passwd" type="password"></td>
          </tr>
          <tr align="center" valign="top" bgcolor="#33CCFF">
            <td colspan="2"><input name="log" type="submit" value="go"></td>
          </tr>
        </table>
		</form>
		</th>
      </tr>
    </table></th>
  </tr>
</table>
</body>
</html>
