<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("../ecardswa.php");
$sql_admin=mysql_query("select*from ecardswa_admin where adminid='$admin_id' ");
if(!empty($sql_admin)){
$row=mysql_fetch_array($sql_admin);
$name=$row["adminname"];
}

?>
<html>
<head>
<title>Admin Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="790" align="center">
  <tr>
    <th align="left" valign="top" scope="col"><table width="790" height="731">
      <tr>
        <th width="790" height="100" colspan="2" scope="col"><?php include("head.php"); ?></th>
      </tr>
      <tr>
        <td width="150" height="610" align="left" valign="top"><?php include("navtab.php"); ?></td>
        <td width="640" align="center" valign="top"> <p>&nbsp;</p>
          <?php  echo"$hello $name";?></td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th align="center" valign="top" scope="col"><?php include("../foot.php"); ?></th>
  </tr>
</table>
</body>
</html>
