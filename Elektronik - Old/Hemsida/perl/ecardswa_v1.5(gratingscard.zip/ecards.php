<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("ecardswa.php");
include("connect.php");
include("session.php");
$ceil=4;
$tabout=true;
$tabempty=false;
$tabcatname=true;
$end=$ecards_result;
$start=0;

if($catid){
$sqlcard=mysql_query("SELECT * FROM ecardswa_cat where catid = '$catid'");
if(!empty($sqlcard)){
$rowcard=mysql_fetch_array($sqlcard);
$cattitle=$rowcard["cattitle"];
$catname=$rowcard["catname"]; 
 }
}

 if(isset($result)){
				  if($result==1){
				  $end=$ecards_result;
                  $start=0;
				  
				  }else if($result >=2){
				  $m=$result-1;
			      $end=+$ecards_result;
                  $start=$m*$end;
				  } 
                  }

$Sqlout=mysql_query("select*from ecardswa_card where catid = '$catid'  LIMIT $start , $end ");
$Sqlouttotal=mysql_query("select*from ecardswa_card where catid = '$catid' ");

if(!empty($Sqlouttotal)){
$totalnum=mysql_num_rows($Sqlouttotal);
}

if(!empty($Sqlout)){
$numout=mysql_num_rows($Sqlout);
if($numout==0){
$tabout=false;
$tabempty=true;
$tabcatname=true;
}
$out=$numout;
}




?>

<html>
<head>
<title><?php print "$catname"."$cattitle"; ?></title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Stil2 {	font-size: 12px;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="500" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="150" align="left" valign="top" scope="col"><table width="149" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th align="center" scope="col"><?php include("tablogin.php") ?></th>
          </tr>
          <tr>
            <td align="center"><?php include("tabcat.php") ?></td>
          </tr>
        </table></th>
        <th width="550" align="center" valign="top" scope="col"><table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th width="500" align="center" scope="col"><p>
              <?php  if ($tabcatname){ ?>
			   </p>
              <table width="350">
                <tr>
                  <td align="center" valign="middle"><?php echo"<img src='imgs/dir.gif'> $catname";?></td>
                </tr>
              </table>
			  <?php } ?> </th>
          </tr>
          <tr>
            <td width="500" align="left">
			<?php if($tabout){ ?>	<table width="510" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td width="500" align="left"><table width="100" border="0" align="center" cellpadding="0" cellspacing="10">
                <?php 
	            $sqlcats=mysql_query("select * from ecardswa_cat  order by  catname ");
	            $i = 1;
                echo"<tr>";
	           if($numout >=1){
	           while($rowecard=mysql_fetch_array($Sqlout)){
	           $card_id=$rowecard["cardid"];
	           $card_name=$rowecard["cardname"];
	 	 
	           ?>
               <th align="center" valign="top" scope="col"><a href="<?php echo"card.php?cardid=$card_id";?>"><img src="<?php echo"$ecardsdir$card_name";?>" width="90" height="100" border="0"></a></th>
               <?php if (is_int($i / $ceil))
	           echo  "</tr>";
               $i++;
                   }
                 } 
               ?>
                </table></td>
              </tr>
            </table>
			<table border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td width="50" align="center"><?php if ($totalnum > $ecards_result ){ echo  "$Site" ; } ?></td>
                <td><table width="10" border="0" cellspacing="5" cellpadding="0">
                    <tr>
                      <?php  
		     if ($totalnum > $ecards_result){
						 $div=$totalnum/$ecards_result;
						 if(!is_int($div)){
						 $div=ceil($div);
						 }
						 $arr=range(1,$div);
						 foreach($arr as $elem) { ?>
                      <th scope="col"><a href="<?php echo "$PHP_SELF?catid=$catid&result=$elem";  ?>" ><?php echo "$elem"; ?></a></th>
                      <?php } } ?>
                          </table></td>
              </tr>
            </table>
			<?php } ?></td>
          </tr>
          <tr>
            <td width="500"><?php if($tabempty){ ?>
              <table width="510" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="500" align="center"><?php echo"$EC_Empty_Cat"?></td>
                </tr>
              </table>
              <?php } ?></td>
          </tr>
        </table>        
      
        </table>          
    <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p></th>    
  </tr>
      <tr>
        <td colspan="2" align="center"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
