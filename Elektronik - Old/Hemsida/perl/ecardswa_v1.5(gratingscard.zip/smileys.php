<?php 
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
?>
<script language="JavaScript" type="text/javascript">
function emoticon(text) {
	var txtarea = document.post.postmsg;
	text = ' ' + text + ' ';
	if (txtarea.createTextRange && txtarea.caretPos) {
		var caretPos = txtarea.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? caretPos.text + text + ' ' : caretPos.text + text;
		txtarea.focus();
	} else {
		txtarea.value  += text;
		txtarea.focus();
	}
}

</script>

<center>
</center>
<div align="left">
  <table width="250" border="0" cellspacing="0" cellpadding="5">
    <tr align="center" valign="middle">
      <td width="50"><a href="javascript:emoticon('s1:-)')"><img src="smileys/1.gif" border="0"></a></td>
      <td width="50"><a href="javascript:emoticon('s2:-)')"><img src="smileys/2.gif" border="0"></a></td>
      <td width="50"><a href="javascript:emoticon('s3:-)')"><img src="smileys/3.gif" border="0"></a></td>
      <td width="80"><a href="javascript:emoticon('s4:-)')"><img src="smileys/4.gif" border="0"></a></td>
      <td width="80"><a href="javascript:emoticon('s5:-)')"><img src="smileys/5.gif" border="0" ></a></td>
    </tr>
    <tr align="center" valign="middle">
      <td width="50"><a href="javascript:emoticon('s6:-)')"><img src="smileys/6.gif" border="0" ></a></td>
      <td width="50"><a href="javascript:emoticon('s7:-)')"><img src="smileys/7.gif" border="0" ></a></td>
      <td width="50"><a href="javascript:emoticon('s8:-)')"><img src="smileys/8.gif" border="0" ></a></td>
      <td width="80"><a href="javascript:emoticon('s9:-)')"><img src="smileys/9.gif" border="0" ></a></td>
      <td width="80"><a href="javascript:emoticon('s10:-)')"><img src="smileys/10.gif" border="0"></a></td>
    </tr>
    <tr align="center" valign="middle">
      <td width="50"><a href="javascript:emoticon('s11:-)')"><img src="smileys/11.gif" border="0"></a></td>
      <td width="50"><a href="javascript:emoticon('s12:-)')"><img src="smileys/12.gif" width="31" height="31" border="0" ></a></td>
      <td width="50"><a href="javascript:emoticon('s13:-)')"><img src="smileys/13.gif" width="20" height="30" border="0" ></a></td>
      <td width="80"><a href="javascript:emoticon('s14:-)')"><img src="smileys/14.gif" width="65" height="50" border="0" ></a></td>
      <td width="80"><a href="javascript:emoticon('s15:-)')"><img src="smileys/15.gif" width="81" height="26" border="0" ></a></td>
    </tr>
  </table>
</div>
