<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="Ecardswa v1.5 represents THE ideal solution for a greeting-card-shipment-service with many features: User registration, history, attractive shipment options, full administration etc">
<meta name="keywords" content="php , php scripts, php script,  ">
<meta name="robots" content="all">
<meta name="robots" content="index">
<meta name="robots" content="follow">
<meta name="page-topic" content="IT">
<meta name="Microsoft Border" content="GENERATOR">
<meta name="content-language" content="en">
