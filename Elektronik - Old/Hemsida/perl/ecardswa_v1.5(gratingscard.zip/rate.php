<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("login.php");
include("ecardswa.php");
$tabcard=true;
$tabrate=true;
$ip=$REMOTE_ADDR;
$rate_date=date("y-m-d");

if($rateit){
$sql_rate=mysql_query("INSERT INTO ecardswa_rate(cardid,cardip,cardpoints,ratedate) VALUES ('$id_card', '$ip', '$rate', NOW())");
$tabrate=false;
$tabcard=false;
$msg=$Rate_ECsucc;
}



if($id){
$sqlcheck_card=mysql_query("select * from ecardswa_rate  where  cardid='$id'  AND cardip='$ip' AND ratedate='$rate_date' ");
if(!empty($sqlcheck_card)){
$numcard=mysql_num_rows($sqlcheck_card);
}

if($numcard==1){
$msg=$Rate_EC_Error;
$tabrate=false;
}else if ($numcard==0){
$msg=$Rate_EC_MSG;
 }
}



$sql_card=mysql_query("select*from ecardswa_card where cardid='$id'");
if(!empty($sql_card)){
$row=mysql_fetch_array($sql_card);
$card=$row["cardname"];
}



?>

<html>
<head>
<title>Ecardswa v1.5 </title>
<?php include("metatag.php"); ?>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="700" height="150" align="center" valign="top" scope="col"><?php include("head.php"); ?></th>
  </tr>
  <tr>
    <td width="700" height="500" align="left" valign="top" background="imgs/main_bc.jpg"><table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="150" align="left" valign="top" scope="col"><table width="149" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th align="center" scope="col"> <?php include("tablogin.php") ?></th>
          </tr>
          <tr>
            <td align="center"><?php include("tabcat.php") ?></td>
          </tr>
        </table></th>
        <th width="550" align="center" valign="top" scope="col"><table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="500" align="center"><table  width="500" border="0" align="center" cellpadding="0" cellspacing="0" >
              <tr>
                <th width="500" height="125" align="center" valign="top" scope="col"><table width="500" border="0" cellspacing="2" cellpadding="0">
                  <tr>
                    <td align="center"><?php echo"$msg"; ?></td>
                  </tr>
                  <tr>
                    <td>
                      <table width="500" border="0" cellspacing="0" cellpadding="0">	
						<tr>
                          <td align="center">
			                <?php if($tabrate){ ?>
							<table width="300" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
                              <tr>
                                <td align="center" bgcolor="#FFCC99"><?php echo"$Rate_EC_MSG2"; ?></td>
                              </tr>
                              <tr>
                                <td align="right" valign="top">
								<form action="<?php echo"$PHP_SELF";?>" method="post">
								<input name="id_card" type="hidden" value="<?php echo"$id";?>">
								<table width="250">
                                  <tr>
                                    <td> 
                                   <SELECT name="rate" size="1"> 
                                   <option value="1">1</option>
								   <option value="2">2</option>
								   <option value="3">3</option>
								   <option value="4">4</option>
								   <option value="5">5</option>
								   <option value="6">6</option>
								   <option value="7">7</option>
								   <option value="8">8</option>
								   <option value="9">9</option>
								  <option value="10" selected>10</option>
								   </SELECT> 
                                   <input name="rateit" type="submit" value="<?php echo"$Rate_EC_Vote"?>">
								   </td>
                                  </tr>
                                </table>
								</form>
								
								</td>
                              </tr>
                            </table>
							<?php } 
						   ?></td>
                        </tr>
                      </table>
					  
                      </td>
                  </tr>
                  <tr>
                    <td width="500" align="center">
					<?php if($tabcard){ ?>
					<table  width="400" cellpadding="0" cellspacing="0" bordercolor="#FF9900" >
                      <tr>
                        <th width="400" align="center" valign="top" scope="col"><img src="<?php echo"$ecardsdir$card";?>"></th>
                      </tr>
                    </table>
					<?php }  ?></td>
                  </tr>
                </table></th>
              </tr>
            </table></td>
          </tr>
        </table>        
      </table>          
    </tr>
      <tr>
        <td colspan="2" align="center" valign="bottom"><table width="700">
          <tr>
            <td width="150">&nbsp;</td>
            <td width="550" align="center"><?php include("foot.php"); ?></td>
          </tr>
        </table></td>
      </tr>
</table>
</td>
  </tr>
</table>
</body>
</html>
