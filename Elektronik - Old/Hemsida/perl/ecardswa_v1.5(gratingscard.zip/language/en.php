<?php 

/* head.php */
$Home_Button="Home";
$Account_Button="Account";
$History_Button="History";
$Favorites_Button="Favorites";
$Top_EC_Button="Top Ecards";
$New_EC_Button="New Ecards";
$new_reg="New registration.";
$get_pass="Forgot password?";
$hello="Hello";
$Welcome="Welcome to";
$Categories="Categories";
$Site="Site";
$Members_Login="Members Login";

/*newuser.php && getpass.php */
$New_Register="New registration";
$Reg_Name="Username:";
$Reg_Pass="Password:";
$Reg_Pass_Repeat="Repeat password:";
$Reg_Email="Email address:";
$Reg_Fast="New registration";
$Reg_MSG="* Please fill in all fields. "
."<br>"."* After your successful registration you will receive a registration 
key to the provided email-address.";
$Reg_Succ_MSG="Your registration was successful.";
$Reg_Thanks_MSG="Thank you for your registration. The registration key was sent to the provided email address.";
$Reg_Name_Error="Error: User name is missing.";
$Reg_Name_Exists="Error: User name already exists. Please choose another user name.";
$Reg_Email_Exists="Error: This email address already exists. Please choose  another email address.";
$Reg_Pass_Error="Error: Password is missing.";
$Reg_Pass_Repeat_Error="Error: The passwords do not match.";
$Reg_Email_Error="Error: Email address is missing.";
$Reg_Smalname_Error="Error: The user name must have more than 6 characters.";
$Reg_Blank_Error="Error: user name must be just letters or digits.";
$Reg_Code="Registration key:";
$Reg_Register_Submit="Registrieren";
$Reg_Mail_supject="Registration key";
$Reg_Mail_MSG="Thank you for your registration. PLease click the following link and
enter your registration key for your activation.";
$Reg_Your_Access_Data="Your access-data";
$Reg_Signatur_MSG="Best Regards";
$Get_Pass_MSG="Please enter your email address in the following field:";
$Get_Pass_Error="Error: The provided email address could not be found.";
$Get_Pass_Send="Your new password was sent to the provided email address.";
$Get_Pass_Submit="Send";
$Get_Pass_MailSubject="Your new password";
$Get_Pass_MailMSG="You receive this message because you have requested a new password from us via email.";

/* getaccount.php */
$Get_Account_MSG="Please enter your registration key in the following field:";
$Get_Account_Succ="Your account is activated. Now you can log-in.";
$Get_Code_Error="Error: The registration key is not correct.";
$Get_id_Error="Error: Wrong ID.";
$Get_Submit_MSG="Activate";

/* favorites.php */
$Fav_MSG="Your favorite E-cards.";
$Fav_Empty_MSG="There are no E-Cards in your favorite .";
$Fav_Add_EC="E-Cards has been added to your favorite";
$Fav_Add_EC_Exist="E-Cards already exists in your favorite.";
$Fav_Delete_EC="really delete?";
$Fav_Delete="delete";
$Fav_Delete_ECsucc="E-Cards has been deleted ";

/* card.php*/
$Card_Send_MSG="send";
$Card_RateIt_MSG="rate it";
$Card_AddToFavorites_MSG="add to favorite";

/* rate.php */
$Rate_EC_MSG="E-cards rating";
$Rate_EC_MSG2="10 is the best rating.";
$Rate_ECsucc="Thank you for rating.";
$Rate_EC_Error="You seem to have already voted once before.";
$Rate_EC_Vote="rate it";

/* topecards.php & newecards.php  */
$New_EC_MSG="New E-cards";
$Top_EC_MSG="Top E-Cards";

/* log_in.php &logout.php */
$log_MSG="Login";
$log_Notlog_MSG="This service is for members only.";
$log_Error_MSG="Your access-data are not correct.";
$log_out="Log off";

/*account.php */ 
$Acc_Update_log="Change access data.";
$Acc_Updatelog_succ="Your access data were successfully changed.";
$Acc_Submit_Updatelog="Change";

/*ecards.php & history.php */ 
$EC_Empty_Cat="There are no greeting-cards in this category.";
$EC_From_TotalNums="From";
$history_Empty_MSG="Empty";
$history_Delete="delete";
$history_Delete_MSG="Really delete?";
$history_Delete_ECsucc="E-card has been deleted.";
$history_Sent_Ecards="sent E-cards";

/* sendcard.php */
$Send_EC_MSG="Please fill in completely all fields.";
$Send_EC_MSGEmpty="You did not choose a greeting card.";
$Send_EC_Empty="The greeting card chosen was not found.";
$Send_To_Mail="Receiver email:";
$Send_To_Name="Receiver name:";
$Send_Sender_Mail="Sender email:";
$Send_Sender_Name="Sender name:";
$Send_EC_Subject="Subject:";
$Send_EC_MSGtext="Message:";
$Send_EC_Send="Send";
$Send_EC_Show="Preview";
$Send_EC_Edit="Edit";
$Send_EC_Stamp="Stamp";
$Send_EC_layout="Layout";
$Send_EC_FontColor="Font colour";
$Send_EC_FontFace="Font type";
$Send_EC_BackgroundColor="Background colour";
$Send_EC_Setting="Settings";
$Send_EC_MailSubjekt="You got a greeting card.";
$Send_EC_MailMSG="You got a greeting card. Click on the below link to collect your card.";
$Send_To_Mail_Error="Error: Receiver email-address is missing or not correct.";
$Send_To_Name_Error="Error: Receiver name is missing.";
$Send_Sender_Mail_Error="Error: Sender email-address is missing or not correct.";
$Send_Sender_Name_Error="Error: Sender name is missing.";
$Send_EC_Subject_Error="Error: Subject is missing." ;
$Send_EC_MSGtext_Error="Error: Message is missing.";
$Send_EC_MSG_succ="The greeting card has been sent successfully.";
$Send_EC_succ="The greeting card has been  sent successfully. You will be automatically notified as soon as the greeting card will be picked-up.";
$Send_EC_Next="[Send another greeting card?]";
$View_EC_Answer="Reply with a greeting card?";
$View_EC_Error="Error: The greeting card could not be displayed.";
$View_EC_PickupSubject=" your ecard is picked-up";
$View_EC_PickupMSG="your ecard is picked-up click at the Link to see your ecards agin";


/* Admin Pages */
$Admin_Edit="Edit";
$Admin_Delete="Delete";
$Submit_yes="Yes";
$Submit_no="No";

/* log_in.php*/
$Admin_log_MSG="Admin area";
$Admin_Notlog_MSG="You are not registered for the admin area.";
$Admin_logError_MSG="Error: Your access-data are not correct.";

/*navtab.php */
$Admin_Home="Home";
$Admin_User="Users";
$Admin_Search_User="Search user";
$Admin_Category="Categories";
$Admin_Ecards="cards";
$Admin_Add_ECCat="Add category";
$Admin_Add_Ecards="Add cards";
$Admin_Ecards_Delete="Delete cards";
$Admin_Ecards_Sent="cards sent";

/* addcards.php , cardscat.php */
$Cat_name="Category name:";
$Cat_Title="Category title:";
$Cat_Name_Error="Error: Category name is missing.";
$Cat_Title_Error="Error: Category title is missing.";
$Cat_Name_Exists="This category already exits.";
$Cat_Add_succ="Category has been added.";
$Cat_Submit_Add="Add";
$Cat_Submit_Edit="Edit";
$Cat_Edit="Edit category.";
$Cat_Edit_succ="Category has been  edited.";
$Cat_delete="Really delete?";
$Cat_Delete_succ="Category has been deleted .";
$Cat_Empty_MSG="There are still no categories added.";
$Ecards_Categories="Greeting-card-categories.";
$Ecards_Width_Error="Error: Width of greeting card must not exceed ";
$Ecards_Height_Error="Error: Height of greeting card must not exceed "; 
$Ecard_file="Image file";
$Delete_Card_MSG="Really delete?";
$Delete_Card_succ="Card has been deleted .";
$Ecard_Submit="Up-load";
$Ecard_Size_Error="Error: Image file is too big.";
$Ecard_Add_Succ="Image file has been uploaded.";
$Ecard_Type_Error="Error: You may load .jpg, .gif und .png image formats only.";
$Sent_Ecards_Date="Date:";
$Sent_Ecards_Pickup="Pick-up:";
$Sent_Ecards_PostId="ID:";
$Sent_Ecards_PostCode="Code:";
$Sent_Ecards_Deletesucc="E-card has been deleted .";
$Pickup_yes="Yes";
$Pickup_no="No";

/* user.php , searchusr.php  */
$Admin_SearchUser_MSG="Search user";
$Admin_SearchUser_Error="No result for the term searched.";
$Admin_User_MSG="User";
$Admin_User_delete="Delete";
$Admin_User_deleteMSG="really delete?";
$Admin_User_deleteSucc="User has been deleted.";
$Admin_User_Email="Email-address";
$Admin_User_date="Since";
$yes="yes";
$no="no";
?>