<?php 
/* head.php */
$intromsg="ecardswa_v1.5 Testsoftware";
$Home_Button="Home";
$Account_Button="Account";
$History_Button="History";
$Favorites_Button="Favorites";
$Top_EC_Button="Top Ecards";
$New_EC_Button="Neue Ecards";
$new_reg="neu registrieren";
$get_pass="Passwort vergessen";
$hello="Hallo";
$Welcome="Willkommen";
$Categories="Kategorien";
$Site="Seite";
$Members_Login="Members Login";
/* newuser.php && getpass.php*/
$New_Register="New registration";
$Reg_Name="Username";
$Reg_Pass="Passwort:";
$Reg_Pass_Repeat="Passwort wiederholen:";
$Reg_Email="E-mail-Adresse:";
$Reg_MSG="-> Bitte alle Felder vollst�ndig ausf�llen. ".
"<br>"."-> Ihre Email-Adresse muss korrekt sein.".
  "<br>"."-> Nachdem Sie sich erfolgreich angemeldet haben wird ein 
Freischaltungscode an die angegebene Email-Adresse geschickt.";
$Reg_Succ_MSG="Die Anmeldung war erfolgreich";
$Reg_Thanks_MSG="Vielen Dank f�r Ihre Anmeldung, der Freischaltungscode wurde an die von Ihnen angegebene Email-Adresse geschickt.";
$Reg_Name_Error="Fehler: Username fehlt.";
$Reg_Name_Exists="Fehler: Username ist bereits vorhanden.";
$Reg_Email_Exists="Fehler: Email-Adresse ist bereits vorhanden.";
$Reg_Pass_Error="Fehler: Passwort fehlt";
$Reg_Pass_Repeat_Error="Fehler: Die Passw�rter stimmen nicht �berein.";
$Reg_Email_Error="Fehler: E-mail-Adresse fehlt.";
$Reg_Smalname_Error="Fehler: Der Username darf nicht k�rzer als 6 Zeichen sein.";
$Reg_Blank_Error="Fehler: nur Buchstaben und Ziffern sind erlaubt";
$Reg_BlankEmail_Error="Fehler: Ihre Email-Adresse fehlt oder ist falsch.";
$Reg_Mail_supject="Ihre Anmeldung";
$Reg_Mail_MSG="Vielen Dank f�r Ihre Anmeldung. Zur automatischen Freischaltung Ihres Accounts rufen Sie bitte folgenden Link auf und geben dort Ihren Freischaltungscode ein.";
$Reg_Code="Freischaltungscode:";
$Reg_Your_Access_Data="Ihre Zugangsdaten";
$Reg_Signatur_MSG="Mit freundlichen Gr��en";
$Reg_Register_Submit="Registrieren";

/* getaccount.php */
$Get_Account_MSG="Bitte den Freischaltungscode im folgenden Feld eingeben:";
$Get_Account_Succ="Ihr Account wurde freigeschaltet. Jetzt k�nnen Sie sich einloggen.";
$Get_Code_Error="Fehler: Der Freischaltungscode ist falsch.";
$Get_id_Error="Fehler: Falsche ID.";
$Get_Submit_MSG="Freischalten";

/* getpass.php */
$Get_Pass_MSG="Geben Sie bitte Ihre Email-Adresse im folgenden Feld ein:";
$Get_Pass_Error="Fehler: Die angegebene Email-Adresse wurde nicht gefunden.";
$Get_Pass_Send="Ihr neues Passwort wurde an die angegebene Email-Adresse geschickt.";
$Get_Pass_Submit="Senden";
$Get_Pass_MailSubject="Ihr neues Passwort";
$Get_Pass_MailMSG="Sie erhalten diese automatische Nachricht aufgrund Ihrer Anforderung eines neuen Passworts.";


/* log_in.php & logout.php */
$log_MSG="Einloggen";
$log_Notlog_MSG="Dieser Service ist nur f�r Mitglieder.";
$log_Error_MSG="Ihre zugangsdaten sind falsch.";
$log_out="Abmelden";

/*account.php */ 
$Acc_Update_log="Zugangsdaten �ndern.";
$Acc_Updatelog_succ="Ihre Zugangsdaten wurden erfolgreich ge�ndert.";
$Acc_Submit_Updatelog="�ndern";

/*ecards.php & history */ 
$EC_Empty_Cat="In dieser Kategorie gibt es keine Grusskarten.";
$EC_From_TotalNums="Von";
$history_Empty_MSG="noch keine Grusskarten";
$history_Delete="l�schen";
$history_Delete_MSG="wirklich l�schen?";
$history_Delete_ECsucc="Grusskarte wurde gel�scht.";
$history_Sent_Ecards="verschickte Grusskarten.";


/* favorites.php */
$Fav_MSG="Ihre beliebtesten Grusskarten.";
$Fav_Empty_MSG="Es befinden sich keine Grusskarten in Ihrem GrusskartenVerzeichnis.";
$Fav_Add_EC="Ihre Grusskarte wurde erfolgreich in Ihr Favoritenverzeichnis eingetragen.";
$Fav_Add_EC_Exist="Die gew�hlte Grusskarte ist schon in Ihrem Favoritenverzeichnis vorhanden.";
$Fav_Delete_EC="Wirklich l�schen?";
$Fav_Delete="L�schen";
$Fav_Delete_ECsucc="Die Grusskarte wurde erfolgreich aus Ihrem Favoritenverzeichnis gel�scht.";

/* card.php*/
$Card_Send_MSG="Senden";
$Card_RateIt_MSG="Bewerten";
$Card_AddToFavorites_MSG="zu Favoriten";

/* rate.php */
$Rate_EC_MSG="Grusskarte bewerten";
$Rate_EC_MSG2="10 ist die beste Wertung.";
$Rate_ECsucc="Vielen Dank f�r Ihre Bewertung.";
$Rate_EC_Error="Sie haben diese Grusskarte heute schon bewertet.";
$Rate_EC_Vote="Abstimmen";

/* topecards.php & newecards.php  */
$New_EC_MSG=" Neue Grusskarten";
$Top_EC_MSG=" Top Grusskarten";

/* sendcard.php */
$Send_EC_MSG="Bitte alle Felder vollst�ndig ausf�llen.";
$Send_EC_MSGEmpty="Sie haben keine Grusskarte gew�hlt.";
$Send_EC_Empty="Die gew�hlte Grusskarte wurde nicht gefunden.";
$Send_To_Mail="Empf�nger Email:";
$Send_To_Name="Empf�nger Name:";
$Send_Sender_Mail="Absender Email:";
$Send_Sender_Name="Absender Name:";
$Send_EC_Subject="Betreff";
$Send_EC_MSGtext="Nachricht:";
$Send_EC_Send="Senden";
$Send_EC_Show="Vorschau";
$Send_EC_Edit="Bearbeiten";
$Send_EC_Stamp="Stempel";
$Send_EC_FontColor="Schriftfarbe";
$Send_EC_FontFace="Schriftart";
$Send_EC_BackgroundColor="Hintergrundfarbe";
$Send_EC_MailSubjekt="Sie haben eine Grusskarte bekommen.";
$Send_EC_MailMSG="Sie haben eine Grusskarte bekommen, klicken Sie auf dem unten stehenenden Link, um Ihre Karte abzuholen.";
$Send_To_Mail_Error="Fehler: Empf�nger Email fehlt oder ist falsch.";
$Send_To_Name_Error="Fehler: Empf�nger Name fehlt.";
$Send_Sender_Mail_Error="Fehler: Absender Email fehlt oder ist falsch.";
$Send_Sender_Name_Error="Fehler: Absender Name fehlt.";
$Send_EC_Subject_Error="Fehler: Betreff fehlt." ;
$Send_EC_MSGtext_Error="Fehler: Nachricht fehlt.";
$Send_EC_MSG_succ="Die Grusskarte wurde erfolgreich versendet.";
$Send_EC_succ="Die Grusskarte wurde erfolgreich versendet, Sie werden automatisch benachrichtigt, wenn die Grusskarte abgeholt wird.";
$Send_EC_Next="[Eine weitere Grusskarte verschicken?]";
$View_EC_Answer="Mit einer Grusskarte antworten!";
$View_EC_Error="Fehler: Die Grusskarte konnte nicht gezeigt werden.";
$View_EC_PickupSubject="Ihre Grusskarte wurde abgeholt";
$View_EC_PickupMSG="der Empf�nger hat die Grusskarte abgeholt, um die Grusskarte nochmal zu sehen,klicken Sie auf dem unten stehenenden Link";


/* Admin Pages */
$Admin_Edit="Bearbeiten";
$Admin_Delete="L�schen";
$Submit_yes="Ja";
$Submit_no="Nein";

/* log_in.php*/
$Admin_log_MSG="Admin-Bereich";
$Admin_Notlog_MSG="Sie sind nicht im Admin-Bereich angemeldet.";
$Admin_logError_MSG="Fehler: Ihre Zugangsdaten sind falsch.";

/*navtab.php */
$Admin_Home="Startseite";
$Admin_User="Benutzer";
$Admin_Search_User="Benutzer suchen.";
$Admin_Category="Kategorien";
$Admin_Ecards="Grusskarten";
$Admin_Add_ECCat="Kategorie eintragen";
$Admin_Add_Ecards="Grusskarten eintragen";
$Admin_Ecards_Delete="Grusskarten l�schen";
$Admin_Ecards_Sent="Versendete Grusskarten";


/* addcards.php,  cardscat.php & */
$Cat_name="Kategorie Name:";
$Cat_Title="Kategorie Titel:";
$Cat_Name_Error="Fehler: Kategorie Name fehlt.";
$Cat_Title_Error="Fehler: Kategorie Titel fehlt.";
$Cat_Name_Exists="Diese Kategorie ist bereits vorhanden.";
$Cat_Add_succ="Kategorie wurde eingetragen.";
$Cat_Submit_Add="Eintragen";
$Cat_Submit_Edit="�ndern";
$Cat_Edit="Kategorie bearbeiten.";
$Cat_Edit_succ="Kategorie wurde ge�ndert.";
$Cat_delete="Wirklich l�schen?";
$Cat_Delete_succ="Kategorie wurde gel�scht.";
$Cat_Empty_MSG="Es sind noch keine Kategorien eingetragen.";
$Ecards_Categories="Grusskarten Kategorien.";
$Ecards_Width_Error="Fehler: Die Grusskartenbreite darf nicht breiter als maximale breite. ";
$Ecards_Height_Error="Fehler: Die Grusskartenh�he darf nicht h�her als maximale hohe."; 
$Ecard_file="Bilddatei";
$Delete_Card_MSG="Wirklich l�schen?";
$Delete_Card_succ="Karte wurde gel�scht.";
$Ecard_Submit="Hochladen";
$Ecard_Size_Error="Fehler: Bilddatei ist zu gross.";
$Ecard_Add_Succ="Bilddatei wurde hochgeladen.";
$Ecard_Type_Error="Fehler: Sie k�nnen nur .jpg, .gif und .png Bildformate hochladen.";
$Sent_Ecards_Date="Datum:";
$Sent_Ecards_Pickup="Abholen:";
$Sent_Ecards_PostId="ID:";
$Sent_Ecards_PostCode="Code:";
$Sent_Ecards_Deletesucc="Grusskarte wurde gel�scht.";
$Pickup_yes="Ja";
$Pickup_no="Nein";

/* user.php , searchusr.php */
$Admin_SearchUser_MSG="Benutzer suchen.";
$Admin_SearchUser_Error="Es wurde kein Ergebnis mit dem gesuchten Wort gefunden.";
$Admin_User_MSG="Benutzer";
$Admin_User_delete="L�schen";
$Admin_User_deleteMSG="Wollen Sie diesen Benutzer wirklich l�schen?";
$Admin_User_deleteSucc="Benutzer wurde gel�scht.";
$Admin_User_Email="Email-Adresse";
$Admin_User_date="Seit";
$yes="Ja";
$no="Nein";
?>