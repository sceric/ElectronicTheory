      <option  value="#000000" style=" width:auto color:#000000; background-color : #000000; ">
	  <option  value="#996600" style="width:auto  color:#996600; background-color : #996600; ">
	  <option  value="#666666" style="width:auto  color:#666666; background-color : #666666; ">
	  <option  value="#999999" style="width:auto  color:#999999; background-color : #999999; ">
	  <option  value="#CCCCCC" style="width:auto  color:#CCCCCC; background-color : #CCCCCC; ">
	  <option  value="#FFFFFF" style="width:auto  color:#FFFFFF; background-color : #FFFFFF; ">
	  <option  value="#FF0000" style="width:auto  color:#FF0000; background-color : #FF0000; ">
	  <option  value="#CC0000" style="width:auto  color:#CC0000; background-color : #CC0000; ">
	  <option  value="#FF9966" style="width:auto  color:#FF9966; background-color : #FF9966; ">
	  <option  value="#FF6600" style="width:auto  color:#FF6600; background-color : #FF6600; ">	  
	  <option  value="#0099FF" style="width:auto  color:#0099FF; background-color : #0099FF; ">  
	  <option  value="#0000FF" style="width:auto  color:#0000FF; background-color : #0000FF; ">	  
	  <option  value="#FFFFCC" style="width:auto  color:#FFFFCC; background-color : #FFFFCC; ">
	  <option  value="#FFFF00" style="width:auto  color:#FFFF00; background-color : #FFFF00; ">
	  <option  value="#00FF00" style="width:auto  color:#00FF00; background-color : #00FF00; ">
	  <option  value="#00CC00" style="width:auto  color:#00CC00; background-color : #00CC00; ">
	  <option  value="#99FF00" style="width:auto  color:#99FF00; background-color : #99FF00; ">
	  <option  value="#99CC00" style="width:auto  color:#99CC00; background-color : #99CC00; "> 
	  <option  value="#FFCCFF" style="width:auto  color:#FFCCFF; background-color : #FFCCFF; ">
	  <option  value="#FF33FF" style="width:auto  color:#FF33FF; background-color : #FF33FF; ">
	  <option  value="#9966FF" style="width:auto  color:#9966FF; background-color : #9966FF; ">
	  <option  value="#9900FF" style="width:auto  color:#9900FF; background-color : #9900FF; ">
	  <option  value="#FFFFFF" style="width:auto   color:#FFFFFF; background-color :#FFFFFF; ">
	  <option  value="#000000" style="background-color : #000000;">---------------</option> 
   