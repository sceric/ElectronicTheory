<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
include("connect.php");

if (isset($ecardswa_userid) )

{ 
$sqlusr=mysql_query("select * from ecardswa_user where userid='$ecardswa_userid'");
if(!empty($sqlusr)){
$numuser=mysql_num_rows($sqlusr);
if($numuser==1){
$usrrow=mysql_fetch_array($sqlusr);
$uname=$usrrow["username"];
$tabhello=true;
$tabsignin=false;
  }
  else if($numuser==0){
  $tabhello=false;
  $tabsignin=true;
   }
  }
} 
else
{
$tabsignin=true;
}

?>


<style type="text/css">
<!--
.Stil2 {font-size: 12px;
	font-weight: bold;
}
-->
</style>
<table width="149" border="0" cellspacing="2" cellpadding="0">
  <tr>
    <th align="center" valign="top" scope="col"> <?php
	   if($tabsignin){ ?>
      <table width="145" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" id="tb">
        <tr>
          <th width="400" height="21" bgcolor="#FFCC99" scope="col"><?php echo"$Members_Login";?></th>
        </tr>
        <tr>
          <td width="145" align="center"><form action="login.php" method="post" >
              <table width="140" border="0" cellspacing="2" cellpadding="0">
                <tr>
                  <th width="50" align="center" valign="top" class="Stil2" scope="col"><strong><font size="2"> <?php print"$Reg_Name"; ?></font></strong></th>
                  <th width="60" align="left" scope="col"><input name="loginname" type="text" size="10"></th>
                </tr>
                <tr>
                  <td width="50" align="center" valign="top"><strong><font size="2"><?php print"$Reg_Pass"; ?></font></strong></td>
                  <td width="60" align="left"><input name="pass" type="password" size="10"></td>
                </tr>
                <tr align="right">
                  <td width="50">&nbsp;</td>
                  <td align="left"><input name="log" type="submit" value="<?php echo"$log_MSG";?>"></td>
                </tr>
                <tr align="left">
                  <td colspan="2"><a href="newuser.php"><?php echo"$new_reg"; ?></a></td>
                </tr>
                <tr align="left">
                  <td colspan="2"><a href="getpass.php"><?php echo"$get_pass"; ?></a></td>
                </tr>
              </table>
          </form></td>
        </tr>
      </table>
      <?php } ?>
      <?php   if($tabhello){ ?>
      <form action="logout.php" method="post">
          <table width="148" height="50" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <th height="20" scope="col"><?php echo"$hello"." "."$uname"; ?></th>
            </tr>
            <tr>
              <td height="30" align="center"><input name="log" type="submit" value="<?php echo"$log_out"; ?>"></td>
            </tr>
          </table>
      </form>
    <?php } ?></th>
  </tr>
</table>

