<?php
////////////////////////////////////////////////////////////////////////////////
//							          		 							      //
//	         				                                                  //
//        			      Ecardswa Version 1.5 		   						  //          
//		    			 Released January , 2005		  	       			  //
//		              Copyright Ecardswa Version 1.5                          //
//		                     Powered by :                                     //
//                       http://www.demof.com                                 //
//                       http://www.ecards.it                                 //
//                        Autor: Walid Awad                                   //                            
//                                                                            //
//							                  							      //
//   All license terms & conditions are valid as soon as you have installed   //
//   this programm onto your server and published it.                         //
//							   							                      //
//   The copyright of the author must not in any case changed or removed.     //
//				                                                              //
//   You are not allowed to use this free programm for any PORN sites.        //
//                                                                            //   							 
//   You can change the layout of this programm but you are not allowed to    //
//   change the programm code.                                                //
//                                                                            //
//   If you do not accept all our license terms &  conditions, you will not   //
//   be allowed to use this free programm.                                    //
//                                                                            //
//   You can find more informations about the license terms & conditions in   //
//   the readme.txt.                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

include("language/en.php");
include("config.php");

/* Please just change the numbers  */

$maxsize=100000;    
$ecardsdir="ecards/";   /* ecards directory */
$cardheight=600;        /* card height  */ 
$cardwidth=600;         /* card width  */     
$maxtop=20;             /* top ecards result  */           
$indextop=5;           /* top ecards result  for index.php  */
$maxnew=20;             /*  new ecards result */
$history_result=30;     /*  history result per site */
$ecards_result=20;       /*  ecards  result per site */
$sent_result=20;        /*  sent cards  result per site */
$AdminUser_result=30;   /*  user  result per site */    
   
?>