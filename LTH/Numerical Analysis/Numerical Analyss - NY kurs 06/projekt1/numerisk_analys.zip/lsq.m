
%Problem 1

%------- Least squares solution-------
% 
% Man kan skriva funktion som:
% 
% function x = lsq(A, y)
% inv(A'*A)*A'*y

%-------------------------------------

% eller som i uppgifft kr�ver
% att man ska anv�nda "\"

%-------------------------------------

function x = lsq(A, y);
x = (A'*A)\(A'*y);
